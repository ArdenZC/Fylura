# v3.40 · 删除范围、冲突决策、身份闭环

> 2026-11-13 · 对应 `redesign-v2.html` / `redesign-v2-macos.html`
> 起因：第三轮独立复审（2×P0 + 2×P1 + 1×P2），全部在文件操作逻辑
> 验证：`_verify-ops.js` 12 组 + `_verify-ops-mac.js` 4 组，均 `allPass: true`

## 五个问题，四个出自「一次性写完就没再回头看」

| 编号 | 问题 | 根因 |
|---|---|---|
| P0 | 删除文件夹只删根，子树变孤儿 | `del()` 只遍历选中项，没展开子树 |
| P0 | 剪切到同名目录出现两个同名条目 | 移动分支完全不查重名 |
| P1 | Windows 行右键的篮子键还是旧键 | v3.39 改了键，漏了 `rowMenu` 这一处 |
| P1 | 复制到自身后代生成 `Root/Sub/Root/Sub/…` | 先插新根、再查来源子树 → 新根把自己算进来源 |
| P2 | 剪贴板认领同名新对象 | 失效后按「路径 + 名字」重找，等于把新对象当成旧的 |

## 改法

### 删除：先展开子树，再一起走
```js
const set = new Set(picked);                       // 兼容父子同时选中
picked.forEach(f => { if (f.folder) subtreeOf(f).forEach(k => set.add(k)); });
const items = [...set];
```
同一批进 `trash`、同一条历史，撤销一次整棵回来。历史标题标「含 N 个子项」。

### 移动撞名：先问，再动
粘贴前扫描目标位置的同名项，一次性弹决策（避免批量操作时连弹十几个）：

| 选项 | 行为 |
|---|---|
| 保留两者 | 进来的项目改名为「名称 2」，原图标不动 |
| 跳过这些项 | 只跳过重复的，其余照常 |
| 替换目标 | 目标位置的原文件移入安全回收站（不是直接删） |

取消 = 整批不动，剪贴板保留。Copy 不需要问：它天然是「保留两者」。

### 复制到自身后代：先取快照，再拦截
```js
// 改前：push 之后再查，新根在自己的后代里 → 无限套娃
FILES.push({ ...f, p: dest, full: copyFull });
cloneSubtree(f, copyFull);              // → subtreeOf(f) 含新根

// 改后
const snapshot = f.folder ? subtreeOf(f).slice() : [];   // 插入前定格
if (selfNest) { skipped++; return; }                     // 目标是自身/后代，直接拦
FILES.push(...);
cloneSubtree(f, copyFull, snapshot);
```

### 剪贴板：稳定 uid，不做名字匹配
```js
const UID = new WeakMap();                 // 跟着对象走，不跟下标、不跟名字
const resolveClipItem = it =>
  FILES.includes(it.ref) ? it.ref : FILES.find(x => uidOf(x) === it.id);
```
都对不上 → 明确提示「来源文件已不存在，请重新复制」。删掉原文件再建同名新文件，不会被误认。

### 篮子：一处改键，全部调用点
键改成一个函数 `ops.bkey(f)`，平台层菜单也用它；mac 篮子「移出」原来按名字删，改成按下标定位（键里有 `\0`，不能塞进 data 属性）。

## 验证

`_verify-ops.js` 从 7 组扩到 12 组，**全部走真实入口**（这一点是上一轮的教训：直接 `basket.set(...)` 不能证明菜单路径是对的）：

```
copy / move / rename        层级与前缀                            ✅✅✅
deleteTree      删根 → 3 项一起进 trash，撤销后整棵回来            ✅
quickUndo       恢复 + 历史 undone=true                            ✅
undoChain       先撤较早 → 最新那条仍可撤                          ✅
clipIdentity    插入干扰项 → 仍指向原对象                          ✅
clipStale       删原文件+建同名 → 不认领（pasted: false）          ✅
moveConflict    弹决策 → 保留两者 → 两个不同名                     ✅
copySelfNest    复制到自身后代 → 被拦，无套娃                      ✅
basketRowMenu   右键菜单入口 → size=2                             ✅
basketToolbar   顶层按钮入口 → size=2                             ✅
```

新增 `_verify-ops-mac.js` 4 组（Windows 脚本依赖 `zcPanes`，不能当 mac 的证明）：
```

deleteTree / moveConflict / quickUndo / basket（含移出一项）      ✅✅✅✅
```

两份原型 8 页 + 暗色全量加载零 JS 异常；`_build.py --check` 零漂移。

## 仍然要做到「冻结」之外的事

评审的结论我同意：**视觉与信息架构可以冻结**，文件操作模拟逻辑这一层已经连续三轮被挖出问题。三个「身份」问题是同一个债：

1. 下标 → 剪贴板漂移
2. 文件名 → 篮子覆盖
3. 路径字符串前缀 → 层级塌陷 / 孤儿

所以原型的这套 `FILES` 数组逻辑**只适合演示**。正式实现必须用：稳定文件 ID（inode / handle）、明确的 Pane ID、树节点模型、以及 Rust 侧 Transfer / Journal / Restore。这条与 4.1 的「不要照搬的写法」一致，本轮又补了「一次性快照」与「不做名字匹配」两条。
