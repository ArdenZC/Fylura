# Fylura 文件管理器 · 高保真原型 v3.40

单文件 HTML 原型，两套：Windows（资源管理器形态）与 macOS（Finder 形态）。
同时是设计规范、走查记录与性能测量的交付包。

---

## 30 秒打开

直接双击 `redesign-v2.html`（Windows 版）或 `redesign-v2-macos.html`（mac 版）。

**但预览图与缩略图需要 `assets/` 在同一目录**，所以更稳的方式是起一个本地服务：

```bash
cd fylura-proto-v3.37
node serve-v2.mjs
# 打开 http://127.0.0.1:4281/redesign-v2.html
# mac 版：http://127.0.0.1:4281/redesign-v2-macos.html
```

右上角有 `Windows / macOS` 切换，可以在同一个文件里对比两套形态。

---

## 包里有什么

| 文件 | 说明 |
|---|---|
| `redesign-v2.html` | Windows 版原型（单文件，已内联全部 CSS/JS） |
| `redesign-v2-macos.html` | macOS 版原型（同上） |
| `DESIGN-SPEC.md` | 设计规范 v3.37：令牌、组件、状态机、动效、交互决策与变更记录 |
| `MOTION.md` | 动效全量清单、本轮修复、性能测量方法、Framer Motion 映射、自评 |
| `HANDOFF.md` | 相对实机项目的改动、逐项实现、演示数据、不可改的约束 |
| `WALK-REPORT.md` | 点击走查：71 个控件的死链复扫、业务流程逐步截图结论 |
| `OVERVIEW-v3.37.md` | 本轮改动的对外摘要（做了什么 / 修了什么 / 验收数据） |
| `src/` | 原型源码（7 个共享页面 + 各模块 CSS/JS） |
| `assets/` | 预览与缩略图（缺了它预览面板是空的） |
| `_build.py` | 构建：把 `src/` 写回两份原型，`--check` 做漂移检测 |
| `_shot.mjs` | 截图 / 跑页面内断言：`node _shot.mjs <url> <out.png> [w] [h] [setup.js]` |
| `_walk.mjs` | 走查器：`--dead` 按钮差分、`--flow=xxx.mjs` 流程截图 |
| `_perf.mjs` | 性能测量：`node _perf.mjs <url> [cpuRate] [probe.css]` |
| `_perf-*.json` | 性能测量留档（4× 降速 / 不降速，win 与 mac） |

---

## 改了东西怎么重新构建

**不要直接改两份 HTML 的共享区** —— 那些内容由 `src/` 生成，`--check` 会报漂移。

```bash
python _build.py           # 写入两份原型
python _build.py --check   # 只检查是否与 src/ 一致（CI 用）
```

结构约定（详见 `_build.py` 头部注释）：

- `src/shared/overview.html`、`src/shared/pages.html` —— 7 个非文件页的唯一来源，两套共用
- `src/flow.css` / `flow.js` —— 业务状态机，两套共用
- **只有「文件」页允许分叉**：Windows 用 `v2-library.js`，macOS 用 `mac-library.js`

---

## 怎么验证（不靠眼睛）

```bash
# 1. 按钮级死链：逐个点，判定「点了没反应」
node _walk.mjs http://127.0.0.1:4281/redesign-v2.html out --dead

# 2. 业务流程：按自备脚本点完整链路并逐步截图（脚本格式见 _walk.mjs 头部注释）
node _walk.mjs http://127.0.0.1:4281/redesign-v2.html out --flow=yourflow.mjs

# 3. 动效成本：4 倍 CPU 降速 + 与配置无关的指标
node _perf.mjs http://127.0.0.1:4281/redesign-v2.html 4

# 4. 回归断言（返回 JSON，看 allPass 是否为 true）
node _shot.mjs http://127.0.0.1:4281/redesign-v2.html /tmp/p0.png  1440 900 _verify-p0.js   # 多窗格选择 / 逐笔撤销 / 文件名注入
node _shot.mjs http://127.0.0.1:4281/redesign-v2.html /tmp/ops.png 1440 900 _verify-ops.js      # 层级 / 删除子树 / 冲突 / 身份 / 篮子（12 组）
node _shot.mjs http://127.0.0.1:4281/redesign-v2-macos.html /tmp/mac.png 1440 900 _verify-ops-mac.js  # mac 选择模型（4 组）
```

性能一条重要前提：**不看绝对 fps**（60Hz 与 144Hz 屏、不同配置没法比），只看
① 一次动画触发几次重排（代码属性）② 降速后的长帧分布 ③ 长帧里排版占多少。
方法和本轮结论见 `MOTION.md` 第 8 节。

---

## 已知限制

1. **没有真机帧率确认**。headless 走软件合成，真机 GPU 路径不同，需在目标机器上跑一次 Performance 面板。
2. 动效只覆盖 7 个页面，实机另外 6 个视图没有对应参考。
3. 页面切换（约 130ms 长帧）与四宫格渲染（约 116ms）是真实 DOM 重建成本，未上虚拟列表，属「原价」。
4. 走查器的差分读 `body.innerHTML` 哈希，纯 CSS 类驱动的折叠可能被误判成「无反应」，这类靠截图人工复核。
5. 数据为演示数据（`FILES` / `PLAN` / `HIST` 等），刷新即重置；不写本地存储（除侧栏折叠与主题偏好）。

---

## 版本

v3.40 · 2026-11-13
本轮：删除文件夹带上子树、移动撞名改为先决策（保留两者/跳过/替换）、
复制到自身后代拦下、剪贴板改用会话内稳定 uid（不再按名字认领）、
补齐 Windows 行右键与 mac 篮子移出的键/索引问题。
断言脚本：`_verify-ops.js` 12 组 + `_verify-ops-mac.js` 4 组。

v3.39：多级目录层级映射、快捷键撤销同步、剪贴板对象身份、篮子 path+name 键。

v3.38：三个 P0（多窗格取错选择 / 撤销不绑定单次删除 / 文件名注入）、mac 交通灯与窄窗口。
v3.37：弹簧动效层（两套令牌 + 四条曲线）、9 处缺陷修复、`contain:layout` 性能优化。
