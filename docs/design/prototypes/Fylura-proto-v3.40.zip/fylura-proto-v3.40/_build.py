#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""单文件原型的构建入口（唯一入口）。

    python _build.py           # 把 src/ 里的共享内容写回两份原型
    python _build.py --check   # 只检查原型是否与 src/ 漂移，有漂移退出码 1
    python _build.py --extract # 首次：从原型里抽出共享区到 src/shared/

结构约定
--------
两份原型各自是**可独立打开的完整文件**，但其中三块内容不手写在原型里：

    src/shared/overview.html   概览页（两套逐字相同）
    src/shared/pages.html      整理 / Dry Run / 清理 / 历史 / 规范 / 设置（两套逐字相同）
    src/flow.css, src/flow.js  业务状态机（注入两套）

原型里用注释标记占位：

    <!-- @shared:overview:begin --> ... <!-- @shared:overview:end -->
    <!-- @shared:pages:begin -->    ... <!-- @shared:pages:end -->
    <style id="zcFlowCss"> … </style>
    <script id="zcFlowJs"> … </script>

「文件」页不在共享区：Windows 是资源管理器形态，macOS 是 Finder 形态，这是唯一
允许分叉的地方（见 DESIGN-SPEC 9.8）。
"""
import re
import sys
import hashlib
from pathlib import Path

ROOT = Path(__file__).parent
SRC = ROOT / "src"
SHARED = SRC / "shared"
FILES = [ROOT / "redesign-v2.html", ROOT / "redesign-v2-macos.html"]
# 只有某一套原型需要的脚本（文件页是唯一允许分叉的地方）
PLATFORM_JS = {
    "redesign-v2.html": "v2-library.js",
    "redesign-v2-macos.html": "mac-library.js",
}
# 先于 PLATFORM_JS 注入：窗格引擎要在能力层之前接管 render/renderB
PLATFORM_JS_PRE = {
    "redesign-v2.html": "v2-panes.js",
}
PLATFORM_CSS = {
    "redesign-v2.html": ["ui-collapse.css", "v2-panes.css", "v2-devices.css", "v2-sidebar.css", "motion.css", "spring.css"],
    "redesign-v2-macos.html": ["ui-collapse.css", "mac-devices.css", "motion.css", "spring.css"],
}
# 侧栏折叠（两套共用）；文件库分组折叠只有 Windows 版
SHARED_UI = "sidebar.js"
SHARED_MOTION = "motion.js"
PLATFORM_UI = {
    "redesign-v2.html": "v2-sidebar.js",
}
# 外部存储：数据与状态机两套共用，界面各平台自己渲染
SHARED_DEVICES = "devices.js"
PLATFORM_DEVICES = {
    "redesign-v2.html": "v2-devices.js",
    "redesign-v2-macos.html": "mac-devices.js",
}
# 两套共用的文件操作层（数据逻辑一份，平台差异走 adapter）
SHARED_OPS = "file-ops.js"

MARKERS = [
    # (key, 起始锚点, 结束锚点)
    ("overview", "      <!-- ============ 概览 ============ -->", "      <!-- ============ 文件 ============ -->"),
    ("pages", "      <!-- ============ 整理文件 ============ -->", "    </main>"),
]

# ---------------- 标记 ----------------

def _mark(key, which):
    # 标记顶格写，且不带缩进参与匹配：缩进一旦被构build改写，匹配就会漂
    return f"<!-- @shared:{key}:{which} -->"


def ensure_markers(text: str) -> str:
    for key, anchor_start, anchor_end in MARKERS:
        b, e = _mark(key, "begin"), _mark(key, "end")
        if b in text and e in text:
            continue
        if anchor_start not in text or anchor_end not in text:
            raise SystemExit(f"找不到锚点：{key}")
        text = text.replace(anchor_start, b + "\n" + anchor_start, 1)
        text = text.replace(anchor_end, e + "\n" + anchor_end, 1)
    return text


def region_span(text: str, key: str):
    b, e = _mark(key, "begin"), _mark(key, "end")
    i = text.index(b) + len(b)
    j = text.index(e)
    return i, j


def extract_region(text: str, key: str) -> str:
    i, j = region_span(text, key)
    return text[i:j].strip("\n") + "\n"


def inject_region(text: str, key: str, body: str) -> str:
    i, j = region_span(text, key)
    return text[:i] + "\n" + body.strip("\n") + "\n" + text[j:]


# ---------------- 样式 / 脚本注入 ----------------

def strip_blocks(text: str) -> str:
    text = re.sub(r'<style id="zcFlowCss">.*?</style>\n?', "", text, flags=re.S)
    text = re.sub(r'<script id="zcFlowJs">.*?</script>\n?', "", text, flags=re.S)
    text = re.sub(r'<style id="paneCss">.*?</style>\n?', "", text, flags=re.S)
    text = re.sub(r'<script id="panesJs">.*?</script>\n?', "", text, flags=re.S)
    text = re.sub(r'<script id="opsJs">.*?</script>\n?', "", text, flags=re.S)
    text = re.sub(r'<script id="libJs">.*?</script>\n?', "", text, flags=re.S)
    text = re.sub(r'<script id="devJs">.*?</script>\n?', "", text, flags=re.S)
    text = re.sub(r'<script id="devUiJs">.*?</script>\n?', "", text, flags=re.S)
    text = re.sub(r'<script id="uiJs">.*?</script>\n?', "", text, flags=re.S)
    text = re.sub(r'<script id="uiPlatJs">.*?</script>\n?', "", text, flags=re.S)
    text = re.sub(r'<script id="moJs">.*?</script>\n?', "", text, flags=re.S)
    return text


def inject_blocks(text: str, css: str, js: str, platform_js: str = "", ops_js: str = "",
                  pane_css: str = "", panes_js: str = "",
                  dev_js: str = "", dev_ui: str = "",
                  ui_js: str = "", ui_plat: str = "", mo_js: str = "") -> str:
    if '<style id="zcFlowCss">' not in text:
        assert text.count("</head>") == 1
        text = text.replace("</head>", '<style id="zcFlowCss">\n' + css + "\n</style>\n</head>", 1)
    if pane_css and '<style id="paneCss">' not in text:
        text = text.replace("</head>", '<style id="paneCss">\n' + pane_css + "\n</style>\n</head>", 1)
    anchor = '<div class="proto-switch" role="group" aria-label="原型版本">'
    if '<script id="zcFlowJs">' not in text:
        assert anchor in text
        text = text.replace(anchor, '<script id="zcFlowJs">\n' + js + "\n</script>\n" + anchor, 1)
    if panes_js and '<script id="panesJs">' not in text:
        text = text.replace(anchor, '<script id="panesJs">\n' + panes_js + "\n</script>\n" + anchor, 1)
    if ops_js and '<script id="opsJs">' not in text:
        text = text.replace(anchor, '<script id="opsJs">\n' + ops_js + "\n</script>\n" + anchor, 1)
    if platform_js and '<script id="libJs">' not in text:
        text = text.replace(anchor, '<script id="libJs">\n' + platform_js + "\n</script>\n" + anchor, 1)
    if dev_js and '<script id="devJs">' not in text:
        text = text.replace(anchor, '<script id="devJs">\n' + dev_js + "\n</script>\n" + anchor, 1)
    if dev_ui and '<script id="devUiJs">' not in text:
        text = text.replace(anchor, '<script id="devUiJs">\n' + dev_ui + "\n</script>\n" + anchor, 1)
    if ui_js and '<script id="uiJs">' not in text:
        text = text.replace(anchor, '<script id="uiJs">\n' + ui_js + "\n</script>\n" + anchor, 1)
    if ui_plat and '<script id="uiPlatJs">' not in text:
        text = text.replace(anchor, '<script id="uiPlatJs">\n' + ui_plat + "\n</script>\n" + anchor, 1)
    if mo_js and '<script id="moJs">' not in text:
        text = text.replace(anchor, '<script id="moJs">\n' + mo_js + "\n</script>\n" + anchor, 1)
    return text


# ---------------- 构建 ----------------

def read(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="strict").replace("\r\n", "\n")


def write(p: Path, text: str) -> None:
    with open(p, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)


def build_text(path: Path, css: str, js: str) -> str:
    text = read(path)
    text = ensure_markers(text)
    for key, _, _ in MARKERS:
        body = (SHARED / f"{key}.html").read_text(encoding="utf-8")
        text = inject_region(text, key, body)
    text = strip_blocks(text)
    name = PLATFORM_JS.get(path.name, "")
    pjs = ""
    if name and (SRC / name).exists():
        pjs = read(SRC / name)
    ops = read(SRC / SHARED_OPS) if (SRC / SHARED_OPS).exists() else ""
    pname = PLATFORM_JS_PRE.get(path.name, "")
    pjs_pre = read(SRC / pname) if pname and (SRC / pname).exists() else ""
    cnames = PLATFORM_CSS.get(path.name, [])
    if isinstance(cnames, str):
        cnames = [cnames]
    pcss = "\n".join(read(SRC / c) for c in cnames if (SRC / c).exists())
    dev = read(SRC / SHARED_DEVICES) if (SRC / SHARED_DEVICES).exists() else ""
    dname = PLATFORM_DEVICES.get(path.name, "")
    dev_ui = read(SRC / dname) if dname and (SRC / dname).exists() else ""
    ui_js = read(SRC / SHARED_UI) if (SRC / SHARED_UI).exists() else ""
    uname = PLATFORM_UI.get(path.name, "")
    ui_plat = read(SRC / uname) if uname and (SRC / uname).exists() else ""
    mo_js = read(SRC / SHARED_MOTION) if (SRC / SHARED_MOTION).exists() else ""
    return inject_blocks(text, css, js, pjs, ops, pcss, pjs_pre, dev, dev_ui, ui_js, ui_plat, mo_js)


def main(argv):
    if "--extract" in argv:
        SHARED.mkdir(parents=True, exist_ok=True)
        ref = ensure_markers(read(FILES[0]))
        for key, _, _ in MARKERS:
            write(SHARED / f"{key}.html", extract_region(ref, key))
            print("抽出", key, "->", SHARED / f"{key}.html")
        # 标记也要落到文件里
        for f in FILES:
            write(f, ensure_markers(read(f)))
        print("标记已写入，可以再跑一次构建")
        return 0

    css = read(SRC / "flow.css")
    js = read(SRC / "flow.js")

    drift = False
    for f in FILES:
        want = build_text(f, css, js)
        have = read(f)
        if "--check" in argv:
            if want != have:
                drift = True
                print("漂移:", f.name)
            else:
                print("一致:", f.name)
            continue
        if want != have:
            write(f, want)
        print("构建:", f.name, hashlib.md5(want.encode()).hexdigest()[:8])

    if "--check" in argv and drift:
        print("\n原型里手改了共享区，请改 src/shared/*.html 后重新构建")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
