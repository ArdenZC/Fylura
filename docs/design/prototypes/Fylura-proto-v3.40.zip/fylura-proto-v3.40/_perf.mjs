// 动效成本测量：node _perf.mjs <url> [cpuRate]
// 不看绝对 fps（那是硬件属性），只看与配置无关的三类数：
//   1. 每次动画触发的 Layout / RecalcStyle 次数（代码属性，任何机器都一样）
//   2. 降速 4x 后的长帧分布（模拟低端机：p95 / 最长帧 / 掉帧比）
//   3. Long Animation Frame 里的 style+layout 耗时（定位是哪一帧贵）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const [,, url, rateStr = '4', cssFile = ''] = process.argv;
const CPU = +rateStr;
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PORT = 9800 + Math.floor(Math.random() * 150);
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'zc-perf-'));

const chrome = spawn(CHROME, [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-gpu',
  '--allow-file-access-from-files', '--force-color-profile=srgb', 'about:blank'
], { stdio: 'ignore' });

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function browserWS() {
  for (let i = 0; i < 120; i++) {
    try {
      const j = await (await fetch(`http://127.0.0.1:${PORT}/json/version`)).json();
      if (j.webSocketDebuggerUrl) return j.webSocketDebuggerUrl;
    } catch {}
    await sleep(100);
  }
  throw new Error('chrome ws not ready');
}

const wsUrl = await browserWS();
const ws = new WebSocket(wsUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });

let seq = 0;
const pending = new Map();
ws.onmessage = ev => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    const { res, rej } = pending.get(m.id);
    pending.delete(m.id);
    m.error ? rej(new Error(JSON.stringify(m.error))) : res(m.result);
  }
};
function send(method, params = {}, sessionId) {
  const id = ++seq;
  return new Promise((res, rej) => {
    pending.set(id, { res, rej });
    ws.send(JSON.stringify({ id, method, params, sessionId }));
  });
}

const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
const S = (m, p) => send(m, p, sessionId);

await S('Page.enable');
await S('Runtime.enable');
await S('Performance.enable');
await S('Emulation.setDeviceMetricsOverride', { width: 1440, height: 900, deviceScaleFactor: 2, mobile: false });

const evaluate = async expr => {
  const r = await S('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
  if (r.exceptionDetails) return { __err: r.exceptionDetails.exception?.description || 'err' };
  return r.result?.value;
};

// 页面内探针：帧间隔 + 长动画帧
const INSTRUMENT = `(() => {
  window.__perf = { frames: [], loaf: [] };
  let last = 0;
  const loop = t => { if (last) window.__perf.frames.push(+(t - last).toFixed(2)); last = t; requestAnimationFrame(loop); };
  requestAnimationFrame(loop);
  try {
    new PerformanceObserver(list => {
      for (const e of list.getEntries()) {
        window.__perf.loaf.push({
          d: Math.round(e.duration),
          style: Math.round(e.styleAndLayoutStart ? (e.styleAndLayoutStart - e.startTime) : 0),
          block: Math.round(e.blockingDuration || 0)
        });
      }
    }).observe({ type: 'long-animation-frame', buffered: false });
  } catch (_e) {}
  return 'armed';
})()`;

// 场景：每个都以 gotoPage('library') 起手，动作重复多次以摊薄噪声
const SCENES = [
  { id: 'page', name: '页面切换', js: `(async () => {
      gotoPage('library'); await new Promise(r=>setTimeout(r,260));
      for (let i=0;i<6;i++){ gotoPage(i%2?'overview':'library'); await new Promise(r=>setTimeout(r,200)); }
      return 'ok'; })()` },
  { id: 'rail', name: '侧栏收展', js: `(async () => {
      const b = document.querySelector('.side-toggle');
      gotoPage('library'); await new Promise(r=>setTimeout(r,260));
      for (let i=0;i<4;i++){ b.click(); await new Promise(r=>setTimeout(r,360)); }
      return 'ok'; })()` },
  { id: 'menu', name: '菜单弹出', js: `(async () => {
      gotoPage('library'); await new Promise(r=>setTimeout(r,260));
      const b = document.getElementById('layoutBtn');
      for (let i=0;i<4;i++){ b.click(); await new Promise(r=>setTimeout(r,320)); closeMenu(); await new Promise(r=>setTimeout(r,200)); }
      return 'ok'; })()` },
  { id: 'sheet', name: '确认层', js: `(async () => {
      gotoPage('library'); await new Promise(r=>setTimeout(r,260));
      for (let i=0;i<3;i++){
        zcFlow.zcConfirm({ title:'删除 3 项', sub:'将移入安全回收站', ok:'删除', danger:true });
        await new Promise(r=>setTimeout(r,320));
        [...document.querySelectorAll('.zc-scrim .btn')].find(x=>x.textContent.trim()==='取消').click();
        await new Promise(r=>setTimeout(r,260));
      }
      return 'ok'; })()` },
  { id: 'tree', name: '目录树折叠', js: `(async () => {
      gotoPage('library'); await new Promise(r=>setTimeout(r,260));
      const hs = [...document.querySelectorAll('.tree-group.tree-sec-h')].slice(0,4);
      for (let k=0;k<2;k++){
        for (const h of hs){ h.click(); await new Promise(r=>setTimeout(r,300)); }
      }
      return 'ok'; })()` },
  { id: 'view', name: '列表↔网格', js: `(async () => {
      gotoPage('library'); await new Promise(r=>setTimeout(r,260));
      for (let i=0;i<4;i++){ document.getElementById('viewA').click(); await new Promise(r=>setTimeout(r,300)); }
      return 'ok'; })()` },
  { id: 'layout', name: '窗格布局切换', js: `(async () => {
      gotoPage('library'); await new Promise(r=>setTimeout(r,260));
      for (const id of ['2v','4','3','1']){ zcPanes.setLayout(id); await new Promise(r=>setTimeout(r,340)); }
      return 'ok'; })()` }
];

const results = [];
const metricsOf = async () => {
  const { metrics } = await S('Performance.getMetrics');
  const m = {};
  metrics.forEach(x => { m[x.name] = x.value; });
  return m;
};

for (const sc of SCENES) {
  await S('Emulation.setCPUThrottlingRate', { rate: 1 });
  await S('Page.navigate', { url });
  await sleep(900);
  if (cssFile) {
    const css = fs.readFileSync(cssFile, 'utf8');
    await evaluate(`(() => { const s=document.createElement('style'); s.id='perfProbe'; s.textContent=${JSON.stringify(css)}; document.head.appendChild(s); return 'injected'; })()`);
  }
  await evaluate(`window.__perf = null`);
  await evaluate(INSTRUMENT);
  const m0 = await metricsOf();
  await S('Emulation.setCPUThrottlingRate', { rate: CPU });
  await evaluate(sc.js);
  const raw = await evaluate(`JSON.stringify(window.__perf)`);
  const m1 = await metricsOf();
  await S('Emulation.setCPUThrottlingRate', { rate: 1 });

  let frames = [], loaf = [];
  try { const p = JSON.parse(raw); frames = p.frames || []; loaf = p.loaf || []; } catch {}
  // 去掉首尾各 2 帧（起手与收尾不干净）
  const f = frames.slice(2, Math.max(3, frames.length - 2));
  const sorted = [...f].sort((a, b) => a - b);
  const pct = q => sorted.length ? sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * q))] : 0;
  const median = pct(0.5);
  const budget = 1000 / 60;
  const dropped = f.filter(x => x > budget * 1.6).length;

  results.push({
    name: sc.name,
    frames: f.length,
    p50: +median.toFixed(1),
    p95: +pct(0.95).toFixed(1),
    max: f.length ? Math.max(...f) : 0,
    dropped,
    layout: Math.round((m1.LayoutCount || 0) - (m0.LayoutCount || 0)),
    recalc: Math.round((m1.RecalcStyleCount || 0) - (m0.RecalcStyleCount || 0)),
    layoutMs: Math.round(((m1.LayoutDuration || 0) - (m0.LayoutDuration || 0)) * 1000),
    scriptMs: Math.round(((m1.ScriptDuration || 0) - (m0.ScriptDuration || 0)) * 1000),
    loafN: loaf.length,
    loafMax: loaf.length ? Math.max(...loaf.map(x => x.d)) : 0,
    loafStyle: loaf.length ? Math.round(loaf.reduce((a, x) => a + x.style, 0) / loaf.length) : 0
  });
  const r = results[results.length - 1];
  console.log(`${sc.name.padEnd(8)} 帧 ${String(r.frames).padStart(3)} · 间隔 p50 ${String(r.p50).padStart(5)} p95 ${String(r.p95).padStart(6)} 最长 ${String(r.max).padStart(6)} · 掉帧 ${r.dropped} · layout ${String(r.layout).padStart(4)} 次/${String(r.layoutMs).padStart(3)}ms · script ${String(r.scriptMs).padStart(4)}ms · 长帧 ${r.loafN} (最长 ${r.loafMax}ms, 其中排版 ${r.loafStyle}ms)`);
}

const tag = url.includes('macos') ? 'mac' : 'win';
const outFile = `_perf-${CPU}x-${tag}.json`;
fs.writeFileSync(path.join(process.cwd(), outFile), JSON.stringify({ url, cpu: CPU, results }, null, 1));
console.log(`\nCPU 降速 ${CPU}x · 报告 ${outFile}`);

ws.close(); chrome.kill();
await sleep(150);
try { fs.rmSync(profile, { recursive: true, force: true }); } catch {}
process.exit(0);
