// 极简 CDP 截图器：node _shot.mjs <fileUrl> <out.png> [w] [h] [setupFile]
// setupFile 里的 JS 会在截图前在页面里执行（用来点导航、切主题等）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const [,, url, out, wStr = '1440', hStr = '900', setupFile = '', clipStr = ''] = process.argv;
const W = +wStr, H = +hStr;
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PORT = 9333 + Math.floor(Math.random() * 200);
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'zc-shot-'));

const chrome = spawn(CHROME, [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-gpu', '--hide-scrollbars=false',
  '--allow-file-access-from-files', 'about:blank'
], { stdio: 'ignore' });

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function browserWS() {
  for (let i = 0; i < 100; i++) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/version`);
      const j = await r.json();
      if (j.webSocketDebuggerUrl) return j.webSocketDebuggerUrl;
    } catch {}
    await sleep(100);
  }
  throw new Error('chrome ws not ready');
}

const wsUrl = await browserWS();
const ws = new WebSocket(wsUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });

let seq = 0;
const pending = new Map();
const problems = [];
ws.onmessage = ev => {
  const m = JSON.parse(ev.data);
  if (m.method === 'Runtime.exceptionThrown') {
    problems.push(m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text);
  }
  if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') {
    problems.push(m.params.entry.text);
  }
  if (m.id && pending.has(m.id)) {
    const { res, rej } = pending.get(m.id);
    pending.delete(m.id);
    m.error ? rej(new Error(JSON.stringify(m.error))) : res(m.result);
  }
};
function send(method, params = {}, sessionId) {
  const id = ++seq;
  return new Promise((res, rej) => {
    pending.set(id, { res, rej });
    ws.send(JSON.stringify({ id, method, params, sessionId }));
  });
}

const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
const S = (m, p) => send(m, p, sessionId);

await S('Page.enable');
await S('Runtime.enable');
await S('Log.enable');
await S('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: 2, mobile: false });
await S('Page.navigate', { url });
await sleep(700);

if (setupFile) {
  const setup = fs.readFileSync(setupFile, 'utf8');
  const r = await S('Runtime.evaluate', { expression: setup, awaitPromise: true, returnByValue: true });
  if (r.exceptionDetails) console.error('SETUP ERROR:', JSON.stringify(r.exceptionDetails.exception?.description || r.exceptionDetails));
  else if (r.result?.value !== undefined) console.log('setup ->', JSON.stringify(r.result.value));
  await sleep(400);
}

const clip = clipStr ? JSON.parse(clipStr) : null;
const shot = await S('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false, ...(clip ? { clip } : {}) });
fs.writeFileSync(out, Buffer.from(shot.data, 'base64'));
console.log('saved', out);
if (problems.length) console.log('PAGE ERRORS:\n' + problems.join('\n'));

ws.close();
chrome.kill();
await sleep(200);
try { fs.rmSync(profile, { recursive: true, force: true }); } catch {}
process.exit(0);
