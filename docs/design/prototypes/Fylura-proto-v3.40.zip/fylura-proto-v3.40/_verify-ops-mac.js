/* macOS 原型的文件操作回归（Windows 版脚本用 zcPanes，不能直接跑在 mac 上）
 *
 *   node _shot.mjs http://127.0.0.1:4281/redesign-v2-macos.html out.png 1440 900 _verify-ops-mac.js
 *
 * 只覆盖 mac 与 Windows 共用的能力层在 mac 选择模型（FX.sel / FX.last）下的行为：
 *   1. 删除文件夹要连子树（trash / 历史同一批）
 *   2. 剪切到同名目录要出决策，不能产生两个同名
 *   3. 快捷撤销要标历史
 *   4. 篮子：同名不同目录两条 + 从篮子里移出一项
 */
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const out = {};
  const mk = (n, p, extra = {}) => ({
    n, p, k: 'doc', type: '文本文档', t: '刚刚', m: '刚刚', s: '1 KB', c: '刚刚', note: '', ...extra
  });
  const mkdir = (n, p) => mk(n, p, { k: 'folder', type: '文件夹', folder: true, full: p ? p + ' / ' + n : n, s: '—' });
  const pick = o => {
    const i = FILES.indexOf(o);
    if (i < 0) throw new Error('pick: 目标不在 FILES 里');
    FX.sel = new Set([i]);
    FX.last = i;
    fxRender();
    return i;
  };
  const under = root => FILES.filter(x => x.p === root || x.p.startsWith(root + ' / ')).length;

  gotoPage('library');
  await sleep(500);

  /* ---- 1. 删文件夹带子树 ---- */
  const r1 = mkdir('MacDelRoot', 'Documents');
  FILES.push(r1, mkdir('Child', 'Documents / MacDelRoot'), mk('deep.txt', 'Documents / MacDelRoot / Child'));
  fxNav('Documents'); await sleep(220); fxRender();
  pick(r1); await sleep(100);
  const n1 = FILES.length;
  window.zcOps.del(); await sleep(320);
  const removed = n1 - FILES.length;
  const trashN = window.zcOps.trash.length;
  window.zcOps.quickUndo(); await sleep(320);
  out.deleteTree = {
    removed, trashN, back: FILES.length === n1, subtree: under('Documents / MacDelRoot'),
    pass: removed === 3 && trashN >= 3 && FILES.length === n1 && under('Documents / MacDelRoot') === 2
  };

  /* ---- 2. 剪切撞名 → 决策 → 保留两者 ---- */
  const c1 = mk('MacCollision.txt', 'Documents');
  const c2 = mk('MacCollision.txt', 'Teaching');
  FILES.push(c1, c2);
  fxNav('Documents'); await sleep(220); fxRender();
  pick(c1); await sleep(100);
  window.zcOps.setClip('cut');
  fxNav('Teaching'); await sleep(220); fxRender();
  window.zcOps.paste();
  await sleep(420);
  const choice = document.querySelectorAll('.zc-scrim .zc-choice')[0];
  const asked = !!choice;
  if (choice) choice.click();
  await sleep(600);
  const names = FILES.filter(f => f.p === 'Teaching' && f.n.startsWith('MacCollision')).map(f => f.n);
  out.moveConflict = {
    asked, names,
    pass: asked && names.length === 2 && new Set(names).size === 2
  };

  /* ---- 3. 快捷撤销标历史 ---- */
  const u1 = mk('mac-undo.txt', 'Teaching');
  FILES.push(u1);
  fxNav('Teaching'); await sleep(220); fxRender();
  pick(u1); await sleep(100);
  const n3 = FILES.length;
  window.zcOps.del(); await sleep(320);
  const h = zcFlow.HIST.find(e => e.kind === 'delete');
  const ok3 = window.zcOps.quickUndo(); await sleep(320);
  out.quickUndo = {
    ok: ok3, back: FILES.length === n3, marked: !!(h && h.undone),
    pass: ok3 === true && FILES.length === n3 && h && h.undone === true
  };

  /* ---- 4. 篮子：同名不同目录 + 移出一项 ---- */
  const b1 = mk('MacSame.pdf', 'Documents');
  const b2 = mk('MacSame.pdf', 'Teaching');
  FILES.push(b1, b2);
  basket.clear();
  fxNav('Documents'); await sleep(200); fxRender();
  pick(b1); await sleep(80);
  fxBasketAdd(); await sleep(200);
  fxNav('Teaching'); await sleep(200); fxRender();
  pick(b2); await sleep(80);
  fxBasketAdd(); await sleep(200);
  const added = basket.size;

  fxBasketOpen(true);
  await sleep(300);
  const dropBtns = [...document.querySelectorAll('#fxBasket [data-basket-drop]')];
  if (dropBtns[0]) dropBtns[0].click();
  await sleep(250);
  out.basket = {
    added, afterRemove: basket.size, buttons: dropBtns.length,
    pass: added === 2 && basket.size === 1 && dropBtns.length === 2
  };

  out.allPass = Object.keys(out).every(k => k === 'allPass' || out[k].pass !== false);
  return JSON.stringify(out, null, 1);
})()
