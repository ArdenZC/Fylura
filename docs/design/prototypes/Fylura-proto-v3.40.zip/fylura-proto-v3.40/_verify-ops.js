/* 文件操作逻辑回归断言（v3.40）
 *
 *   node _shot.mjs http://127.0.0.1:4281/redesign-v2.html out.png 1440 900 _verify-ops.js
 *
 * 十二组断言，全部走真实入口（ops.setClip / paste / del / quickUndo / rowMenu），
 * 不直接往 Map 里写数据 —— 否则测的是数据结构，不是 UI 路径。
 */
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const out = {};
  const mk = (n, p, extra = {}) => ({
    n, p, k: 'doc', type: '文本文档', t: '刚刚', m: '刚刚', s: '1 KB', c: '刚刚', note: '', ...extra
  });
  const mkdir = (n, p) => mk(n, p, { k: 'folder', type: '文件夹', folder: true, full: p ? p + ' / ' + n : n, s: '—' });
  const under = root => FILES.filter(x => x.p === root || x.p.startsWith(root + ' / '))
    .map(x => x.n + ' @ ' + x.p).sort();
  const namesIn = dir => FILES.filter(f => f.p === dir).map(f => f.n).sort();

  const selectA = o => {
    const i = FILES.indexOf(o);
    if (i < 0) throw new Error('selectA: 目标不在 FILES 里');
    window.paneSel('A').clear();
    window.zcPanes.select('A', i);
    return i;
  };
  const clearClip = () => { window.zcOps.setClip('copy'); };
  const menuItem = txt => [...document.querySelectorAll('.fm-menu button')]
    .find(b => b.textContent.trim().startsWith(txt));

  gotoPage('library');
  await sleep(450);

  /* ============ 1. 复制：三级目录层级 ============ */
  const root = mkdir('ReviewRoot', 'Documents');
  const l2 = mkdir('Level2', 'Documents / ReviewRoot');
  const deep = mk('deep.txt', 'Documents / ReviewRoot / Level2');
  FILES.push(root, l2, deep);
  navigateTo('A', 'Documents'); await sleep(220);
  selectA(root); await sleep(80);
  window.zcOps.setClip('copy');
  navigateTo('A', 'Teaching'); await sleep(220);
  window.zcOps.paste(); await sleep(320);
  const copyTree = under('Teaching / ReviewRoot');
  out.copy = {
    tree: copyTree,
    pass: copyTree.length === 2 &&
      copyTree.includes('Level2 @ Teaching / ReviewRoot') &&
      copyTree.includes('deep.txt @ Teaching / ReviewRoot / Level2')
  };

  /* ============ 2. 移动：三级目录层级 + 无孤儿 ============ */
  const r2 = mkdir('MoveRoot', 'Documents');
  const l3 = mkdir('Inner', 'Documents / MoveRoot');
  const d2 = mk('moved.txt', 'Documents / MoveRoot / Inner');
  FILES.push(r2, l3, d2);
  navigateTo('A', 'Documents'); await sleep(220);
  selectA(r2); await sleep(80);
  window.zcOps.setClip('cut');
  navigateTo('A', 'Teaching'); await sleep(220);
  window.zcOps.paste(); await sleep(320);
  const moveTree = under('Teaching / MoveRoot');
  out.move = {
    tree: moveTree,
    orphan: under('Documents / MoveRoot'),
    pass: moveTree.length === 2 &&
      moveTree.includes('Inner @ Teaching / MoveRoot') &&
      moveTree.includes('moved.txt @ Teaching / MoveRoot / Inner') &&
      under('Documents / MoveRoot').length === 0
  };

  /* ============ 3. 重命名：子项前缀跟着换 ============ */
  const r3 = mkdir('OldName', 'Documents');
  FILES.push(r3, mkdir('Sub', 'Documents / OldName'), mk('inner.txt', 'Documents / OldName / Sub'));
  navigateTo('A', 'Documents'); await sleep(250);
  selectA(r3); await sleep(80);
  window.zcOps.rename(FILES.indexOf(r3));
  await sleep(350);
  const inp = document.getElementById('zcInput');
  if (inp) {
    inp.value = 'NewName';
    [...document.querySelectorAll('.zc-scrim .btn')].find(b => b.textContent.trim() === '重命名')?.click();
  }
  await sleep(520);
  const reTree = under('Documents / NewName');
  out.rename = {
    tree: reTree,
    stale: FILES.filter(x => x.p && x.p.includes('OldName')).map(x => x.n),
    pass: reTree.length === 2 &&
      reTree.includes('Sub @ Documents / NewName') &&
      reTree.includes('inner.txt @ Documents / NewName / Sub') &&
      !FILES.some(x => x.p && x.p.includes('OldName'))
  };

  /* ============ 4. 删除文件夹：子树一起走、一起回来 ============ */
  const r4 = mkdir('DelRoot', 'Documents');
  FILES.push(r4, mkdir('Child', 'Documents / DelRoot'), mk('deep.txt', 'Documents / DelRoot / Child'));
  navigateTo('A', 'Documents'); await sleep(250);
  selectA(r4); await sleep(100);
  const n4 = FILES.length;
  window.zcOps.del(); await sleep(320);
  const afterDelTree = FILES.length;
  const trashN = window.zcOps.trash.length;
  window.zcOps.quickUndo(); await sleep(320);
  out.deleteTree = {
    removed: n4 - afterDelTree,
    trashN,
    restoredAll: FILES.length === n4,
    subtreeBack: under('Documents / DelRoot').length,
    pass: (n4 - afterDelTree) === 3 && trashN >= 3 &&
      FILES.length === n4 && under('Documents / DelRoot').length === 2
  };

  /* ============ 5. 快捷撤销同步历史 ============ */
  navigateTo('A', 'Documents'); await sleep(250);
  const victim = mk('undo-single.txt', 'Documents');
  FILES.push(victim);
  selectA(victim); await sleep(100);
  const n5 = FILES.length;
  window.zcOps.del(); await sleep(320);
  const hDel = zcFlow.HIST.find(h => h.kind === 'delete');
  const ok5 = window.zcOps.quickUndo(); await sleep(320);
  out.quickUndo = {
    undoOk: ok5,
    restoredAll: FILES.length === n5,
    histMarked: !!(hDel && hDel.undone),
    pass: ok5 === true && FILES.length === n5 && hDel && hDel.undone === true
  };

  /* ============ 6. 撤销链：先撤较早，最新那条还能撤 ============ */
  const u1 = mk('undo-a.txt', 'Teaching');
  const u2 = mk('undo-b.txt', 'Teaching');
  FILES.push(u1, u2);
  navigateTo('A', 'Teaching'); await sleep(250);
  const n6a = FILES.length;
  selectA(u1); await sleep(100); window.zcOps.del(); await sleep(320);
  const del1 = n6a - FILES.length;
  const n6b = FILES.length;
  selectA(u2); await sleep(100); window.zcOps.del(); await sleep(320);
  const del2 = n6b - FILES.length;
  const n6 = FILES.length;
  gotoPage('history'); await sleep(400);
  const undos = [...document.querySelectorAll('.hs-undo')];
  if (undos[1]) undos[1].click();
  await sleep(750);
  gotoPage('library'); await sleep(320);
  const ok6 = window.zcOps.quickUndo(); await sleep(320);
  out.undoChain = {
    undos: undos.length, quickOk: ok6, del1, del2,
    delta: FILES.length - n6,
    pass: undos.length >= 2 && ok6 === true && (FILES.length - n6) === del1 + del2
  };

  /* ============ 7. 剪贴板：插入干扰项后仍指向原对象 ============ */
  navigateTo('A', 'Teaching'); await sleep(250);
  const target7 = mk('clip-target.txt', 'Teaching');
  FILES.push(target7);
  selectA(target7); await sleep(100);
  window.zcOps.setClip('copy');
  FILES.unshift(mk('intruder.txt', 'Documents'));
  render(); await sleep(180);
  navigateTo('A', 'Documents'); await sleep(250);
  window.zcOps.paste(); await sleep(320);
  const arrived7 = FILES[FILES.length - 1];
  out.clipIdentity = {
    expect: target7.n,
    got: arrived7 ? arrived7.n : 'none',
    pass: !!arrived7 && arrived7.n === target7.n
  };

  /* ============ 8. 剪贴板：删掉原文件再建同名，不能认领新对象 ============ */
  const s1 = mk('SameIdentity.txt', 'Documents', { note: 'A' });
  FILES.push(s1);
  navigateTo('A', 'Documents'); await sleep(250);
  selectA(s1); await sleep(100);
  window.zcOps.setClip('copy');
  const k8 = FILES.indexOf(s1);
  if (k8 >= 0) FILES.splice(k8, 1);
  const s2 = mk('SameIdentity.txt', 'Documents', { note: 'B' });
  FILES.push(s2);
  navigateTo('A', 'Teaching'); await sleep(250);
  window.zcOps.paste(); await sleep(350);
  out.clipStale = {
    pasted: FILES.some(f => f.p === 'Teaching' && f.n === 'SameIdentity.txt'),
    pass: !FILES.some(f => f.p === 'Teaching' && f.n === 'SameIdentity.txt')
  };

  /* ============ 9. 移动撞名：不能出现两个同名 ============ */
  const c1 = mk('CollisionTrace.txt', 'Documents');
  const c2 = mk('CollisionTrace.txt', 'Teaching');
  FILES.push(c1, c2);
  navigateTo('A', 'Documents'); await sleep(250);
  selectA(c1); await sleep(100);
  window.zcOps.setClip('cut');
  navigateTo('A', 'Teaching'); await sleep(250);
  window.zcOps.paste();
  await sleep(400);
  const choice = document.querySelectorAll('.zc-scrim .zc-choice')[0];
  const asked = !!choice;
  if (choice) choice.click();
  await sleep(600);
  const collisionNames = FILES.filter(f => f.p === 'Teaching' && f.n.startsWith('CollisionTrace')).map(f => f.n);
  out.moveConflict = {
    asked,
    names: collisionNames,
    pass: asked && collisionNames.length === 2 && new Set(collisionNames).size === 2
  };

  /* ============ 10. 复制到自身后代：拦下，不产生套娃 ============ */
  const r10 = mkdir('SelfRoot', 'Documents');
  const sub10 = mkdir('Sub', 'Documents / SelfRoot');
  FILES.push(r10, sub10);
  navigateTo('A', 'Documents'); await sleep(250);
  selectA(r10); await sleep(100);
  window.zcOps.setClip('copy');
  navigateTo('A', 'Documents / SelfRoot / Sub'); await sleep(250);
  window.zcOps.paste(); await sleep(350);
  const nest = FILES.filter(f => f.p.startsWith('Documents / SelfRoot')).length;
  out.copySelfNest = {
    entries: nest,
    pass: nest === 1        /* 只有 Sub 自己，没有新副本 */
  };

  /* ============ 11. 篮子：同名不同目录（走真实数据） ============ */
  const b1 = mk('UNIQUE_BASKET.pdf', 'Documents');
  const b2 = mk('UNIQUE_BASKET.pdf', 'Teaching');
  FILES.push(b1, b2);
  basket.clear();
  window.rowMenu(200, 200, FILES.indexOf(b1), 'A');
  await sleep(220);
  menuItem('加入篮子')?.click();
  await sleep(220);
  window.rowMenu(200, 200, FILES.indexOf(b2), 'A');
  await sleep(220);
  menuItem('加入篮子')?.click();
  await sleep(260);
  const savedRaw = localStorage.getItem('fylura:basket');
  out.basketRowMenu = {
    size: basket.size,
    saved: JSON.parse(savedRaw || '[]').length,
    pass: basket.size === 2 && JSON.parse(savedRaw || '[]').length === 2
  };

  /* ============ 12. 顶层「加入篮子」按钮同样走新键 ============ */
  basket.clear();
  navigateTo('A', 'Documents'); await sleep(220);
  selectA(b1); await sleep(100);
  addToBasket();
  await sleep(200);
  navigateTo('A', 'Teaching'); await sleep(220);
  selectA(b2); await sleep(100);
  addToBasket();
  await sleep(200);
  out.basketToolbar = { size: basket.size, pass: basket.size === 2 };

  out.allPass = Object.keys(out).every(k => k === 'allPass' || out[k].pass !== false);
  return JSON.stringify(out, null, 1);
})()
