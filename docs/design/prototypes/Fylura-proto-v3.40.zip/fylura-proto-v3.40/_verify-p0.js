/* 三个 P0 的回归断言（配合 _shot.mjs 或 _walk.mjs --flow 使用）
 *
 *   node _shot.mjs http://127.0.0.1:4281/redesign-v2.html out.png 1440 900 _verify-p0.js
 *
 * 判据：
 *   1. 四宫格聚焦 C 格，选中一项后复制 → 剪贴板的文件必须是 C 格选中的那个
 *   2. 连删两个文件，撤销**较早**那一次 → 只恢复 1 个、回收站剩 1 个、
 *      较早条目 undone=true、最近条目仍为 false
 *   3. 文件名含 `<img onerror>` → 列表与网格都按文本渲染，不生成元素、不执行脚本
 */
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const out = {};
  gotoPage('library');
  await sleep(400);

  /* ---------- P0-1 多窗格：操作必须跟着焦点窗格 ---------- */
  zcPanes.setLayout('4');
  await sleep(600);
  window.focusPane('C');
  await sleep(80);
  const rowsC = [...document.querySelectorAll('#rowsC .row')];
  if (rowsC[2]) rowsC[2].click();
  await sleep(150);
  window.zcOps.setClip('copy');
  await sleep(120);
  /* v3.40 起剪贴板内部是 {ref,id} 包装，用 clipFiles 拿文件对象 */
  const clipNames = window.zcOps.clipFiles.map(f => f.n);
  const cSelNames = (window.paneSel('C').size ? [...window.paneSel('C')] : [window.paneCur('C')])
    .filter(i => i != null).map(i => FILES[i].n);
  out.p0_1 = {
    focus: window.focus,
    clip: clipNames,
    paneC: cSelNames,
    pass: clipNames.length > 0 && JSON.stringify(clipNames) === JSON.stringify(cSelNames)
  };

  /* ---------- P0-3 注入：名字当文本，不当标记 ---------- */
  zcPanes.setLayout('1');
  await sleep(500);
  window.focusPane('A');
  await sleep(80);
  const pA = window.paneState('A').path;
  const iT = FILES.findIndex(f => f.p === pA && !f.folder);
  const keepName = FILES[iT].n;
  FILES[iT].n = '<img src=x onerror="window.__pwned=1">.txt';
  render();
  await sleep(250);
  const listEl = document.getElementById('rows');
  const listInjected = !!listEl.querySelector('img, script');
  const listRaw = listEl.textContent.includes('<img src=x');
  document.getElementById('viewA').click();
  await sleep(400);
  const gridEl = document.getElementById('rows');
  const gridInjected = !!gridEl.querySelector('img, script');
  const gridRaw = gridEl.textContent.includes('<img src=x');
  out.p0_3 = {
    listInjected, listRaw, gridInjected, gridRaw,
    pwned: !!window.__pwned,
    pass: !listInjected && !gridInjected && !window.__pwned && listRaw && gridRaw
  };
  FILES[iT].n = keepName;
  document.getElementById('viewA').click();
  render();
  await sleep(250);

  /* ---------- P0-2 历史：撤销只回滚那一次删除 ---------- */
  window.focusPane('A');
  await sleep(80);
  const before = FILES.length;
  selectOne(0); await sleep(100); window.zcOps.del(); await sleep(300);
  selectOne(0); await sleep(100); window.zcOps.del(); await sleep(300);
  const afterSecond = FILES.length;
  const delHist = zcFlow.HIST.filter(h => h.kind === 'delete');
  gotoPage('history');
  await sleep(400);
  const undos = [...document.querySelectorAll('.hs-undo')];
  /* HIST 最新在前：undos[1] 是较早那次 */
  if (undos[1]) undos[1].click();
  await sleep(800);
  const recovered = FILES.length - afterSecond;
  const states = delHist.slice(0, 2).map(h => ({ title: h.title, undone: !!h.undone }));
  out.p0_2 = {
    before, afterSecond, recovered,
    trashLeft: window.zcOps.trash.length,
    states,
    pass: recovered === 1 && window.zcOps.trash.length === 1 &&
          states.length === 2 && states[0].undone === false && states[1].undone === true
  };

  out.allPass = out.p0_1.pass && out.p0_2.pass && out.p0_3.pass;
  return JSON.stringify(out, null, 1);
})()
