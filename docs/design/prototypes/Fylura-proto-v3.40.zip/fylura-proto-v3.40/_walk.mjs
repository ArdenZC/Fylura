// 点击走查器：node _walk.mjs <url> <outDir> [--dead] [--flow=file.mjs] [--w=1440] [--h=900]
// --dead  逐页枚举可见按钮，逐个点击，判定「点了没反应」
// --flow  按脚本顺序点完整业务流程，每步截图
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const args = process.argv.slice(2);
const url = args[0];
const outDir = args[1] || 'walk';
const flag = k => args.find(a => a.startsWith('--' + k + '='))?.split('=')[1];
const has = k => args.includes('--' + k);
const W = +(flag('w') || 1440), H = +(flag('h') || 900);
const MODE = has('dead') ? 'dead' : 'flow';
const FLOW = flag('flow');

fs.mkdirSync(path.join(outDir, 'steps'), { recursive: true });

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PORT = 9500 + Math.floor(Math.random() * 300);
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'zc-walk-'));
const chrome = spawn(CHROME, [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-gpu',
  '--allow-file-access-from-files', '--force-color-profile=srgb', 'about:blank'
], { stdio: 'ignore' });

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function browserWS() {
  for (let i = 0; i < 120; i++) {
    try {
      const j = await (await fetch(`http://127.0.0.1:${PORT}/json/version`)).json();
      if (j.webSocketDebuggerUrl) return j.webSocketDebuggerUrl;
    } catch {}
    await sleep(100);
  }
  throw new Error('chrome ws not ready');
}

const wsUrl = await browserWS();
const ws = new WebSocket(wsUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });

let seq = 0;
const pending = new Map();
let errs = [];
ws.onmessage = ev => {
  const m = JSON.parse(ev.data);
  if (m.method === 'Runtime.exceptionThrown') {
    const d = m.params.exceptionDetails;
    errs.push((d.exception?.description || d.text || '').split('\n')[0]);
  }
  if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') errs.push(m.params.entry.text);
  if (m.id && pending.has(m.id)) {
    const { res, rej } = pending.get(m.id);
    pending.delete(m.id);
    m.error ? rej(new Error(JSON.stringify(m.error))) : res(m.result);
  }
};
function send(method, params = {}, sessionId) {
  const id = ++seq;
  return new Promise((res, rej) => { pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params, sessionId })); });
}

const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
const S = (m, p) => send(m, p, sessionId);

await S('Page.enable'); await S('Runtime.enable'); await S('Log.enable');
await S('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: 1, mobile: false });

async function evaluate(expr) {
  const r = await S('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
  if (r.exceptionDetails) return { __err: (r.exceptionDetails.exception?.description || r.exceptionDetails.text || '').split('\n')[0] };
  return r.result?.value;
}
async function shot(file) {
  const s = await S('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  fs.writeFileSync(file, Buffer.from(s.data, 'base64'));
}

// 页面内快照：body 结构哈希 + 活动页 + 滚动位置 + toast
const SNAP = `(() => {
  const h = document.body.innerHTML;
  let x = 0;
  for (let i = 0; i < h.length; i++) { x = (x * 31 + h.charCodeAt(i)) | 0; }
  const sc = [...document.querySelectorAll('.table,.wrap,.fx-body,.set-scroll,.rows')]
    .map(e => e.scrollTop | 0).join(',');
  const t = document.querySelector('.fm-toast');
  return [x, document.documentElement.className, document.body.className,
          document.querySelector('.page.active')?.id || '', sc,
          t && t.classList.contains('show') ? t.textContent : '',
          window.scrollY | 0].join('|');
})()`;

// 枚举：当前活动页内可见、可点的控件
const LIST = `(() => {
  const page = document.querySelector('.page.active');
  if (!page) return [];
  const sel = 'button, [role="option"], [role="tab"], [role="radio"], .chip, .cand, .seg button, .row, .card-row, [data-goto], [onclick]';
  const all = [...page.querySelectorAll(sel)];
  const out = [];
  all.forEach((el, i) => {
    const r = el.getBoundingClientRect();
    if (r.width < 8 || r.height < 8) return;
    if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return;
    const st = getComputedStyle(el);
    if (st.visibility === 'hidden' || st.display === 'none' || st.opacity === '0') return;
    // 被浮层盖住的跳过
    const cx = Math.max(1, r.left + Math.min(r.width / 2, 20));
    const cy = Math.max(1, r.top + Math.min(r.height / 2, 10));
    const top = document.elementFromPoint(cx, cy);
    if (top && !el.contains(top) && top !== el) return;
    const txt = (el.innerText || el.getAttribute('aria-label') || el.title || '').replace(/\\s+/g, ' ').trim().slice(0, 28);
    out.push({ i, txt, cls: el.className.toString().slice(0, 40), tag: el.tagName, disabled: el.disabled === true || el.getAttribute('aria-disabled') === 'true' });
  });
  return out;
})()`;

function clickIdx(i) {
  return `(() => {
    const page = document.querySelector('.page.active');
    const sel = 'button, [role="option"], [role="tab"], [role="radio"], .chip, .cand, .seg button, .row, .card-row, [data-goto], [onclick]';
    const el = page.querySelectorAll(sel)[${i}];
    if (!el) return 'missing';
    el.scrollIntoView({block:'nearest'});
    el.click();
    return 'ok';
  })()`;
}

const report = { url, mode: MODE, pages: [], steps: [], dead: [], errors: [] };
const PAGES = ['overview', 'library', 'organize', 'dryrun', 'cleanup', 'history', 'spec', 'settings'];

if (MODE === 'dead') {
  for (const page of PAGES) {
    await S('Page.navigate', { url });
    await sleep(700);
    errs = [];
    await evaluate(`gotoPage(${JSON.stringify(page)})`);
    await sleep(250);
    const list = await evaluate(LIST);
    const rows = [];
    for (const item of list) {
      // 禁用态不是「无反应」，是不适用；单独计数，不混进死按钮清单
      if (item.disabled) { rows.push({ page, txt: item.txt, disabled: true }); continue; }
      // 每次点击前重置：同一个页面，DOM 干净
      await S('Page.navigate', { url });
      await sleep(500);
      errs = [];
      await evaluate(`gotoPage(${JSON.stringify(page)})`);
      await sleep(200);
      const before = await evaluate(SNAP);
      const r = await evaluate(clickIdx(item.i));
      await sleep(360);
      const after = await evaluate(SNAP);
      const dead = before === after;
      const o = { page, txt: item.txt, cls: item.cls, tag: item.tag, dead, err: errs.slice(0, 2) };
      rows.push(o);
      if (dead) {
        const f = path.join(outDir, 'steps', `dead-${page}-${item.i}.png`);
        await shot(f);
        o.shot = f;
        report.dead.push(o);
      }
      if (errs.length) report.errors.push({ page, txt: item.txt, err: errs.slice(0, 3) });
      await evaluate(`document.querySelector('.fm-toast')?.classList.remove('show')`);
    }
    report.pages.push({ page, count: list.length, disabled: rows.filter(r => r.disabled).length, rows });
    console.log(`[${page}] ${list.length} 个控件，禁用 ${rows.filter(r => r.disabled).length}，死按钮 ${rows.filter(r => r.dead).length}`);
  }
} else {
  const flow = (await import(pathToFileURL(path.resolve(FLOW)).href)).default;
  await S('Page.navigate', { url });
  await sleep(900);
  for (let k = 0; k < flow.length; k++) {
    errs = [];
    const step = flow[k];
    const before = await evaluate(SNAP);
    const r = await evaluate(step.js);
    await sleep(step.wait ?? 420);
    const after = await evaluate(SNAP);
    const name = String(k + 1).padStart(2, '0') + '-' + (step.name || 'step').replace(/[^\w\u4e00-\u9fa5-]+/g, '_');
    const f = path.join(outDir, 'steps', name + '.png');
    await shot(f);
    const rec = { k: k + 1, name: step.name, r, changed: before !== after, err: errs.slice(0, 3), shot: f, note: step.note || '' };
    report.steps.push(rec);
    if (r && r.__err) console.log(`  ✗ ${step.name} → ${r.__err}`);
    if (errs.length) console.log(`  ! ${step.name} → ${errs[0]}`);
    if (!rec.changed) console.log(`  · ${step.name} → 无变化`);
  }
}

fs.writeFileSync(path.join(outDir, 'walk.json'), JSON.stringify(report, null, 1));
if (report.dead.length) {
  console.log('\n=== 点了没反应 ===');
  report.dead.forEach(d => console.log(`[${d.page}] ${d.txt}  (${d.cls})`));
}
if (report.errors.length) {
  console.log('\n=== 报错 ===');
  report.errors.forEach(d => console.log(`[${d.page}] ${d.txt} → ${d.err.join(' | ')}`));
}
console.log('\n报告:', path.join(outDir, 'walk.json'));

ws.close(); chrome.kill();
await sleep(150);
try { fs.rmSync(profile, { recursive: true, force: true }); } catch {}
process.exit(0);
