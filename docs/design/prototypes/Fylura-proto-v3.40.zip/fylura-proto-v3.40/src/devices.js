/* ===================== 外部存储 =====================
   移动硬盘 / SD 卡 / NAS / 手机 / 云盘：设备状态机 + 换入流程。
   两套原型共用这一份数据与逻辑；侧栏与工具栏由各平台自己渲染。

   状态：mounted（已连接）/ readonly（只读）/ mounting（连接中）/ ejecting（弹出中）
        offline（已断开）/ signedout（云盘未登录）/ signingin（登录中）
   ================================================== */
(function () {
  'use strict';
  if (window.__zcDevices) return;
  window.__zcDevices = true;

  const GB = 1024;
  const flow = () => window.zcFlow || {};

  /* ---------------- 设备 ---------------- */
  const DEVS = [
    { id: 't7', name: '移动硬盘 T7', kind: 'usb', bus: 'USB-C · 10 Gb/s',
      total: 2048, used: 1408, state: 'mounted', ejectable: true, mount: '移动硬盘 T7',
      note: '便携 SSD' },
    { id: 'sd', name: 'SD 卡 (相机)', kind: 'sd', bus: 'UHS-II · 写保护',
      total: 128, used: 116, state: 'readonly', ejectable: true, mount: 'SD 卡',
      note: '索尼 A7M4' },
    { id: 'nas', name: '工作室 NAS', kind: 'nas', bus: 'SMB 3 · 2.5GbE',
      total: 4096, used: 2290, state: 'mounted', ejectable: false, mount: '工作室 NAS',
      note: '局域网' },
    { id: 'pixel', name: 'Pixel 8', kind: 'phone', bus: 'MTP · 320 张照片',
      total: 128, used: 92, state: 'mounted', ejectable: true, mount: 'Pixel 8',
      note: 'Android 16' },
    { id: 'dropbox', name: 'Dropbox', kind: 'cloud', bus: '个人版 · 按需文件',
      total: 2048, used: 612, state: 'signedout', ejectable: false, mount: 'Dropbox',
      note: '云盘' }
  ];
  const byId = id => DEVS.find(d => d.id === id) || null;
  const isOpen = d => d && (d.state === 'mounted' || d.state === 'readonly');
  const canImport = d => isOpen(d);

  /* ---------------- 设备内容（挂到同一份 FILES 上） ---------------- */
  const SEED = [
    ['t7', '移动硬盘 T7', '换机备份 2026.zip', 'zip', '压缩包', '18.4 GB', '11 月 9 日'],
    ['t7', '移动硬盘 T7 / DCIM', 'DSC-0931.ARW', 'img', 'RAW', '48.6 MB', '今天 09:41'],
    ['t7', '移动硬盘 T7 / DCIM', 'DSC-0932.ARW', 'img', 'RAW', '47.9 MB', '今天 09:42'],
    ['t7', '移动硬盘 T7 / DCIM', 'MVI-0933.MP4', 'video', 'Video', '312 MB', '今天 09:44'],
    ['t7', '移动硬盘 T7 / Projects', 'Fine-cut-v4.prproj', 'deck', 'Premiere', '82 MB', '11 月 8 日'],
    ['t7', '移动硬盘 T7 / Projects', 'Broll-0928.mp4', 'video', 'Video', '1.4 GB', '11 月 8 日'],

    ['sd', 'SD 卡 / DCIM', 'DSC-1001.ARW', 'img', 'RAW', '49.2 MB', '今天 08:12'],
    ['sd', 'SD 卡 / DCIM', 'DSC-1002.ARW', 'img', 'RAW', '48.8 MB', '今天 08:13'],
    ['sd', 'SD 卡 / DCIM', 'DSC-1003.JPG', 'img', 'JPEG', '8.4 MB', '今天 08:13'],
    ['sd', 'SD 卡 / DCIM', 'CLIP-1004.MP4', 'video', 'Video', '624 MB', '今天 08:20'],

    ['nas', '工作室 NAS / 设计档案', 'Brand book 2026.pdf', 'pdf', 'PDF', '36.2 MB', '11 月 6 日'],
    ['nas', '工作室 NAS / 设计档案', 'logo-final.ai', 'doc', 'Illustrator', '12.6 MB', '11 月 4 日'],
    ['nas', '工作室 NAS / 设计档案', '官网改版-v3.fig', 'doc', 'Figma', '88 MB', '11 月 2 日'],
    ['nas', '工作室 NAS / 素材库', '配乐-授权清单.xlsx', 'sheet', 'Excel', '204 KB', '10 月 30 日'],

    ['pixel', 'Pixel 8 / Camera', 'PXL_1112_0845.jpg', 'img', 'JPEG', '4.2 MB', '昨天 08:45'],
    ['pixel', 'Pixel 8 / Camera', 'PXL_1112_0902.jpg', 'img', 'JPEG', '3.8 MB', '昨天 09:02'],
    ['pixel', 'Pixel 8 / Camera', 'PXL_1112_1830.mp4', 'video', 'Video', '96 MB', '昨天 18:30'],

    ['dropbox', 'Dropbox / 团队共享', 'Q4 预算.xlsx', 'sheet', 'Excel', '386 KB', '今天 11:20', true],
    ['dropbox', 'Dropbox / 团队共享', '品牌规范.pdf', 'pdf', 'PDF', '12.4 MB', '11 月 7 日'],
    ['dropbox', 'Dropbox / 团队共享', '客户反馈-1105.md', 'doc', 'Markdown', '18 KB', '11 月 5 日', true]
  ];

  function seedFiles() {
    if (typeof FILES === 'undefined') return;
    if (FILES.some(f => f.dev)) return;
    SEED.forEach(([dev, p, n, k, type, s, t, cloud]) => {
      FILES.push({ n, p, k, type, s, t, m: t, c: t, dev, cloud: !!cloud,
        note: cloud ? '只在云端，打开时按需下载。' : '外部设备上的文件。' });
    });
  }

  /* 路径 → 设备（最长前缀匹配） */
  function devOfPath(path) {
    if (!path) return null;
    let hit = null;
    DEVS.forEach(d => {
      if (path === d.mount || path.indexOf(d.mount + ' / ') === 0) {
        if (!hit || d.mount.length > hit.mount.length) hit = d;
      }
    });
    return hit;
  }

  /* ---------------- 宿主钩子 ---------------- */
  const H = {
    toast: m => { if (typeof showToast === 'function') showToast(m); },
    redraw: () => {},
    openPath: () => {},
    historyPush: () => {},
    panePaths: () => []
  };
  let listeners = [];
  const emit = what => listeners.forEach(fn => { try { fn(what); } catch (_e) {} });

  function configure(h) { Object.assign(H, h || {}); }
  function onChange(fn) { if (typeof fn === 'function') listeners.push(fn); }

  /* ---------------- 格式化 ---------------- */
  const gb = n => n >= 1024 ? (n / 1024).toFixed(1).replace(/\.0$/, '') + ' TB'
    : n >= 1 ? Math.round(n) + ' GB'
    : Math.round(n * 1024) + ' MB';
  const bytesOf = s => {
    if (!s || s === '—') return 0;
    const v = parseFloat(s);
    if (!isFinite(v)) return 0;
    if (/TB/i.test(s)) return v * GB;
    if (/GB/i.test(s)) return v;
    if (/MB/i.test(s)) return v / GB;
    if (/KB/i.test(s)) return v / GB / GB;
    return 0;
  };

  /* ---------------- 状态迁移 ---------------- */
  const wait = ms => new Promise(r => setTimeout(r, (matchMedia('(prefers-reduced-motion: reduce)').matches ? 60 : ms)));

  async function connect(id) {
    const d = byId(id);
    if (!d || isOpen(d) || d.state === 'mounting') return;
    if (d.state === 'signedout') return signIn(id);
    const prev = d.state;
    d.state = 'mounting';
    emit('state');
    await wait(1200);
    d.state = (prev === 'readonly') ? 'readonly' : 'mounted';
    emit('state');
    H.toast(d.name + ' 已连接');
  }

  async function signIn(id) {
    const d = byId(id);
    if (!d || d.state === 'signingin') return;
    d.state = 'signingin';
    emit('state');
    await wait(1400);
    d.state = 'mounted';
    d.signed = true;
    emit('state');
    H.toast('已登录 ' + d.name + ' · 可用 ' + gb(d.total - d.used));
  }

  async function eject(id) {
    const d = byId(id);
    if (!d || !isOpen(d)) return;
    const Z = flow();
    if (!Z.zcConfirm) return;
    const inside = H.panePaths().filter(p => devOfPath(p) === d).length;
    const ok = await Z.zcConfirm({
      title: '安全弹出 ' + d.name + '？',
      sub: '弹出后设备上的文件不会被改动，正在写入的内容会先写完。',
      body: inside
        ? '<div class="zc-note">有 ' + inside + ' 个窗格正在浏览这个设备，弹出后它们会显示为「设备已断开」。</div>'
        : '',
      ok: '安全弹出'
    });
    if (!ok) return;
    const prev = d.state;
    d.state = 'ejecting';
    emit('state');
    await wait(1100);
    d.state = 'offline';
    d.prev = prev;
    d.lastAt = '刚刚';
    emit('state');
    H.toast('已安全弹出 · 现在可以拔下 ' + d.name);
  }

  /* ---------------- 换入（复制 + 校验） ---------------- */
  const TARGETS = [
    { label: '工作区', desc: 'Documents / Workspace', path: 'Documents / Workspace' },
    { label: '图片', desc: 'Assets / Photos', path: 'Assets / Photos' },
    { label: '归档', desc: 'Documents / Archive', path: 'Documents / Archive' }
  ];

  async function importFrom(id) {
    const d = byId(id);
    const Z = flow();
    if (!d || !canImport(d) || !Z.zcPick) { H.toast('这个设备现在不可用'); return; }
    const src = FILES.map((f, i) => ({ f, i })).filter(x => x.f.dev === d.id && !x.f.folder);
    if (!src.length) { H.toast('这个设备里没有可换入的文件'); return; }
    const total = src.reduce((n, x) => n + bytesOf(x.f.s), 0);

    const pick = await Z.zcPick({
      title: '换入到哪个文件夹？',
      sub: d.name + ' · ' + src.length + ' 个文件 · ' + gb(total),
      items: TARGETS.map(t => ({ label: t.label, desc: t.desc }))
    });
    if (pick == null) return;
    const target = TARGETS[pick];

    const ro = d.state === 'readonly';
    const ok = await Z.zcConfirm({
      title: '换入 ' + src.length + ' 个文件？',
      sub: '只复制，不会删除设备上的原文件。',
      body: '<div class="zc-note">目标：' + target.path + (ro ? '　·　' + d.name + ' 是只读的，只能读取' : '') + '</div>',
      ok: '开始换入'
    });
    if (!ok) return;

    const res = await Z.zcRun({
      title: '正在换入 ' + src.length + ' 个文件',
      sub: '先复制，再逐个校验大小。设备不会被写入。',
      items: src.map(x => ({ n: x.f.n, m: '→ ' + target.label })),
      verb: '复制中',
      doneTitle: src.length + ' 个文件已换入',
      doneBody: '已逐个校验，' + gb(total) + ' 与设备上一致。原文件仍在 ' + d.name + ' 上。',
      cta: '打开目标文件夹'
    });
    if (res && res.failed && res.failed.length) return;

    const names = [];
    src.forEach(x => {
      const f = x.f;
      names.push(f.n);
      FILES.push({ ...f, p: target.path, dev: null, cloud: false, t: '刚刚', m: '刚刚',
        from: d.name, note: '从 ' + d.name + ' 换入，已校验。' });
    });
    H.historyPush({
      kind: 'index',
      title: '从 ' + d.name + ' 换入 ' + names.length + ' 个文件',
      meta: ['刚刚', target.label, '已校验', gb(total)],
      undo: false
    });
    H.redraw();
    H.openPath(target.path);
    H.toast('已换入 ' + names.length + ' 个文件到 ' + target.label);
    emit('state');
  }

  /* ---------------- 云盘：按需下载 ---------------- */
  async function download(name) {
    const f = FILES.find(x => x.n === name && x.cloud);
    if (!f) return false;
    H.toast('正在从云端下载 ' + f.n);
    await wait(900);
    f.cloud = false;
    f.t = '刚刚'; f.m = '刚刚';
    f.note = '已下载到本机。';
    H.redraw();
    H.toast('已下载 ' + f.n);
    return true;
  }

  seedFiles();

  window.zcDevices = {
    list: () => DEVS.slice(),
    get: byId,
    isOpen, canImport, devOfPath, configure, onChange, emit,
    connect, eject, signIn, importFrom, download,
    gb, bytesOf,
    /* 走查用 */
    _set(id, patch) { const d = byId(id); if (d) { Object.assign(d, patch); emit('state'); } }
  };
})();
