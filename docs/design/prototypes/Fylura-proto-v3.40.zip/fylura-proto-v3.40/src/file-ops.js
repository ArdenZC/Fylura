/* ===== 文件操作（两套原型共用）=====
   数据模型只有一份：FILES，每个条目带 p（所在目录）。
   平台差异用 adapter 注入：当前路径、选中项、重绘、toast。
   这样 Windows 与 macOS 的文件页形态可以不同（9.8 的「平台层」），
   但新建/复制/剪切/粘贴/重命名/反选/打开方式/收藏这些能力是同一套实现。 */
(function () {
  'use strict';
  const flow = window.zcFlow || {};
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  let A = null;                                     /* adapter */
  let clip = null;                                  /* { mode:'copy'|'cut', ids:[] } */
  const favs = new Set(['Documents / Workspace', 'Teaching / 2026 Autumn']);

  const path = () => (A ? A.path() : '');
  const toast = m => { if (A && A.toast) A.toast(m); };

  /* 「创建副本」：一定带「副本」后缀 */
  function suffixName(dir, base) {
    const dot = base.lastIndexOf('.');
    const stem = dot > 0 ? base.slice(0, dot) : base;
    const ext = dot > 0 ? base.slice(dot) : '';
    let n = stem + ' 副本' + ext, i = 2;
    while (FILES.some(f => f.p === dir && f.n === n)) { n = stem + ' 副本 ' + i + ext; i++; }
    return n;
  }
  /* 「粘贴到别的目录」：先试原名，撞名才加后缀。
     原来复用「副本」逻辑，跨目录粘贴会被无脑改名成「xxx 副本」—— 用户只是想搬一份过去。 */
  function uniqueIn(dir, base) {
    if (!FILES.some(f => f.p === dir && f.n === base)) return base;
    return suffixName(dir, base);
  }

  /* 名称校验：渲染层已经转义，这里再从入口挡一层。
     Windows/macOS 的文件系统本身不允许这些字符，原型以前是「能输进去、能显示、
     能拼进 innerHTML」，等于把一条注入路径留在了演示里。 */
  const ILLEGAL = /[\\/:*?"<>|]/;
  function nameError(name) {
    const n = String(name || '');
    if (!n.trim()) return '名称不能为空';
    if (ILLEGAL.test(n)) return '名称不能包含 \\ / : * ? " < > |';
    if (/[. ]$/.test(n)) return '名称不能以空格或句点结尾';
    if (n === '.' || n === '..') return '这个名称不可用';
    if (n.length > 128) return '名称太长（上限 128 个字符）';
    return '';
  }

  /* ---------- 创建 ---------- */
  async function newFile() {
    if (!flow.zcPrompt) return;
    const name = await flow.zcPrompt({
      title: '新建文件', sub: '建在「' + (path() || '本机') + '」',
      value: '未命名文档.txt', ok: '创建'
    });
    if (!name) return;
    const e1 = nameError(name);
    if (e1) return toast(e1);
    if (FILES.some(f => f.p === path() && f.n === name)) return toast('这个目录里已经有同名文件');
    const item = { n: name, p: path(), k: 'doc', type: '文本文档', t: '刚刚', m: '刚刚', s: '0 KB', c: '刚刚', note: '新建文件，还没有内容' };
    FILES.push(item);
    A.redraw();
    A.select(FILES.indexOf(item));
    toast('已创建 ' + name);
  }

  async function newFolder() {
    if (!flow.zcPrompt) return;
    const name = await flow.zcPrompt({
      title: '新建文件夹', sub: '建在「' + (path() || '本机') + '」',
      value: '新建文件夹', ok: '创建'
    });
    if (!name) return;
    const e2 = nameError(name);
    if (e2) return toast(e2);
    if (FILES.some(f => f.p === path() && f.n === name)) return toast('这个目录里已经有同名项目');
    const item = {
      n: name, p: path(), k: 'folder', type: '文件夹', t: '刚刚', m: '刚刚', s: '—', c: '刚刚',
      folder: true, full: (path() ? path() + ' / ' : '') + name, note: '新建文件夹'
    };
    FILES.push(item);
    A.redraw();
    A.select(FILES.indexOf(item));
    toast('已创建文件夹 ' + name);
  }

  function duplicate() {
    const ids = A.ids();
    if (!ids.length) return toast('先选中项目');
    let n = 0;
    ids.forEach(i => {
      const f = FILES[i];
      if (!f || f.folder) return;
      FILES.push({ ...f, n: suffixName(f.p, f.n), t: '刚刚', m: '刚刚' });
      n++;
    });
    A.redraw();
    toast(n ? '已创建 ' + n + ' 个副本' : '文件夹不支持创建副本');
  }

  /* ---------- 层级映射 ----------
     原型用 p 的字符串前缀表示层级（"Documents / ReviewRoot / Level2"）。
     所以搬动、复制、改名文件夹时，必须**整体换前缀**，而不是把每个子项的 p
     都改成根路径 —— 后者会把 Level2 拍到根下面，层级就塌了。
     full 一律从 p + n 推导，避免两处各写一份再对不上。 */
  const fullOf = f => (!f || !f.folder) ? (f && f.full) : (f.p ? f.p + ' / ' + f.n : f.n);

  function remapUnder(oldRoot, newRoot, except) {
    if (!oldRoot || oldRoot === newRoot) return 0;
    const pre = oldRoot + ' / ';
    let n = 0;
    FILES.forEach(k => {
      if (k === except || !k.p) return;
      if (k.p === oldRoot) { k.p = newRoot; n++; }
      else if (k.p.startsWith(pre)) { k.p = newRoot + k.p.slice(oldRoot.length); n++; }
      else return;
      if (k.folder) k.full = fullOf(k);
    });
    return n;
  }

  /* 复制文件夹：子树逐项克隆到新前缀下，层级保持不变。
     snapshot 必须由调用方在**改动 FILES 之前**取好 —— 一旦先把新根 push 进去，
     再调 subtreeOf(f) 就会把刚插入的新根也算成来源（复制到自身后代时无限嵌套）。 */
  function cloneSubtree(f, newFull, snapshot) {
    const oldRoot = f.full;
    if (!oldRoot) return 0;
    let n = 0;
    (snapshot || subtreeOf(f)).forEach(k => {
      const np = k.p === oldRoot ? newFull : newFull + k.p.slice(oldRoot.length);
      FILES.push({ ...k, p: np, full: k.folder ? (np ? np + ' / ' + k.n : k.n) : k.full, t: '刚刚', m: '刚刚' });
      n++;
    });
    return n;
  }

  /* ---------- 稳定身份 ----------
     原型的数据是普通数组，没有后端 id。这里用 WeakMap 给每个对象分配一个
     会话内唯一的序号：它跟着**对象**走，不跟下标、也不跟名字走。
     只按「路径 + 名字」重找是不行的 —— 删掉原文件、再建一个同名的新文件，
     剪贴板就会认领那个新的（评审用这个构造复现过）。 */
  const UID = new WeakMap();
  let uidSeq = 0;
  const uidOf = f => { if (!UID.has(f)) UID.set(f, ++uidSeq); return UID.get(f); };

  /* ---------- 剪贴板 ----------
     存 { ref, id }：ref 用来直接命中，id 用来在数组重建后仍能确认「是同一个对象」。
     两者都对不上就是来源真的没了，明确提示，不做按名字的近似匹配。 */
  function setClip(mode, side) {
    const ids = A.ids(side);
    if (!ids.length) return toast('先选中项目');
    const files = ids.map(i => FILES[i]).filter(Boolean);
    clip = { mode, items: files.map(f => ({ ref: f, id: uidOf(f) })) };
    A.redraw();
    const folders = files.filter(f => f.folder);
    /* 文件夹也一起进剪贴板：正式实现由目录传输引擎递归处理，
       原型里连子树一起搬，保证「记录的是哪些项」不丢 */
    toast((mode === 'cut' ? '已剪切 ' : '已复制 ') + files.length + ' 项' +
      (folders.length ? '（含 ' + folders.length + ' 个文件夹）' : ''));
  }

  function resolveClipItem(it) {
    if (!it) return null;
    if (it.ref && FILES.includes(it.ref)) return it.ref;
    for (const x of FILES) if (uidOf(x) === it.id) return x;
    return null;
  }

  /* 复制文件夹时把它的子树一起带走：原型数据里子项用 p 前缀表示层级 */
  function subtreeOf(f) {
    if (!f || !f.folder || !f.full) return [];
    return FILES.filter(x => x !== f && (x.p === f.full || x.p.startsWith(f.full + ' / ')));
  }

  /* 目标位置已有同名项目时怎么处理。Copy 与 Move 共用同一套决策：
     移动尤其不能默默生成两个同名条目 —— 它们在逻辑上不可区分，
     之后任何按名字的操作都会指错（评审用 CollisionTrace.txt 复现过）。 */
  async function askConflict(n) {
    if (!flow.zcPick) return 'keepBoth';
    const i = await flow.zcPick({
      title: '目标位置已有同名项目',
      sub: n + ' 项与目标文件夹里的名称重复，选择怎么处理',
      items: [
        { label: '保留两者', desc: '进来的项目重命名为「名称 2」' },
        { label: '跳过这些项', desc: '重复的不处理，其余照常' },
        { label: '替换目标', desc: '目标位置的原项目移入安全回收站' }
      ]
    });
    if (i == null) return null;
    return ['keepBoth', 'skip', 'replace'][i] || 'keepBoth';
  }

  async function paste() {
    if (!clip || !clip.items.length) return toast('剪贴板是空的');
    const dest = path();
    const cut = clip.mode === 'cut';

    const alive = [];
    let lost = 0;
    clip.items.forEach(it => {
      const f = resolveClipItem(it);
      if (f) alive.push(f); else lost++;
    });
    if (!alive.length) {
      clip = null;
      A.redraw();
      return toast('来源文件已不存在，请重新复制');
    }

    /* 移动的撞名一次性问清楚，不边做边弹 */
    let mode = 'keepBoth';
    if (cut) {
      const dup = alive.filter(f => f.p !== dest && FILES.some(x => x !== f && x.p === dest && x.n === f.n));
      if (dup.length) {
        const pick = await askConflict(dup.length);
        if (!pick) return;                       /* 取消：剪贴板留着，什么都没动 */
        mode = pick;
      }
    }

    let moved = 0, copied = 0, skipped = 0, replaced = 0;
    alive.forEach(f => {
      const oldRoot = f.full;
      /* 不能把一个文件夹塞进它自己或它的后代里 */
      const selfNest = !!(f.folder && f.full && (dest === f.full || dest.startsWith(f.full + ' / ')));

      if (cut) {
        if (f.p === dest) { skipped++; return; }
        if (selfNest) { skipped++; return; }
        if (FILES.some(x => x !== f && x.p === dest && x.n === f.n)) {
          if (mode === 'skip') { skipped++; return; }
          if (mode === 'replace') {
            const v = FILES.find(x => x !== f && x.p === dest && x.n === f.n);
            if (v) {
              const k = FILES.indexOf(v);
              if (k >= 0) { FILES.splice(k, 1); trash.push({ ...v }); replaced++; }
            }
          } else {
            f.n = uniqueIn(dest, f.n);           /* 保留两者：改名 */
          }
        }
        f.p = dest;
        if (f.folder) f.full = fullOf(f);
        f.t = '刚刚'; moved++;
        if (f.folder) remapUnder(oldRoot, f.full, f);   /* 子树跟着走，前缀替换而不是拍平 */
      } else {
        if (selfNest) { skipped++; return; }
        /* 快照必须在插入新根**之前**取：先 push 再 subtreeOf(f) 会把新根也算进来源，
           复制到自身后代时就会套娃（评审复现过 RootDeepCopy/Sub/RootDeepCopy/…）。 */
        const snapshot = f.folder ? subtreeOf(f).slice() : [];
        const n = uniqueIn(dest, f.n);
        const copyFull = f.folder ? ((dest ? dest + ' / ' : '') + n) : f.full;
        FILES.push({ ...f, p: dest, n, full: copyFull, t: '刚刚', m: '刚刚' });
        if (f.folder) cloneSubtree(f, copyFull, snapshot);
        copied++;
      }
    });

    clip = null;
    A.redraw();
    const parts = [];
    if (moved) parts.push('已移动 ' + moved + ' 项');
    if (copied) parts.push('已粘贴 ' + copied + ' 项');
    if (replaced) parts.push('替换 ' + replaced + ' 项（原文件在安全回收站）');
    if (skipped) parts.push('跳过 ' + skipped + ' 项');
    if (lost) parts.push(lost + ' 项来源已不存在');
    toast(parts.length ? parts.join(' · ') : '来源与目标相同');
  }

  async function rename(idx) {
    if (!flow.zcPrompt) return;
    const f = FILES[idx];
    if (!f) return;
    const name = await flow.zcPrompt({ title: '重命名', sub: '当前：' + f.n, value: f.n, ok: '重命名' });
    if (!name || name === f.n) return;
    const e3 = nameError(name);
    if (e3) return toast(e3);
    if (FILES.some(x => x !== f && x.p === f.p && x.n === name)) return toast('这个目录里已经有同名文件');
    const oldFull = f.full;
    f.n = name;
    if (f.folder) {
      f.full = fullOf(f);
      /* 文件夹改名后，子树里所有子项的前缀都得跟着换，否则它们会挂在旧路径下变成孤儿 */
      remapUnder(oldFull, f.full, f);
    }
    A.redraw();
    toast('已重命名为 ' + name);
  }

  /* ---------- 选择 ---------- */
  function invert(visible, currentSel) {
    const vis = visible || [];
    if (!vis.length) return toast('这里没有可选的项目');
    const sel = new Set(currentSel && currentSel.size ? [...currentSel] : []);
    const keep = vis.filter(i => !sel.has(i));
    A.setSelection(keep);
    toast('已反选 ' + keep.length + ' 项');
  }

  /* ---------- 打开方式 ---------- */
  async function openWith() {
    const ids = A.ids();
    const f = FILES[ids[0]];
    if (!f) return toast('先选中文件');
    if (!flow.zcPick) return;
    const i = await flow.zcPick({
      title: '打开方式', sub: f.n, items: [
        { label: '系统默认程序', desc: '交给操作系统决定，与双击一致' },
        { label: 'Fylura 预览', desc: '在应用内查看，不改变文件' },
        { label: '文本编辑器', desc: '纯文本打开，超过 1 MB 只读前 1 MB' }
      ]
    });
    if (i == null) return;
    if (i === 1) A.preview(ids[0]);
    else toast('原型：用「' + (i === 0 ? '系统默认程序' : '文本编辑器') + '」打开 ' + f.n);
  }

  /* ---------- 删除 / 恢复 ---------- */
  const trash = [];                                  /* 安全回收站（本会话） */
  let lastDelete = null;                             /* 快捷撤销用 */
  let lastEntry = null;                              /* 对应的历史条目 */

  function del() {
    const ids = A.ids();
    if (!ids.length) return toast('先选中项目');
    const picked = ids.map(i => FILES[i]).filter(Boolean);
    if (!picked.length) return;
    /* 删文件夹必须连子树一起删。只删根的话 Child / deep.txt 会留在 FILES 里变成孤儿：
       列表里看不见、回收站里没有、历史恢复也救不回来。
       用 Set 去重，兼容「同时选中父目录和它的子项」。 */
    const set = new Set(picked);
    picked.forEach(f => { if (f.folder) subtreeOf(f).forEach(k => set.add(k)); });
    const items = [...set];
    items.forEach(f => {
      const i = FILES.indexOf(f);
      if (i >= 0) FILES.splice(i, 1);
    });
    const copies = items.map(f => ({ ...f }));
    trash.push(...copies);
    lastDelete = copies;
    A.redraw();
    const extra = items.length - picked.length;
    if (A.historyPush) {
      lastEntry = A.historyPush({
        kind: 'delete',
        title: '删除 ' + picked.length + ' 项' + (extra ? '（含 ' + extra + ' 个子项）' : ''),
        meta: ['刚刚', '可在安全回收站恢复', '90 天内有效'],
        undo: true,
        payload: { items: copies }
      });
    }
    toast('已移入安全回收站 · ' + items.length + ' 项' + (extra ? '（含子树）' : ''));
  }

  function restoreItems(items) {
    (items || []).forEach(it => FILES.push({ ...it }));
    A.redraw();
    toast('已恢复 ' + (items || []).length + ' 项');
  }

  function quickUndo() {
    if (!lastDelete || !lastDelete.length) return false;
    const items = lastDelete;
    lastDelete = null;
    items.forEach(it => {
      const k = trash.findIndex(x => x === it);
      if (k >= 0) trash.splice(k, 1);
    });
    restoreItems(items);
    if (lastEntry) {
      lastEntry.undone = true;
      lastEntry = null;
      if (window.zcFlow && window.zcFlow.renderHist) window.zcFlow.renderHist();
    }
    return true;
  }

  /* ---------- 收藏 ---------- */
  function toggleFav(p) {
    const target = p || path();
    if (!target) return toast('本机根目录不能收藏');
    const on = favs.has(target);
    if (on) favs.delete(target); else favs.add(target);
    toast(on ? '已取消收藏' : '已收藏 ' + target.split(' / ').pop());
    if (A.onFavChange) A.onFavChange();
  }

  async function openFavs() {
    if (!flow.zcPick) return;
    const list = [...favs];
    if (!list.length) return toast('还没有收藏');
    const i = await flow.zcPick({
      title: '收藏的文件夹', sub: '共 ' + list.length + ' 个', items: list.map(p => ({ label: p.split(' / ').pop(), desc: p }))
    });
    if (i == null) return;
    A.navTo(list[i]);
  }

  window.zcOps = {
    configure(adapter) {
      A = adapter;
      if (A.onUndo) A.onUndo('delete', async (h) => {
        /* 只恢复**这条历史自己删掉的那几项**。
           原来这里是 trash.splice(0, trash.length)：撤销较早的一次删除，
           会把整个回收站倒空 —— 两个文件都回来、回收站空了、
           另一条删除历史还挂着「未撤销」。三个现象出自同一行。 */
        const items = (h && h.payload && Array.isArray(h.payload.items)) ? h.payload.items : [];
        if (!items.length) return toast('这条记录没有可恢复的内容');
        let n = 0;
        items.forEach(it => {
          const k = trash.indexOf(it);
          if (k < 0) return;                     /* 已经恢复过，跳过 */
          trash.splice(k, 1);
          FILES.push({ ...it });
          n++;
        });
        if (!n) {
          if (h) h.undone = true;
          A.redraw();
          if (window.zcFlow && window.zcFlow.renderHist) window.zcFlow.renderHist();
          return toast('这些项目已经在原位置');
        }
        if (h) h.undone = true;
        /* 撤销的正好是「Ctrl+Z 记着的那一条」时，两边状态一起清，
           否则快捷撤销还能把一个已经回来的文件再恢复一次 */
        if (!lastEntry || lastEntry === h) { lastDelete = null; lastEntry = null; }
        A.redraw();
        toast('已恢复 ' + n + ' 项');
        if (window.zcFlow && window.zcFlow.renderHist) window.zcFlow.renderHist();
      });
    },
    /* 篮子键：路径 + 名字。平台层菜单也用它，避免一边新键一边旧键 */
    bkey: f => (f.p || '') + '\u0000' + f.n,
    /* 当前选择（调试与回归用）：多窗格里必须带 Pane ID */
    ids: side => (A ? A.ids(side) : []),
    del, quickUndo, restoreItems,
    get trash() { return trash.slice(); },
    newFile, newFolder, duplicate, setClip, paste, rename, invert, openWith, toggleFav, openFavs,
    favs,
    get clip() { return clip; },
    /* 剪贴板里的文件对象（回归脚本与提示文案用；clip.items 是 {ref,id} 包装） */
    get clipFiles() { return clip ? clip.items.map(it => it.ref) : []; }
  };
})();
