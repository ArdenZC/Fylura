/* ===================== 业务状态机（走查补齐） =====================
   把「点一下没反应」的按钮接上真实状态：
   概览 → 整理计划 → Dry Run → 执行 → 历史 → 撤销，清理 → 安全回收站 → 历史。
   两套原型共用同一套逻辑，只有文件库导航按平台分支。
   ================================================================= */
(function () {
  'use strict';
  if (window.__zcFlow) return;
  window.__zcFlow = true;

  const IS_MAC = document.documentElement.classList.contains('os-mac');
  const RM = matchMedia('(prefers-reduced-motion: reduce)');
  const pause = ms => new Promise(r => setTimeout(r, RM.matches ? 0 : ms));
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  /* 文件名是唯一的用户可控输入，凡是把它拼进 innerHTML 的地方都要过这里。
     正式实现用 React 的 {text} 就天然安全，原型是手写字符串拼接，必须显式转义。 */
  window.zcEsc = esc;
  const CHECK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
  const CHECK_LG = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
  /* ---------------- 状态与重渲染 ----------------
     所有会改变界面的状态都在 commit() 里改，commit 结束后统一重渲染。
     不这样做的后果是：新增一个派生视图时，得记得在所有 mutation 后面补一行
     renderX()，漏一次就是「数据变了、界面没变」。 */
  const Render = {};
  let renderPaused = 0;
  function commit(fn) {
    if (fn) fn();
    if (renderPaused) return;
    for (const k in Render) Render[k]();
  }
  function batch(fn) {
    renderPaused++;
    try { if (fn) fn(); } finally { renderPaused--; if (!renderPaused) commit(); }
  }

  const byText = (root, txt) => $$('button', root).find(b => (b.textContent || '').replace(/\s+/g, '').includes(txt.replace(/\s+/g, '')));

  /* ---------------- 弹层原语 ---------------- */
  let lockDepth = 0;
  function lock(on) {
    lockDepth = Math.max(0, lockDepth + (on ? 1 : -1));
    const need = lockDepth > 0;
    if (typeof lockBackground === 'function') lockBackground(need);
    document.documentElement.classList.toggle('zc-modal', need);
  }

  function layer(o) {
    const wrap = document.createElement('div');
    wrap.className = 'zc-scrim';
    wrap.innerHTML =
      '<div class="zc-sheet" role="dialog" aria-modal="true" aria-label="' + esc(o.label || o.title || '对话框') + '" style="width:' + (o.width || 440) + 'px" tabindex="-1">' +
        '<div class="zc-head"><h3>' + (o.title || '') + '</h3>' + (o.sub ? '<p>' + o.sub + '</p>' : '') + '</div>' +
        '<div class="zc-body"></div>' +
        '<div class="zc-acts"></div>' +
      '</div>';
    const sheet = $('.zc-sheet', wrap);
    const body = $('.zc-body', wrap);
    const acts = $('.zc-acts', wrap);
    body.innerHTML = o.body || '';

    const prev = document.activeElement;
    let closed = false;
    const api = { root: wrap, sheet, body, onClose: null };

    const setActs = list => {
      acts.innerHTML = '';
      list.forEach(a => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'btn btn-' + (a.kind || 'quiet');
        b.textContent = a.label;
        if (a.disabled) b.disabled = true;
        b.addEventListener('click', () => a.onClick ? a.onClick(close) : close(a.value));
        acts.appendChild(b);
      });
      const first = acts.querySelector('.btn-primary, .btn-danger') || acts.querySelector('.btn');
      if (first && o.autofocus !== false) first.focus({ preventScroll: true });
      else sheet.focus({ preventScroll: true });
    };

    function close(v) {
      if (closed) return;
      closed = true;
      document.removeEventListener('keydown', onKey, true);
      wrap.classList.add('is-out');
      const done = () => {
        wrap.remove();
        lock(false);
        if (prev && prev.focus) prev.focus({ preventScroll: true });
        if (api.onClose) api.onClose(v);
      };
      if (RM.matches) done(); else setTimeout(done, 150);
    }
    api.close = close;
    api.setActs = setActs;
    api.setBody = html => { body.innerHTML = html; };

    function onKey(e) {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(null); return; }
      if (e.key === 'Tab') {
        const items = $$('button, [href], input, [tabindex]:not([tabindex="-1"])', sheet).filter(el => !el.disabled && el.offsetParent !== null);
        if (!items.length) return;
        const i = items.indexOf(document.activeElement);
        e.preventDefault();
        if (e.shiftKey) items[(i <= 0 ? items.length : i) - 1].focus();
        else items[(i + 1) % items.length].focus();
      }
    }
    document.addEventListener('keydown', onKey, true);
    wrap.addEventListener('mousedown', e => { if (e.target === wrap) close(null); });

    document.body.appendChild(wrap);
    lock(true);
    setActs(o.acts || [{ label: '关闭', kind: 'quiet', onClick: c => c(null) }]);
    if (o.after) o.after(api);
    return api;
  }

  function zcConfirm(o) {
    return new Promise(resolve => {
      const L = layer({
        title: o.title, sub: o.sub, width: o.width || 430, body: o.body,
        acts: [
          { label: o.cancel || '取消', kind: 'quiet', onClick: c => c(false) },
          { label: o.ok || '确认', kind: o.danger ? 'danger' : 'primary', onClick: c => c(true) }
        ]
      });
      L.onClose = v => resolve(v === true);
    });
  }

  const CROSS = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  const WARN_LG = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8v5"/><circle cx="12" cy="16.6" r=".9" fill="currentColor" stroke="none"/><path d="M10.3 3.9 2.6 17.4A1.9 1.9 0 0 0 4.3 20.3h15.4a1.9 1.9 0 0 0 1.7-2.9L13.7 3.9a1.9 1.9 0 0 0-3.4 0Z"/></svg>';

  function zcRun(o) {
    const all = (o.items || []).map(it => ({ ...it, attempt: 0 }));
    let okCount = 0;
    let failList = [];
    return new Promise(resolve => {
      const L = layer({ title: o.title, sub: o.sub, width: o.width || 470, label: o.title, body: '', acts: [] });
      L.onClose = () => resolve({ ok: okCount, failed: failList });

      const rowHTML = it =>
        '<div class="zc-row" data-n="' + esc(it.n) + '"><span class="zc-dot">' + CHECK + '</span>' +
        '<span class="zc-n">' + esc(it.n) + '</span>' +
        '<span class="zc-m">' + esc(it.m || '') + '</span>' +
        '<span class="zc-s">待处理</span></div>';

      async function batch(list, isRetry) {
        const head = $('.zc-head', L.root);
        head.hidden = false;
        $('h3', head).textContent = isRetry ? '仅重试 ' + list.length + ' 项' : o.title;
        const hp = $('p', head);
        if (hp) hp.textContent = isRetry ? '只处理上一次失败的项，已完成的不会重跑。' : (o.sub || '');
        L.sheet.classList.remove('is-done');
        L.setBody('<div class="zc-bar"><i></i></div><div class="zc-rows">' + list.map(rowHTML).join('') + '</div>' +
                  '<div class="zc-sum">0 / ' + list.length + '</div>');
        L.setActs([]);

        const rows = [...L.root.querySelectorAll('.zc-row')];
        const bar = $('.zc-bar i', L.root);
        const sum = $('.zc-sum', L.root);
        const fast = list.length > 12;          /* 大批量不再逐条演，改成批次推进 + 滚动 */
        const box = $('.zc-rows', L.root);
        if (box) box.classList.toggle('is-fast', fast);
        for (let i = 0; i < list.length; i++) {
          const it = list[i], r = rows[i];
          it.attempt++;
          const fails = it.fail && (it.fail.always || (it.fail.failOn || [1]).includes(it.attempt));
          if (!fast) {
            r.classList.add('is-run');
            $('.zc-s', r).textContent = o.verb || '处理中';
            await pause(120);
            r.classList.remove('is-run');
          }
          if (fails) {
            r.classList.add('is-fail');
            $('.zc-dot', r).innerHTML = CROSS;
            $('.zc-s', r).textContent = '失败';
            const why = (it.attempt > 1 && it.fail.reason2) ? it.fail.reason2 : it.fail.reason;
            const m = $('.zc-m', r);
            m.textContent = why;
            m.title = why;
            if (!fast) await pause(360);
          } else {
            r.classList.add('is-done');
            $('.zc-s', r).textContent = '完成';
            okCount++;
            if (!fast) await pause(70);
          }
          bar.style.width = Math.round((i + 1) / list.length * 100) + '%';
          sum.textContent = (i + 1) + ' / ' + list.length;
          if (fast && (i % 6 === 5 || i === list.length - 1)) {
            r.scrollIntoView({ block: 'nearest' });
            await pause(26);
          }
        }
        failList = list.filter(it => it.fail && (it.fail.always || (it.fail.failOn || [1]).includes(it.attempt)));
      }

      const failBlock = list =>
        '<div class="zc-fails">' + list.slice(0, 4).map(f => {
          const why = (f.attempt > 1 && f.fail.reason2) ? f.fail.reason2 : f.fail.reason;
          return '<div class="zc-fail"><span class="zc-fdot">' + CROSS + '</span>' +
            '<span class="zc-fn">' + esc(f.n) + '</span><span class="zc-fw" title="' + esc(why) + '">' + esc(why) + '</span></div>';
        }).join('') + (list.length > 4 ? '<div class="zc-fmore">还有 ' + (list.length - 4) + ' 项</div>' : '') + '</div>';

      const doneHTML = (warn, title, body, extra) =>
        '<div class="zc-done' + (warn ? ' is-warn' : '') + '"><span class="zc-check">' + (warn ? WARN_LG : CHECK_LG) + '</span>' +
        '<b>' + title + '</b><p>' + body + '</p>' + (extra || '') + '</div>';

      async function finish() {
        await pause(240);
        const head = $('.zc-head', L.root);
        if (head) head.hidden = true;
        L.sheet.classList.add('is-done');
        if (!failList.length) {
          L.setBody(doneHTML(false, o.doneTitle || '已完成', o.doneBody || ''));
          L.setActs([{ label: o.cta || '完成', kind: 'primary', onClick: c => c(true) }]);
          return;
        }
        const bad = failList.length;
        const stuck = failList.every(f => f.fail && f.fail.always);
        const title = okCount ? okCount + ' 项完成，' + bad + ' 项失败' : bad + ' 项失败';
        const body = '失败的文件仍在原位，没有丢失，也没有被删除。' +
          (stuck ? '这些文件已经不在原来的位置，需要回到文件库重新定位。' : '');
        L.setBody(doneHTML(true, title, body, failBlock(failList)));
        L.setActs(stuck
          ? [{ label: '完成', kind: 'primary', onClick: c => c(true) }]
          : [{ label: '完成', kind: 'quiet', onClick: c => c(true) },
             { label: '仅重试 ' + bad + ' 项', kind: 'primary', onClick: () => { retry(failList); } }]);
      }

      async function retry(list) {
        await batch(list.map(it => ({ ...it })), true);
        await finish();
      }

      (async () => { await batch(all, false); await finish(); })();
    });
  }


  /* ---------------- 输入与选择层 ---------------- */
  function zcPrompt(o) {
    return new Promise(resolve => {
      const L = layer({
        title: o.title, sub: o.sub, width: o.width || 420, label: o.title,
        body: '<input class="zc-input" id="zcInput" type="text" value="' + esc(o.value || '') +
              '" spellcheck="false" autocomplete="off" aria-label="' + esc(o.title || '输入') + '">' +
              (o.hint ? '<p class="zc-note">' + o.hint + '</p>' : ''),
        acts: [
          { label: o.cancel || '取消', kind: 'quiet', onClick: c => c(null) },
          { label: o.ok || '确定', kind: 'primary', onClick: c => c(input.value.trim() || null) }
        ],
        autofocus: false
      });
      const input = $('#zcInput', L.root);
      input.focus({ preventScroll: true });
      input.select();
      input.addEventListener('keydown', e => {
        if (e.isComposing || e.keyCode === 229) return;
        if (e.key === 'Enter') { e.preventDefault(); L.close(input.value.trim() || null); }
      });
      L.onClose = v => resolve(typeof v === 'string' && v ? v : null);
    });
  }

  function zcPick(o) {
    return new Promise(resolve => {
      const body = '<div class="zc-choices">' + (o.items || []).map((it, i) =>
        '<button type="button" class="zc-choice" data-i="' + i + '"><span class="zc-ct"><b>' + it.label + '</b>' +
        (it.desc ? '<span>' + it.desc + '</span>' : '') + '</span></button>').join('') + '</div>';
      const L = layer({
        title: o.title, sub: o.sub, width: o.width || 430, label: o.title, body,
        acts: [{ label: o.cancel || '取消', kind: 'quiet', onClick: c => c(null) }]
      });
      [...L.root.querySelectorAll('.zc-choice')].forEach(b => {
        b.addEventListener('click', () => L.close(+b.dataset.i));
      });
      L.onClose = v => resolve(typeof v === 'number' ? v : null);
    });
  }

  /* ---------------- 数据 ---------------- */
  const PLAN_BASE = [
      { dest: 'Documents / Workspace / Brand', files: [
        { n: 'Brand guidelines.pdf', k: 'pdf', from: 'Documents / Brand', s: '3.2 MB' },
        { n: 'cover-hero.png', k: 'img', from: 'Assets / Homepage', s: '4.8 MB' },
        { n: '品牌语气说明.md', k: 'doc', from: 'Documents / Notes', s: '6 KB' }
      ] },
      { dest: 'Documents / Workspace / Teaching', files: [
        { n: 'course-plan-uml.docx', k: 'doc', from: 'Teaching / 2026 Autumn', s: '128 KB' },
        { n: 'dataset-structure.csv', k: 'sheet', from: 'Teaching / Data Structure', s: '512 KB' },
        { n: 'week-06.key', k: 'deck', from: 'Teaching / 2026 Autumn', s: '18.4 MB' }
      ] },
      { dest: 'Documents / Workspace / Finance', files: [
        { n: 'budget-2026.xlsx', k: 'sheet', from: 'Documents / Finance', s: '212 KB' },
        { n: '报价单 · Q3.pdf', k: 'pdf', from: 'Documents / Finance', s: '1.2 MB' }
      ] }
  ];
  const PLAN = { id: 'P-1106', at: '14:02', active: true, groupBy: 'dest', scale: 8, groups: [] };
  PLAN.moved = new Set();          /* 已经真正移动过的文件，失败的不算 */
  PLAN.cancelled = false;
  PLAN.expand = new Set();         /* 整理页哪个分组被展开 */
  PLAN.expandDry = false;          /* Dry Run 是否显示全部 */

  /* 量级：8 是演示基准，60 / 240 用来暴露折叠、计数与性能问题 */
  const EXTRA_KIND = [
    { k: 'pdf', ext: 'pdf' }, { k: 'img', ext: 'png' }, { k: 'doc', ext: 'docx' }, { k: 'sheet', ext: 'csv' },
    { k: 'deck', ext: 'key' }, { k: 'zip', ext: 'zip' }, { k: 'code', ext: 'ts' }, { k: 'audio', ext: 'm4a' }
  ];
  const EXTRA_NAME = ['archive', 'invoice', 'draft', 'photo', 'dataset', 'lesson', 'budget', 'report', 'clip', 'mock'];
  const EXTRA_FROM = ['Documents / Archive', 'Assets / Photos', 'Teaching / 2026 Autumn', 'Documents / Inbox', 'Assets / Video'];
  function buildPlan(scale) {
    const groups = PLAN_BASE.map(g => ({ dest: g.dest, files: g.files.map(f => ({ ...f })) }));
    for (let i = 0; i < scale - 8; i++) {
      const kd = EXTRA_KIND[i % EXTRA_KIND.length];
      const mb = 0.4 + ((i * 7) % 24);
      groups[i % groups.length].files.push({
        n: EXTRA_NAME[i % EXTRA_NAME.length] + '-' + String(i + 1).padStart(3, '0') + '.' + kd.ext,
        k: kd.k,
        from: EXTRA_FROM[i % EXTRA_FROM.length],
        s: mb >= 1 ? Math.round(mb) + ' MB' : Math.round(mb * 1024) + ' KB'
      });
    }
    return groups;
  }
  const planFiles = () => PLAN.groups.flatMap(g => g.files.map(f => ({ ...f, dest: g.dest })))
    .filter(f => !PLAN.moved.has(f.n));
  /* 两条会失败的项：一条重试能好，一条重试也不会好 */
  const FAILS = {
    'week-06.key': { reason: '目标目录没有写权限', failOn: [1] },
    '报价单 · Q3.pdf': { reason: '源文件已被移动或删除', reason2: '仍然找不到源文件', always: true }
  };

  PLAN.groups = buildPlan(PLAN.scale);

  /* 一个真实的同名冲突：目标目录里已经有 cover-hero.png */
  const CONFLICT = {
    file: 'cover-hero.png',
    existing: { n: 'cover-hero.png', s: '2.1 MB', t: '2026-09-18 10:42', p: 'Documents / Workspace / Brand' },
    res: null                       // 'keep' | 'replace' | 'skip'
  };
  const conflictOf = n => n === CONFLICT.file ? CONFLICT : null;

  const CL = [
    { n: 'archive-2025.zip', p: 'Documents / Archive', why: '90 天未访问', sz: '1.5 GB', mb: 1536, k: 'zip' },
    { n: 'demo-v7.mp4', p: 'Assets / Video', why: '导出后未再使用', sz: '312 MB', mb: 312, k: 'video' },
    { n: 'icon-set.zip', p: 'Assets / Icons', why: '已解压到 Assets / Icons', sz: '33.8 MB', mb: 33.8, k: 'zip' },
    { n: 'team-photo-04.jpg', p: 'Assets / Photos', why: '重复副本', sz: '5.2 MB', mb: 5.2, k: 'img' },
    { n: 'meeting-notes-07.md', p: 'Documents / Notes', why: '内容已并入 Project notes', sz: '14 KB', mb: 0.014, k: 'doc' },
    { n: 'budget-2025.xlsx', p: 'Documents / Finance', why: '已被 2026 版替代', sz: '428 KB', mb: 0.428, k: 'sheet' }
  ].map(c => ({ ...c, picked: false, gone: false }));

  const fmtMB = mb => mb >= 1024 ? (mb / 1024).toFixed(1) + ' GB' : mb >= 1 ? Math.round(mb) + ' MB' : Math.round(mb * 1024) + ' KB';
  const clLeft = () => CL.filter(c => !c.gone);
  const clSpace = () => clLeft().reduce((a, c) => a + c.mb, 0);
  const clPicked = () => clLeft().filter(c => c.picked);

  const HIST = [
    { id: 'h1', kind: 'restore', title: '从安全回收站恢复 2 个文件', meta: ['昨天 18:04', '回到 Documents / Archive'], undo: false },
    { id: 'h2', kind: 'index', title: '新增扫描位置 Teaching', meta: ['昨天 09:12', '索引 42 个文件'], undo: false },
    { id: 'h3', kind: 'organize', title: '整理 12 个文件', meta: ['11 月 9 日 16:20', '4 个目标目录', '超过 30 天，仅保留摘要'], undo: false }
  ];
  let histFilter = 'all';
  let histSeq = 10;
  const HIST_KIND = { organize: '整理', cleanup: '清理', restore: '恢复', index: '索引', delete: '删除' };
  const HIST_ICON = { organize: '#i-spark', cleanup: '#i-broom', restore: '#i-undo', index: '#i-folder', delete: '#i-close' };

  function addHist(e) {
    HIST.unshift({ id: 'h' + (++histSeq), undone: false, ...e });
  }

  /* 文件页的删除/恢复走同一本历史：操作方把撤销动作注册进来，
     历史条目点「撤销」时优先走注册的处理函数。 */
  const undoHooks = {};
  function onUndo(kind, fn) { undoHooks[kind] = fn; }
  function pushHistory(e) { addHist(e); commit(); return HIST[0]; }

  /* ---------------- 概览 ---------------- */
  function renderOverview() {
    const page = $('#p-overview');
    if (!page) return;
    const n = PLAN.active ? planFiles().length : 0;
    const space = clSpace();
    const planKpi = $('#ovPlan'), planSub = $('#ovPlanSub');
    const spaceKpi = $('#ovSpace'), spaceSub = $('#ovSpaceSub');
    const status = $('#ovStatus');
    if (planKpi) planKpi.textContent = n;
    if (planSub) planSub.textContent = n ? '等待审阅' : '暂无建议';
    if (spaceKpi) spaceKpi.textContent = space > 0 ? fmtMB(space) : '0 B';
    if (spaceSub) spaceSub.textContent = clLeft().length ? '等待确认' : '已清理';
    if (status) {
      const bits = [];
      if (n) bits.push(n + ' 个整理建议');
      if (clLeft().length) bits.push(clLeft().length + ' 个清理候选项');
      status.textContent = bits.length ? '索引完成 · ' + bits.join('、') + '待确认' : '索引完成，没有待确认的文件操作';
    }

    const navCount = $('.nav-item[data-page="organize"] .nav-count') || $('.m-row[data-page="organize"] .nav-count');
    if (navCount) { navCount.textContent = n; navCount.hidden = n === 0; }
    const navClean = $('.nav-item[data-page="cleanup"] .nav-count, .m-row[data-page="cleanup"] .nav-count');
    if (navClean) { navClean.textContent = clLeft().length; navClean.hidden = clLeft().length === 0; }
  }

  /* ---------------- 整理计划 ---------------- */
  function renderPlan() {
    const page = $('#p-organize');
    const body = $('#planBody');
    if (!page || !body) return;
    const title = $('#planTitle'), meta = $('#planMeta');
    const kpiN = $('#planKpiN'), kpiSub = $('#planKpiSub');
    const bar = $('#planBarText');
    const files = planFiles();

    if (!PLAN.active) {
      const cancelled = PLAN.cancelled;
      body.innerHTML = '<div class="zc-empty"><span class="ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7.5A2 2 0 0 1 5 5.5h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg></span>' +
        '<b>' + (cancelled ? '计划已取消' : '这批文件都已就位') + '</b>' +
        '<p>' + (cancelled
          ? '磁盘上没有任何改动。需要时可以重新生成一份建议，它只会提出移动，不会删除文件。'
          : '没有剩下要移动的文件。需要时可以重新生成一份建议。') + '</p>' +
        '<button class="btn btn-primary" type="button" id="planRegen2">重新生成建议</button></div>';
      const r2 = $('#planRegen2');
      if (r2) r2.addEventListener('click', regenPlan);
    } else if (!files.length) {
      body.innerHTML = '<div class="zc-empty"><b>没有可整理的文件</b><p>最近 90 天没有需要移动的文件。</p></div>';
    } else {
      let groups;
      if (PLAN.groupBy === 'src') {
        const map = new Map();
        files.forEach(f => { if (!map.has(f.from)) map.set(f.from, []); map.get(f.from).push(f); });
        groups = [...map].map(([from, list]) => ({ head: from, files: list }));
      } else {
        groups = PLAN.groups
          .map(g => ({ head: g.dest, files: g.files.filter(f => !PLAN.moved.has(f.n)) }))
          .filter(g => g.files.length);
      }
      const LIMIT = 6;
      body.innerHTML = groups.map(g => {
        const open = PLAN.expand.has(g.head) || g.files.length <= LIMIT;
        const show = open ? g.files : g.files.slice(0, LIMIT);
        const rest = g.files.length - show.length;
        const rows = show.map(f =>
          '<div class="plan-file"><span class="fi" data-k="' + f.k + '"><svg width="16" height="16"><use href="#f-' + f.k + '"/></svg></span>' + esc(f.n) +
          '<span class="from">' + esc(PLAN.groupBy === 'src' ? '→ ' + f.dest : f.from) + '</span></div>').join('');
        const more = g.files.length > LIMIT
          ? '<div class="plan-more"><button type="button" data-g="' + esc(g.head) + '">' +
            (open ? '收起' : '还有 ' + rest + ' 个文件') + '</button></div>' : '';
        return '<div class="plan-group"><div class="plan-target"><svg width="16" height="16"><use href="#f-folder"/></svg>' + esc(g.head) +
          '<span class="n">' + g.files.length + ' 个文件</span></div>' + rows + more + '</div>';
      }).join('');
      $$('.plan-more button', body).forEach(b => b.addEventListener('click', () => {
        const head = b.dataset.g;
        if (PLAN.expand.has(head)) PLAN.expand.delete(head); else PLAN.expand.add(head);
        commit();
      }));
    }

    if (title) title.textContent = '整理计划 ' + PLAN.id;
    if (meta) meta.textContent = PLAN.active ? '生成于 ' + PLAN.at + ' · 基于最近 90 天'
      : (PLAN.cancelled ? '已取消 · 未改动任何文件' : '已执行完成 · 仍可整批撤销');
    const cfKpi = $('#planConflict'), cfSub = $('#planConflictSub');
    if (cfKpi) { cfKpi.textContent = CONFLICT.res ? 0 : 1; cfKpi.classList.toggle('is-warn', !CONFLICT.res); }
    if (cfSub) cfSub.textContent = CONFLICT.res ? '冲突已定' : '需在 Dry Run 处理';
    const dur = $('#planDur'), durSub = $('#planDurSub');
    if (dur) dur.textContent = PLAN.active ? Math.max(12, Math.round(files.length * 0.15)) + ' 秒' : '—';
    if (durSub) durSub.textContent = PLAN.active ? '本地操作' : '没有待办变更';
    if (kpiN) kpiN.textContent = PLAN.active ? files.length : 0;
    if (kpiSub) kpiSub.textContent = PLAN.active ? '分到 ' + PLAN.groups.length + ' 个目录' : '等待重新生成';
    if (bar) bar.innerHTML = PLAN.active
      ? '<b>' + files.length + ' 个文件</b>将被移动 · 不会删除任何文件' + (CONFLICT.res ? '' : ' · <b class="warn">1 个同名待处理</b>')
      : '计划已取消 · 磁盘未改动';

    const groupBtn = $('.sec-head button', page);
    if (groupBtn) {
      groupBtn.textContent = PLAN.groupBy === 'src' ? '分组：来源位置' : '分组：目标目录';
      groupBtn.disabled = !PLAN.active;
    }
    const barActs = $('.bar-actions', page);
    [barActs && byText(barActs, '取消计划'), byText(page, '预览变更'), byText(page, '预览并执行'),
     byText($('.head-actions', page), '进入 Dry Run')].forEach(b => { if (b) b.disabled = !PLAN.active; });
  }

  function setPlanScale(n) {
    PLAN.scale = n;
    PLAN.groups = buildPlan(n);
    PLAN.moved.clear();
    PLAN.expand.clear();
    PLAN.expandDry = false;
    PLAN.cancelled = false;
    PLAN.active = true;
    CONFLICT.res = null;
    commit();
    if (typeof showToast === 'function') showToast('计划改为 ' + planFiles().length + ' 项 · 分到 3 个目录');
  }

  function regenPlan() {
    PLAN.active = true;
    PLAN.cancelled = false;
    PLAN.moved.clear();
    CONFLICT.res = null;
    PLAN.at = '刚刚';
    const num = parseInt(PLAN.id.split('-')[1], 10) + 1;
    PLAN.id = 'P-' + num;
    commit();
    if (typeof showToast === 'function') showToast('已按最近 90 天重新生成建议 · ' + planFiles().length + ' 个文件');
  }

  /* ---------------- Dry Run ---------------- */
  function renderDry() {
    const panel = $('#dryPanel');
    if (!panel) return;
    const sum = $('#drySum');
    const files = planFiles();
    const head = '<div class="dry-head"><span></span><span>文件与目标位置</span><span style="text-align:right">大小</span></div>';
    if (!PLAN.active) {
      panel.innerHTML = '<div class="zc-empty"><b>' + (PLAN.cancelled ? '计划已取消' : '没有待执行的变化') + '</b><p>' +
        (PLAN.cancelled ? '磁盘上还没有发生任何改动。' : '这批文件都已就位，可以在「历史」里整批撤销。') +
        '</p><button class="btn btn-ghost" type="button" onclick="gotoPage(\'organize\')">返回整理文件</button></div>';
      if (sum) sum.innerHTML = '<span class="dim">当前没有待预览的变更</span>';
      const go = $('#dryRunGo');
      if (go) { go.disabled = true; go.textContent = '没有待执行的变更'; }
      return;
    }
    const CF_LABEL = { keep: '保留双方', replace: '替换', skip: '跳过' };
    const rowOf = f => {
      const cf = conflictOf(f.n);
      const flag = !cf ? '' : (CONFLICT.res
        ? '<span class="dry-flag is-done">已定 · ' + CF_LABEL[CONFLICT.res] + '</span>'
        : '<span class="dry-flag">同名</span>');
      return '<div class="dry-row' + (cf && !CONFLICT.res ? ' is-conflict' : '') + '">' +
        '<span class="fi" data-k="' + f.k + '"><svg width="16" height="16"><use href="#f-' + f.k + '"/></svg></span>' +
        '<span class="dmain"><span class="nm">' + esc(f.n) + flag + '</span><span class="mv"><span class="from">' + esc(f.from) + '</span><b>→</b><span class="to">' + esc(f.dest) + '</span></span></span>' +
        '<span class="sz">' + f.s + '</span></div>';
    };
    const DRY_LIMIT = 40;
    const all = PLAN.expandDry || files.length <= DRY_LIMIT;
    const shown = all ? files : files.slice(0, DRY_LIMIT);
    panel.innerHTML = head + shown.map(rowOf).join('') +
      (files.length > DRY_LIMIT
        ? '<div class="dry-more"><button type="button" id="dryMore">' + (all ? '收起' : '展开全部 ' + files.length + ' 项') + '</button></div>'
        : '');
    const dm = $('#dryMore');
    if (dm) dm.addEventListener('click', () => { PLAN.expandDry = !all; commit(); });
    const cfN = CONFLICT.res ? 0 : 1;
    if (sum) sum.innerHTML =
      '<span><b>' + files.length + '</b> 个文件将被移动</span><i></i>' +
      '<span' + (cfN ? ' class="is-warn"' : '') + '><b>' + cfN + '</b> 个命名冲突</span><i></i>' +
      '<span><b>0</b> 个文件被删除</span><i></i><span><b>' + PLAN.groups.length + '</b> 个目标目录</span><i></i>' +
      '<span class="dim">执行后可在「历史」里整批撤销</span>';
    const go = $('#dryRunGo');
    if (go) {
      go.disabled = false;
      go.textContent = cfN ? '先处理 ' + cfN + ' 个冲突' : '执行 ' + files.length + ' 项变更';
    }
  }

  function zcConflict() {
    return new Promise(resolve => {
      const files = planFiles();
      const f = files.find(x => conflictOf(x.n)) || files[0];
      const old = CONFLICT.existing;
      const base = f.n.replace(/\.[^.]+$/, '');
      let pick = CONFLICT.res || 'keep';
      const opt = (v, name, desc) =>
        '<button type="button" class="cf-opt" role="radio" aria-checked="' + (pick === v) + '" data-v="' + v + '">' +
        '<span class="cf-radio"></span><span class="cf-otx"><b>' + name + '</b><span>' + desc + '</span></span></button>';
      const L = layer({
        title: '1 个文件同名，先决定怎么处理',
        sub: '其余 ' + (files.length - 1) + ' 个文件不受影响。这个选择只作用于本次执行。',
        width: 560, label: '同名文件处理',
        body: '<div class="cf">' +
            '<div class="cf-pair">' +
              '<div class="cf-cell is-new"><span class="cf-tag">要移入</span><b>' + esc(f.n) + '</b>' +
                '<span class="cf-meta">' + f.s + ' · 今天 14:02</span><span class="cf-path">' + esc(f.from) + '</span></div>' +
              '<span class="cf-arrow" aria-hidden="true">→</span>' +
              '<div class="cf-cell is-old"><span class="cf-tag">目标已有</span><b>' + esc(old.n) + '</b>' +
                '<span class="cf-meta">' + old.s + ' · ' + esc(old.t) + '</span><span class="cf-path">' + esc(old.p) + '</span></div>' +
            '</div>' +
            '<div class="cf-opts" role="radiogroup" aria-label="同名文件怎么处理">' +
              opt('keep', '保留双方', '新文件改名为 ' + esc(base) + ' 2.png，两个都留着') +
              opt('replace', '替换', '现有文件移入安全回收站，90 天内可恢复') +
              opt('skip', '跳过', '这个文件留在原位，其余 ' + (files.length - 1) + ' 项继续') +
            '</div>' +
            '<p class="zc-note">没有「永久删除」这个选项。替换也只是把旧文件送进回收站。</p>' +
          '</div>',
        acts: [
          { label: '取消', kind: 'quiet', onClick: c => c(null) },
          { label: '继续执行 ' + files.length + ' 项', kind: 'primary', onClick: c => c(pick) }
        ]
      });
      L.root.addEventListener('click', e => {
        const b = e.target.closest('.cf-opt');
        if (!b) return;
        pick = b.dataset.v;
        [...L.root.querySelectorAll('.cf-opt')].forEach(x => x.setAttribute('aria-checked', String(x === b)));
        const n = pick === 'skip' ? files.length - 1 : files.length;
        const primary = [...L.root.querySelectorAll('.zc-acts .btn')].pop();
        if (primary) primary.textContent = '继续执行 ' + n + ' 项';
      });
      L.onClose = v => resolve(v || null);
    });
  }

  async function execPlan() {
    const all = planFiles();
    if (!PLAN.active || !all.length) { if (typeof showToast === 'function') showToast('没有待执行的变更'); return; }
    let res = CONFLICT.res;
    if (!res) {
      // 有未决冲突：先决策，决策层本身就是确认
      const picked = await zcConflict();
      if (!picked) return;
      res = picked;
      CONFLICT.res = res;
      commit();
    } else {
      const ok = await zcConfirm({
        title: '执行 ' + all.length + ' 项变更？',
        sub: '只会移动文件，不会删除、不会覆盖。执行完成后可以在「历史」里整批撤销。',
        body: '<div class="zc-note">目标目录：' + PLAN.groups.map(g => esc(g.dest.split(' / ').pop())).join('、') + '</div>',
        ok: '执行变更'
      });
      if (!ok) return;
    }
    const skipped = res === 'skip' ? 1 : 0;
    const files = all.filter(f => !(conflictOf(f.n) && res === 'skip'));
    const lastDir = f => f.dest.split(' / ').slice(-1)[0];
    const note = {
      keep: '同名文件已改名为 ' + CONFLICT.file.replace(/\.[^.]+$/, '') + ' 2.png，两个都还在。',
      replace: '旧的 cover-hero.png 已在安全回收站，90 天内可恢复。',
      skip: '1 个同名文件已跳过，留在原位。'
    }[res];
    const secs = Math.max(12, Math.round(files.length * 0.15));
    const result = await zcRun({
      title: '正在执行 ' + files.length + ' 项变更',
      sub: '本地操作，预计 ' + secs + ' 秒。中途关闭窗口也不会丢数据。',
      items: files.map(f => ({
        n: f.n,
        m: conflictOf(f.n) ? (res === 'replace' ? '替换同名 → ' + lastDir(f) : res === 'keep' ? '改名 → ' + lastDir(f) : '→ ' + lastDir(f)) : '→ ' + lastDir(f),
        fail: FAILS[f.n]
      })),
      verb: '移动中',
      doneTitle: files.length + ' 个文件已就位',
      doneBody: note + ' 没有文件被永久删除。这次改动已记入历史，可以整批撤销。',
      cta: '查看历史'
    });

    const failedNames = new Set((result.failed || []).map(f => f.n));
    files.forEach(f => { if (!failedNames.has(f.n)) PLAN.moved.add(f.n); });
    const bad = failedNames.size;
    const moved = result.ok || 0;
    const left = planFiles().length;
    PLAN.active = left > 0;

    if (moved) {
      addHist({
        kind: 'organize',
        title: '整理 ' + moved + ' 个文件' + (bad ? ' · ' + bad + ' 项失败' : ''),
        meta: ['刚刚', bad ? bad + ' 项仍在原位' : skipped ? '跳过 1 个同名文件' : res === 'replace' ? '替换 1 个同名文件' : res === 'keep' ? '1 个同名已改名' : PLAN.groups.length + ' 个目标目录', secs + ' 秒'],
        undo: true
      });
    }
    commit();
    if (typeof showToast === 'function') {
      showToast(bad ? '已移动 ' + moved + ' 项 · ' + bad + ' 项失败，仍在原位' : '已执行 ' + moved + ' 项变更' + (skipped ? ' · 跳过 1 个' : '') + ' · 可在历史撤销');
    }
    if (typeof gotoPage === 'function') gotoPage('history');
  }

  /* ---------------- 清理 ---------------- */
  function renderCleanup() {
    const wrap = $('#cands');
    if (!wrap) return;
    const left = clLeft();
    const head = '<div class="cand-head"><span></span><span>名称</span><span>原因</span><span style="text-align:right">大小</span></div>';
    if (!left.length) {
      wrap.innerHTML = head + '<div class="zc-empty"><span class="ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span><b>没有候选项了</b><p>6 个候选项已在安全回收站，90 天内都能恢复。重新扫描会再检查一遍。</p></div>';
    } else {
      wrap.innerHTML = head + left.map((c, i) =>
        '<button class="cand' + (c.picked ? ' sel' : '') + '" role="option" aria-selected="' + c.picked + '" data-n="' + esc(c.n) + '">' +
        '<span class="cb"><svg width="12" height="12"><use href="#i-check"/></svg></span>' +
        '<span class="name"><span class="fi" data-k="' + c.k + '"><svg width="16" height="16"><use href="#f-' + c.k + '"/></svg></span>' +
        '<span class="name-txt"><span class="fname">' + esc(c.n) + '</span><span class="fpath">' + esc(c.p) + '</span></span></span>' +
        '<span class="why">' + esc(c.why) + '</span><span class="sz num">' + c.sz + '</span></button>').join('');
      $$('.cand', wrap).forEach(b => b.addEventListener('click', () => {
        const c = CL.find(x => x.n === b.dataset.n);
        if (!c) return;
        c.picked = !c.picked;
        b.classList.toggle('sel', c.picked);
        b.setAttribute('aria-selected', String(c.picked));
        paintCleanup();
      }));
    }
    paintCleanup();
  }

  function paintCleanup() {
    const n = clPicked().length;
    const space = clPicked().reduce((a, c) => a + c.mb, 0);
    const cnt = $('#candCount'); if (cnt) cnt.textContent = n;
    const bar = $('#candBar');
    if (bar) bar.innerHTML = '<b>' + n + ' 个</b>候选项已选中 · 可释放 ' + (n ? fmtMB(space) : '0 B');
    const spaceKpi = $('#clSpace'), spaceSub = $('#clSpaceSub');
    const countKpi = $('#clCount'), countSub = $('#clCountSub');
    if (spaceKpi) spaceKpi.textContent = clSpace() ? fmtMB(clSpace()) : '0 B';
    if (spaceSub) spaceSub.textContent = '来自 ' + clLeft().length + ' 个候选项';
    if (countKpi) countKpi.textContent = clLeft().length;
    if (countSub) countSub.textContent = clLeft().length ? '已排除系统目录' : '全部已处理';
    const cancelSel = $('#p-cleanup .bar-actions .btn-quiet');
    if (cancelSel) cancelSel.disabled = n === 0;
    const main = $('#clTrash');
    if (main) {
      main.disabled = n === 0;
      main.textContent = n ? '移到安全回收站（' + n + '）' : '移到安全回收站';
    }
    const left = clLeft().length;
    const review = byText($('#p-cleanup .page-head'), '审阅');
    if (review) {
      review.disabled = left === 0;
      review.textContent = left ? '审阅 ' + left + ' 个候选项' : '暂无可审阅项';
    }
    const range = byText($('#p-cleanup'), '选择范围');
    if (range) range.disabled = left === 0;
    const selSub = $('#clSelSub');
    if (selSub) selSub.textContent = n ? '仍需你确认' : (left ? '选中后可移入' : '本轮已处理完');
  }

  async function execTrash() {
    const picked = clPicked();
    if (!picked.length) { if (typeof showToast === 'function') showToast('先选中候选项'); return; }
    const mb = picked.reduce((a, c) => a + c.mb, 0);
    const ok = await zcConfirm({
      title: '把 ' + picked.length + ' 个候选项移到安全回收站？',
      sub: '可释放 <b>' + fmtMB(mb) + '</b>。文件进入 Fylura 安全回收站，90 天内可恢复，不会被直接永久删除。',
      body: '<div class="zc-note">' + picked.slice(0, 3).map(c => esc(c.n)).join('、') + (picked.length > 3 ? ' 等 ' + picked.length + ' 项' : '') + '</div>',
      ok: '移到安全回收站'
    });
    if (!ok) return;
    await zcRun({
      title: '正在移入安全回收站',
      sub: '每个文件都会写一条恢复记录。',
      items: picked.map(c => ({ n: c.n, m: c.sz })),
      verb: '移入中',
      doneTitle: picked.length + ' 个文件已移入安全回收站',
      doneBody: '释放 ' + fmtMB(mb) + ' · 90 天内可恢复。改动已记入历史。',
      cta: '完成'
    });
    picked.forEach(c => { c.gone = true; c.picked = false; });
    addHist({ kind: 'cleanup', title: picked.length + ' 个候选项移入安全回收站', meta: ['刚刚', '释放 ' + fmtMB(mb), '可恢复'], undo: true });
    commit();
    if (typeof showToast === 'function') showToast('已释放 ' + fmtMB(mb) + ' · 90 天内可恢复');
  }

  async function rescanCleanup() {
    const rows = [
      { n: 'Documents', m: '索引 8,412 个文件' },
      { n: 'Teaching', m: '索引 1,206 个文件' },
      { n: 'Assets', m: '索引 3,977 个文件' }
    ];
    await zcRun({
      title: '正在重新扫描',
      sub: '只读取元数据与访问时间，不读取文件内容。',
      items: rows, verb: '扫描中',
      doneTitle: '扫描完成',
      doneBody: clLeft().length ? '找到 ' + clLeft().length + ' 个候选项 · 可释放 ' + fmtMB(clSpace()) : '暂时没有新的候选项。',
      cta: '完成'
    });
    CL.forEach(c => { c.gone = false; c.picked = false; });
    commit();
    if (typeof showToast === 'function') showToast('扫描完成 · ' + clLeft().length + ' 个候选项');
  }

  /* ---------------- 历史 ---------------- */
  function renderHist() {
    const list = $('#hsList');
    if (!list) return;
    const map = { '全部': 'all', '整理': 'organize', '清理': 'cleanup', '恢复': 'restore' };
    $$('#p-history .chip').forEach(c => {
      c.setAttribute('aria-pressed', String(map[c.textContent.trim()] === histFilter));
    });
    const match = h => histFilter === 'all' || h.kind === histFilter ||
      (histFilter === 'cleanup' && h.kind === 'delete');
    const rows = HIST.filter(match);
    if (!rows.length) {
      list.innerHTML = '<div class="zc-empty"><b>这一类还没有记录</b><p>只有真正执行过的操作才会出现在这里。</p></div>';
      return;
    }
    list.innerHTML = rows.map(h =>
      '<div class="tl-item' + (h.undone ? ' is-undone' : '') + '" data-id="' + h.id + '">' +
      '<span class="tl-dot ' + (h.undone ? '' : 'ok') + '"><svg width="14" height="14"><use href="' + (h.undone ? '#i-undo' : HIST_ICON[h.kind]) + '"/></svg></span>' +
      '<div class="tl-main"><b>' + esc(h.title) + '</b>' + (h.undone ? '<span class="hs-badge">已撤销</span>' : '') +
      '<div class="meta">' + h.meta.map(m => '<span>' + esc(m) + '</span>').join('<i>·</i>') + '</div></div>' +
      '<div class="tl-act">' +
      (h.undo && !h.undone ? '<button class="btn btn-quiet hs-undo" type="button" style="height:28px;font-size:12px"><svg width="14" height="14"><use href="#i-undo"/></svg>撤销</button>' : '') +
      (h.kind === 'cleanup' && !h.undone ? '<button class="btn btn-quiet hs-open" type="button" style="height:28px;font-size:12px">查看</button>' : '') +
      '</div></div>').join('');
    $$('.hs-undo', list).forEach(b => b.addEventListener('click', () => {
      const id = b.closest('.tl-item').dataset.id;
      undoEntry(HIST.find(h => h.id === id));
    }));
    $$('.hs-open', list).forEach(b => b.addEventListener('click', () => {
      if (typeof gotoPage === 'function') gotoPage('cleanup');
      if (typeof showToast === 'function') showToast('已跳到空间清理 · 记录可在历史中恢复');
    }));
  }

  async function undoEntry(h) {
    if (!h || h.undone) return;
    if (undoHooks[h.kind]) { await undoHooks[h.kind](h); return; }
    const what = h.kind === 'organize' ? '把 ' + PLAN.moved.size + ' 个文件移回原位' : '把文件从安全回收站恢复';
    const ok = await zcConfirm({
      title: '撤销这次操作？',
      sub: '将' + what + '。撤销本身也会记入历史。',
      ok: '撤销',
      danger: false
    });
    if (!ok) return;
    const restored = h.kind === 'cleanup' ? CL.filter(c => c.gone).length : 0;
    const movedNames = [...PLAN.moved];
    await zcRun({
      title: '正在撤销',
      items: h.kind === 'organize'
        ? PLAN.groups.flatMap(g => g.files.filter(f => PLAN.moved.has(f.n)).map(f => ({ n: f.n, m: '← ' + g.dest.split(' / ').slice(-1)[0] })))
        : CL.filter(c => c.gone).map(c => ({ n: c.n, m: '恢复到 ' + c.p })),
      verb: '回滚中',
      doneTitle: '已撤销',
      doneBody: h.kind === 'organize' ? movedNames.length + ' 个文件回到原来的位置。整理建议重新变为待审阅。' : '文件已回到原位置，候选项重新出现在清理列表。',
      cta: '完成'
    });
    h.undone = true;
    if (h.kind === 'organize') { PLAN.active = true; PLAN.cancelled = false; PLAN.moved.clear(); CONFLICT.res = null; }
    if (h.kind === 'cleanup') CL.forEach(c => { c.gone = false; c.picked = false; });
    addHist({ kind: 'restore', title: h.kind === 'organize' ? '撤销整理 · ' + movedNames.length + ' 个文件回到原位' : '从安全回收站恢复 ' + restored + ' 个文件', meta: ['刚刚', '手动撤销'], undo: false });
    commit();
    if (typeof showToast === 'function') showToast('已撤销');
  }

  /* ---------------- 概览页交互 ---------------- */
  async function rescanAll() {
    await zcRun({
      title: '正在重新扫描',
      sub: '检查 3 个位置的变化，只读取元数据。',
      items: [
        { n: 'Documents', m: '2 分钟前已索引' },
        { n: 'Teaching', m: '昨天已索引' },
        { n: 'Assets', m: '未索引' }
      ],
      verb: '扫描中',
      doneTitle: '索引已更新',
      doneBody: '21 个文件 · 3 个位置。整理建议与清理候选项都已重新计算。',
      cta: '完成'
    });
    commit();
    if (typeof showToast === 'function') showToast('索引已更新 · 21 个文件');
  }

  /* ---------------- 绑定 ---------------- */
  function bind() {
    /* 概览 */
    const ov = $('#p-overview');
    if (ov) {
      const scan = byText($('.head-actions', ov), '重新扫描');
      if (scan) scan.addEventListener('click', rescanAll);
      const org = byText($('.head-actions', ov), '开始整理');
      if (org) org.addEventListener('click', () => gotoPage('organize'));
      const tasks = $$('.panel', ov)[0] ? $$('.task', $$('.panel', ov)[0]) : [];
      const dest = ['library', 'organize', 'cleanup'];
      tasks.forEach((t, i) => t.addEventListener('click', () => dest[i] && gotoPage(dest[i])));
      const all = byText(ov, '查看全部');
      if (all) all.addEventListener('click', () => gotoPage('history'));
      $$('#recent .task').forEach(b => b.addEventListener('click', () => {
        const name = ($('b', b) || {}).textContent || '';
        openInLibrary(name);
      }));
    }

    /* 整理 */
    const og = $('#p-organize');
    if (og) {
      $$('.scale-seg button', og).forEach(b => b.addEventListener('click', () => {
        $$('.scale-seg button', og).forEach(x => x.setAttribute('aria-pressed', String(x === b)));
        setPlanScale(+b.dataset.scale);
      }));
      const regen = byText($('.head-actions', og), '重新生成建议');
      if (regen) regen.addEventListener('click', regenPlan);
      const preview = byText(og, '预览变更');
      if (preview) preview.addEventListener('click', () => gotoPage('dryrun'));
      const goto2 = byText(og, '预览并执行') || byText(og, '进入 Dry Run');
      if (goto2) goto2.addEventListener('click', () => gotoPage('dryrun'));
      const cancel = byText(og, '取消计划');
      if (cancel) cancel.addEventListener('click', async () => {
        if (!PLAN.active) return;
        const ok = await zcConfirm({
          title: '取消这份整理计划？',
          sub: '计划只是建议，取消不会改动磁盘上的任何文件。之后可以重新生成。',
          ok: '取消计划', cancel: '留着'
        });
        if (!ok) return;
        PLAN.active = false;
        PLAN.cancelled = true;
        commit();
        if (typeof showToast === 'function') showToast('计划已取消 · 磁盘未改动');
      });
      const gb = $('.sec-head button', og);
      if (gb) gb.addEventListener('click', () => {
        PLAN.groupBy = PLAN.groupBy === 'dest' ? 'src' : 'dest';
        commit();
        if (typeof showToast === 'function') showToast(PLAN.groupBy === 'src' ? '按来源位置分组' : '按目标目录分组');
      });
    }

    /* Dry Run：原按钮直接跳历史，先克隆掉旧监听 */
    const go = $('#dryRunGo');
    if (go) {
      const fresh = go.cloneNode(true);
      go.replaceWith(fresh);
      fresh.addEventListener('click', execPlan);
    }

    /* 清理 */
    const cp = $('#p-cleanup');
    if (cp) {
      const rescan = byText($('.head-actions', cp), '重新扫描');
      if (rescan) rescan.addEventListener('click', rescanCleanup);
      const review = byText($('.head-actions', cp), '审阅');
      if (review) review.addEventListener('click', () => {
        const wrap = $('#cands');
        const first = $('.cand:not(.sel)', cp) || $('.cand', cp);
        if (!first || !wrap) { if (typeof showToast === 'function') showToast('没有待审阅的候选项'); return; }
        wrap.classList.remove('is-review');
        void wrap.offsetWidth;
        wrap.classList.add('is-review');
        setTimeout(() => wrap.classList.remove('is-review'), 1300);
        wrap.scrollIntoView({ block: 'nearest', behavior: RM.matches ? 'auto' : 'smooth' });
        first.focus({ preventScroll: true });
      });
      const range = byText(cp, '选择范围');
      if (range) range.addEventListener('click', e => {
        e.stopPropagation();
        const left = clLeft();
        const big = left.filter(c => c.mb >= 100);
        const dup = left.filter(c => c.why.includes('重复'));
        const items = [
          { label: '全部 ' + left.length + ' 项', act: () => left.forEach(c => c.picked = true) },
          { label: '大于 100 MB（' + big.length + '）', act: () => { left.forEach(c => c.picked = false); big.forEach(c => c.picked = true); } },
          { label: '只看重复副本（' + dup.length + '）', act: () => { left.forEach(c => c.picked = false); dup.forEach(c => c.picked = true); } },
          { label: '清空选择', act: () => left.forEach(c => c.picked = false) }
        ];
        if (typeof openMenu === 'function') openMenu(range, items.map(i => ({ label: i.label, act: () => { i.act(); commit(); } })));
        else { items[0].act(); commit(); }
      });
      const cancel = byText($('.bar-actions', cp), '取消');
      if (cancel) cancel.addEventListener('click', () => {
        if (!clPicked().length) { if (typeof showToast === 'function') showToast('没有选中的候选项'); return; }
        clLeft().forEach(c => c.picked = false);
        commit();
        if (typeof showToast === 'function') showToast('已清空选择');
      });
      const trash = $('.bar-actions .btn-primary', cp);
      if (trash) { trash.id = 'clTrash'; trash.addEventListener('click', execTrash); }
    }

    /* 历史 */
    const hs = $('#p-history');
    if (hs) {
      $$('.chip', hs).forEach(c => c.addEventListener('click', () => {
        const map = { '全部': 'all', '整理': 'organize', '清理': 'cleanup', '恢复': 'restore' };
        histFilter = map[c.textContent.trim()] || 'all';
        commit();
      }));
      const exp = byText($('.head-actions', hs), '导出记录');
      if (exp) exp.addEventListener('click', () => {
        const n = HIST.filter(h => !h.undone).length;
        if (typeof showToast === 'function') showToast('已导出 ' + n + ' 条记录（原型：不落盘）');
      });
    }

    /* 侧栏底部工作区：给这行一个真实入口，而不是一块不会动的装饰 */
    const wsBtn = $('#wsBtn');
    if (wsBtn) wsBtn.addEventListener('click', e => {
      e.stopPropagation();
      const items = [
        { label: '工作区设置…', act: () => gotoPage('settings') },
        { label: '重新扫描索引', act: () => { if (typeof showToast === 'function') showToast('已重新扫描 21 个文件'); } },
        { label: '切换工作区…', act: () => { if (typeof showToast === 'function') showToast('原型：只有一个本地工作区'); } }
      ];
      if (typeof openMenu === 'function') openMenu(wsBtn, items);
    });

    /* 文件库：整理文件入口（V2 的按钮此前没有行为） */
    const lib = $('#p-library');
    if (lib && !IS_MAC) {
      const btn = byText($('.lib-head, .pane-head, .tb, #paneA', lib), '整理文件') || byText(lib, '整理文件');
      if (btn && !btn.closest('.nav-item')) btn.addEventListener('click', () => gotoPage('organize'));
    }
  }

  function openInLibrary(name) {
    if (!name) return;
    gotoPage('library');
    if (typeof FILES === 'undefined') return;
    const i = FILES.findIndex(f => f.n === name);
    if (i < 0) return;
    if (IS_MAC && typeof FX !== 'undefined' && typeof fxRender === 'function') {
      FX.path = FILES[i].p || '';
      FX.sel = new Set([i]); FX.last = i; FX.preview = i;
      fxRender();
      if (typeof showToast === 'function') showToast('已定位到 ' + name);
      return;
    }
    if (typeof navigateTo === 'function') navigateTo('A', FILES[i].p || '');
    setTimeout(() => {
      if (typeof selectOne === 'function' && typeof PA !== 'undefined' && PA.idx.includes(i)) selectOne(i);
      if (typeof showToast === 'function') showToast('已定位到 ' + name);
    }, 30);
  }

  /* ---------------- 页面进入 & 启动 ---------------- */
  const RENDER = { overview: renderOverview, organize: renderPlan, dryrun: renderDry, cleanup: renderCleanup, history: renderHist };
  document.addEventListener('zc:page', e => {
    const fn = RENDER[e.detail];
    if (fn) fn();
  });

  bind();
  Object.assign(Render, {
    overview: renderOverview, plan: renderPlan, dry: renderDry,
    cleanup: renderCleanup, hist: renderHist
  });
  commit();

  window.zcFlow = { PLAN, CL, HIST, commit, batch, Render, zcPrompt, zcPick, zcConfirm, zcRun,
  pushHistory, onUndo, renderHist: () => renderHist(), execPlan, execTrash, renderOverview, renderPlan, renderDry, renderCleanup, renderHist };
})();
