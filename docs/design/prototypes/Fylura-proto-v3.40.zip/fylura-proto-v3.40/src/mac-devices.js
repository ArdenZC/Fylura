/* ===== macOS：外部存储（Finder 侧栏里的设备）
   数据与状态机在 devices.js（两套共用）。Finder 的侧栏不显示容量条，
   所以这里只给「名字 + 状态徽标 + 弹出」，容量放进 title 与文件页的工具栏提示。
   ============================================================ */
(function () {
  'use strict';
  const D = window.zcDevices;
  if (!D) return;
  const $ = (s, r = document) => r.querySelector(s);
  const toast = m => { if (typeof showToast === 'function') showToast(m); };
  const ICON = { usb: 'i-usb', sd: 'i-sdcard', nas: 'i-nas', phone: 'i-phone', cloud: 'i-cloud' };
  const dark = () => document.documentElement.classList.contains('dark');

  function buildGroup() {
    if ($('#fxDevs')) return;
    const side = $('.fx-side-scroll');
    if (!side) return;
    const groups = [...side.querySelectorAll('.fx-group')];
    const pos = groups.find(g => (g.querySelector('.fx-group-h') || {}).textContent === '位置');
    const wrap = document.createElement('div');
    wrap.className = 'fx-group';
    wrap.innerHTML = '<div class="fx-group-h">外部设备</div><div id="fxDevs"></div>';
    if (pos && pos.nextSibling) side.insertBefore(wrap, pos.nextSibling);
    else side.appendChild(wrap);
  }

  function rowHTML(d) {
    const open = D.isOpen(d);
    const off = d.state === 'offline';
    const busy = d.state === 'mounting' || d.state === 'ejecting' || d.state === 'signingin';
    let chip = '';
    if (d.state === 'readonly') chip = '<span class="dev-chip is-ro">只读</span>';
    else if (d.state === 'signedout') chip = '<span class="dev-chip is-cloud">未登录</span>';
    else if (off) chip = '<span class="dev-chip is-off">已断开</span>';
    else if (busy) chip = '<span class="dev-chip">' + (d.state === 'ejecting' ? '弹出中' : '连接中') + '</span>';
    /* 设备名进 title 属性、也要进 innerHTML：同样要转义，否则带引号的名字会破属性 */
    const title = zcEsc(d.name + ' · ' + d.bus + (open ? ' · 可用 ' + D.gb(d.total - d.used) + ' / ' + D.gb(d.total) : ''));
    const eject = (open && d.ejectable)
      ? '<span class="dev-eject" role="button" tabindex="0" data-act="eject" title="推出">⏏</span>' : '';
    return '<button class="fx-srow' + (off ? ' is-off' : '') + (busy ? ' is-busy' : '') + '" type="button"' +
      ' data-dev="' + d.id + '" title="' + title + '">' +
      '<svg><use href="#' + (ICON[d.kind] || 'i-usb') + '"/></svg><span class="dev-nm">' + zcEsc(d.name) + '</span>' + chip + eject + '</button>';
  }

  function render() {
    buildGroup();
    const box = $('#fxDevs');
    if (!box) return;
    box.innerHTML = D.list().map(rowHTML).join('');
  }

  document.addEventListener('click', e => {
    const ej = e.target.closest('#fxDevs .dev-eject');
    if (ej) { e.stopPropagation(); e.preventDefault(); e.target.closest('[data-dev]') && D.eject(e.target.closest('[data-dev]').dataset.dev); return; }
    const row = e.target.closest('#fxDevs [data-dev]');
    if (!row) return;
    const d = D.get(row.dataset.dev);
    if (!d) return;
    if (D.isOpen(d)) { gotoPage('library'); fxNav(d.mount); return; }
    if (d.state === 'offline') return D.connect(d.id);
    if (d.state === 'signedout') return D.signIn(d.id);
    toast(d.name + (d.state === 'mounting' ? ' 正在连接…' : ' 正在弹出…'));
  });

  document.addEventListener('contextmenu', e => {
    const row = e.target.closest('#fxDevs [data-dev]');
    if (!row || typeof openMenuAt !== 'function') return;
    e.preventDefault();
    const d = D.get(row.dataset.dev);
    if (!d) return;
    openMenuAt(e.clientX, e.clientY, [
      { label: '打开', act: () => D.isOpen(d) ? (gotoPage('library'), fxNav(d.mount)) : D.connect(d.id) },
      { label: '换入到本机…', act: () => D.importFrom(d.id) },
      'sep',
      { label: '推出', act: () => D.eject(d.id) },
      { label: '重新连接', act: () => D.connect(d.id) },
      'sep',
      { label: '在 Finder 中显示', act: () => toast('原型：在 Finder 中显示 ' + d.name) }
    ]);
  });

  /* 云端文件：行内徽标 + 打开时先下载 */
  const baseRow = window.rowHTML;
  if (typeof baseRow === 'function') {
    window.rowHTML = function (i) {
      let s = baseRow.apply(this, arguments);
      const f = FILES[i];
      if (f && f.cloud) {
        s = s.replace('<span class="fname">' + f.n + '</span>',
          '<span class="fname">' + f.n + '</span><span class="chip-cloud">仅云端</span>');
      }
      return s;
    };
  }
  const baseOpen = window.openQP;
  if (typeof baseOpen === 'function') {
    window.openQP = function (i) {
      const f = FILES[i];
      if (f && f.cloud) { D.download(f.n); return; }
      return baseOpen.apply(this, arguments);
    };
  }

  D.configure({
    toast,
    redraw: () => { if (typeof fxRender === 'function') fxRender(); render(); },
    openPath: p => { gotoPage('library'); if (typeof fxNav === 'function') fxNav(p); },
    historyPush: e => { if (window.zcFlow && zcFlow.pushHistory) zcFlow.pushHistory(e); },
    panePaths: () => (typeof FX !== 'undefined' ? [FX.path] : [])
  });
  D.onChange(() => { render(); if (typeof fxRender === 'function') fxRender(); });

  render();
})();
