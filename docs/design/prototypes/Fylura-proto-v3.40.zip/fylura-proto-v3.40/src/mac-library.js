/* ===== macOS 文件库：平台适配（只注入 redesign-v2-macos.html）=====
   能力与 Windows 版共用 src/file-ops.js；这里只把 FX 的选中模型接上去，
   并按 Finder 的语言重写「更多」与右键菜单。形态是 Finder，能力是同一套。 */
(function () {
  'use strict';
  const ops = window.zcOps;
  if (!ops) return;
  const toast = m => { if (typeof showToast === 'function') showToast(m); };
  const dark = () => document.documentElement.classList.contains('dark');

  ops.configure({
    path: () => FX.path || '',
    ids: () => (FX.sel.size ? [...FX.sel] : (FX.last != null ? [FX.last] : [])),
    select: i => { FX.sel = new Set([i]); FX.last = i; FX.preview = i; fxRender(); },
    setSelection: list => {
      FX.sel = new Set(list);
      FX.last = list.length ? list[list.length - 1] : null;
      FX.preview = FX.last;
      fxRender();
    },
    redraw: () => fxRender(),
    preview: i => openQP(i),
    navTo: p => { gotoPage('library'); fxNav(p); },
    toast,
    onFavChange: () => {},
    /* 必须 return：file-ops 靠这个返回值记住「快捷撤销对应哪条历史」，
       原来没返回，Ctrl+Z 恢复文件后历史里仍显示未撤销 */
    historyPush: e => (window.zcFlow ? window.zcFlow.pushHistory(e) : null),
    onUndo: (kind, fn) => { if (window.zcFlow) window.zcFlow.onUndo(kind, fn); }
  });

  /* ---------- 更多 ---------- */
  window.fxMoreMenu = function (anchor) {
    openMenu(anchor, [
      { label: '刷新', act: () => { fxRender(); toast('已刷新'); } },
      { label: '全选<span class="mk">⌘A</span>', act: () => {
          if (!FX.ids.length) return toast('这个文件夹是空的');
          FX.sel = new Set(FX.ids); FX.last = FX.ids[FX.ids.length - 1] || null;
          fxPaintSelection(); toast('已全选 ' + FX.ids.length + ' 项');
        } },
      { label: '反选', act: () => ops.invert(FX.ids, new Set(FX.sel.size ? [...FX.sel] : (FX.last != null ? [FX.last] : []))) },
      { label: '双栏对比', on: FX.dual, act: () => document.getElementById('fxDualBtn').click() },
      'sep',
      { label: '新建文件', act: () => ops.newFile() },
      { label: '新建文件夹', act: () => ops.newFolder() },
      { label: '创建副本', act: () => ops.duplicate() },
      'sep',
      { label: '拷贝<span class="mk">⌘C</span>', act: () => ops.setClip('copy') },
      { label: '剪切<span class="mk">⌘X</span>', act: () => ops.setClip('cut') },
      { label: '粘贴<span class="mk">⌘V</span>', act: () => ops.paste() },
      'sep',
      { label: '新建标签页<span class="mk">⌘T</span>', act: fxAddTab },
      { label: '显示简介<span class="mk">⌘I</span>', act: () => fxToggleInfo() },
      { label: '加入篮子<span class="mk">⌘B</span>', act: fxBasketAdd },
      { label: '打开篮子', act: () => fxBasketOpen(true) },
      'sep',
      { label: '收藏当前文件夹', act: () => ops.toggleFav() },
      { label: '收藏的文件夹…', act: () => ops.openFavs() },
      { label: '打开方式…', act: () => ops.openWith() },
      'sep',
      { label: '整理文件…', act: () => gotoPage('organize') },
      { label: '空间清理…', act: () => gotoPage('cleanup') },
      { label: '切换到' + (dark() ? '浅色' : '深色'), act: () => document.documentElement.classList.toggle('dark') }
    ]);
  };

  /* ---------- 行右键：捕获阶段接管（空白区仍走原来的视图/排序菜单） ---------- */
  if (typeof FX_MAIN !== 'undefined' && FX_MAIN) {
    FX_MAIN.addEventListener('contextmenu', e => {
      const row = e.target.closest('[data-i]');
      if (!row) return;
      e.preventDefault();
      e.stopPropagation();
      const i = +row.dataset.i;
      const f = FILES[i];
      if (!f) return;
      if (!FX.sel.has(i)) {
        FX.sel = new Set([i]); FX.last = i;
        FX.preview = f.folder ? null : i;
        fxRender();
      }
      openMenuAt(e.clientX, e.clientY, [
        { label: f.folder ? '打开' : '快速查看<span class="mk">空格</span>', act: () => f.folder ? fxNav(f.full) : openQP(i) },
        { label: '打开方式…', act: () => ops.openWith() },
        'sep',
        { label: '重命名…', act: () => ops.rename(i) },
        { label: '创建副本', act: () => ops.duplicate() },
        { label: '拷贝<span class="mk">⌘C</span>', act: () => ops.setClip('copy') },
        { label: '剪切<span class="mk">⌘X</span>', act: () => ops.setClip('cut') },
        { label: '粘贴到此处<span class="mk">⌘V</span>', act: () => ops.paste() },
        'sep',
        { label: '加入篮子<span class="mk">⌘B</span>', act: fxBasketAdd },
        { label: '收藏所在文件夹', act: () => ops.toggleFav(f.p) },
        { label: '显示简介<span class="mk">⌘I</span>', act: () => fxToggleInfo(true) },
        'sep',
        { label: '<span style="color:var(--danger)">移到废纸篓</span><span class="mk">⌘⌫</span>', act: () => ops.del() }
      ]);
    }, true);
  }

  /* ---------- ⌘C / ⌘X / ⌘V ---------- */
  document.addEventListener('keydown', e => {
    if (!(e.metaKey || e.ctrlKey)) return;
    if (!document.querySelector('#p-library.active')) return;
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    const k = e.key.toLowerCase();
    if (k === 'c') { e.preventDefault(); ops.setClip('copy'); }
    else if (k === 'x') { e.preventDefault(); ops.setClip('cut'); }
    else if (k === 'v') { e.preventDefault(); ops.paste(); }
    else if (k === 'z') { e.preventDefault(); if (!ops.quickUndo()) toast('没有可撤销的删除'); }
  });

  /* ⌘⌫ 移到废纸篓 */
  document.addEventListener('keydown', e => {
    if (!document.querySelector('#p-library.active')) return;
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    if (e.key === 'Backspace' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); ops.del(); }
    else if (e.key === 'Delete') { e.preventDefault(); ops.del(); }
  });

  window.maclib = { ops };
})();
