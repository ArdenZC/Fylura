/* ===== 动效层：弹簧入场 / 快速退场 + 规范页重播 =====
   为什么菜单要在这里接管：fmMenu 是同一个 DOM 节点反复复用的，CSS animation
   只在第一次 hidden→false 时播一次，之后再也不播。WAAPI 则每次调用都重新
   播放，而且能取消上一段 —— 用户快速连点两个「更多」时不会两段动画叠在一起。
   ================================================================= */
(function () {
  'use strict';
  if (window.__zcMotion) return;
  window.__zcMotion = true;

  const RM = matchMedia('(prefers-reduced-motion: reduce)');
  const SPRING = 'cubic-bezier(.34,1.38,.64,1)';
  const EXIT = 'cubic-bezier(.4,0,1,1)';
  const D_IN = 240, D_OUT = 130;

  const menuEl = () => document.getElementById('fmMenu');
  let picked = false;      /* 这一次关闭是「点中菜单项」，要瞬关 */
  let closing = false;
  let outAnim = null;

  /* 点菜单项 → 菜单该立刻消失（系统菜单也是这样）；点空白 → 淡出 */
  document.addEventListener('click', e => {
    const m = menuEl();
    if (m && !m.hidden && m.contains(e.target)) picked = true;
  }, true);

  function cancelOut() {
    if (outAnim) { try { outAnim.cancel(); } catch (_e) {} outAnim = null; }
    closing = false;
  }

  function playIn() {
    const m = menuEl();
    if (!m || m.hidden || RM.matches) return;
    cancelOut();
    const up = m.dataset.side === 'up';
    m.style.transformOrigin = up ? 'bottom left' : 'top left';
    /* from 的方向 = 锚点所在的方向：菜单在下方，就从上方长下来 */
    m.animate([
      { opacity: 0, transform: 'translateY(' + (up ? 6 : -6) + 'px) scale(.96)' },
      { opacity: 1, transform: 'translateY(0) scale(1)' }
    ], { duration: D_IN, easing: SPRING });
  }

  function playOut(then) {
    const m = menuEl();
    if (!m || m.hidden || RM.matches) { then(); return; }
    if (closing) return;
    closing = true;
    const up = m.dataset.side === 'up';
    m.style.transformOrigin = up ? 'bottom left' : 'top left';
    outAnim = m.animate([
      { opacity: 1, transform: 'translateY(0) scale(1)' },
      { opacity: 0, transform: 'translateY(' + (up ? -4 : 4) + 'px) scale(.985)' }
    ], { duration: D_OUT, easing: EXIT });
    outAnim.onfinish = () => { outAnim = null; closing = false; then(); };
  }

  /* 包装三个全局菜单函数；锚点方向靠最终位置与锚点比较得出 */
  const rawOpen = window.openMenu;
  const rawOpenAt = window.openMenuAt;
  const rawClose = window.closeMenu;

  if (typeof rawOpen === 'function') {
    window.openMenu = function (anchor, items) {
      rawOpen.apply(this, arguments);
      const m = menuEl();
      if (!m) return;
      const r = anchor && anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : null;
      m.dataset.side = r && m.getBoundingClientRect().top < r.top ? 'up' : 'down';
      playIn();
    };
  }
  if (typeof rawOpenAt === 'function') {
    window.openMenuAt = function (x, y, items) {
      rawOpenAt.apply(this, arguments);
      const m = menuEl();
      if (!m) return;
      /* 坐标菜单：落点比 y 小说明被翻到上方了 */
      m.dataset.side = m.getBoundingClientRect().top < y - 4 ? 'up' : 'down';
      playIn();
    };
  }
  if (typeof rawClose === 'function') {
    window.closeMenu = function () {
      const m = menuEl();
      if (!m || m.hidden) { picked = false; return; }
      if (picked) { picked = false; cancelOut(); rawClose(); return; }
      playOut(() => rawClose());
    };
  }

  /* ---------- 复用节点的入场上浮 ----------
     spot / 预览 / 设置页下拉都靠 hidden 属性开关同一个节点，CSS animation 只在
     第一次插进文档时跑一遍。这里用 MutationObserver 只盯 hidden 这一条属性，
     变化极少（一次交互一次），不会拖慢渲染。 */
  const POPS = [
    { sel: '#spot', inner: '.spot-box', y: -8, s: .97, o: 'top center', d: 260 },
    { sel: '#qp', inner: '.qp-box', y: 12, s: .96, o: 'center', d: 280 },
    { sel: '.dd-menu', inner: null, y: -5, s: .98, o: 'top right', d: 200 }
  ];

  function pop(el, r) {
    const inner = r.inner ? el.querySelector(r.inner) : null;
    const target = inner || el;
    const up = r.sel === '.dd-menu' && el.closest('.dd') && el.closest('.dd').classList.contains('up');
    target.style.transformOrigin = up ? 'bottom right' : r.o;
    target.getAnimations().forEach(a => a.cancel());
    el.getAnimations().forEach(a => a.cancel());
    target.animate([
      { opacity: 0, transform: 'translateY(' + r.y + 'px) scale(' + r.s + ')' },
      { opacity: 1, transform: 'none' }
    ], { duration: r.d, easing: SPRING });
    if (inner) el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: 'cubic-bezier(.32,.72,0,1)' });
  }

  new MutationObserver(list => {
    if (RM.matches) return;
    list.forEach(m => {
      const el = m.target;
      if (!(el instanceof Element) || el.hasAttribute('hidden')) return;
      for (const r of POPS) {
        if (el.matches(r.sel)) { pop(el, r); break; }
      }
    });
  }).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['hidden'] });

  /* ---------- 规范页「重播」 ---------- */
  const btn = document.getElementById('moPlay');
  if (!btn) return;
  btn.addEventListener('click', () => {
    ['moDurations', 'moEases'].forEach(id => {
      const box = document.getElementById(id);
      if (!box) return;
      box.classList.remove('is-run');
      void box.offsetWidth;          /* 强制重排，动画才会重播 */
      box.classList.add('is-run');
    });
    /* 不主动清除：animation-fill-mode: both 会让圆点停在终点，
       下次点「重播」时移除类 → 瞬间回到起点 → 再跑一遍，比原地回弹自然 */
  });
})();
