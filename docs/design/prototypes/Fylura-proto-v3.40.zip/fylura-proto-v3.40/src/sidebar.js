/* ===== 应用侧栏：折叠成图标轨道（两套原型共用） =====
   导航项的文字是文本节点，CSS 选不到，所以这里先把文字包进 span，
   折叠时才有东西可隐藏。状态记在 localStorage，刷新后保持。
   ==================================================== */
(function () {
  'use strict';
  if (window.__zcSidebar) return;
  window.__zcSidebar = true;

  const body = document.querySelector('.body');
  const side = document.querySelector('.side');
  if (!body || !side) return;
  const KEY = 'fylura:side-rail';

  /* 1. 文字包一层 span；顺便给每个图标补 title（轨道里只能靠 tooltip） */
  side.querySelectorAll('.nav-item').forEach(btn => {
    let label = '';
    [...btn.childNodes].forEach(n => {
      if (n.nodeType === 3 && n.textContent.trim()) {
        label += n.textContent.trim();
        const s = document.createElement('span');
        s.className = 'nav-txt';
        s.textContent = n.textContent.trim();
        n.replaceWith(s);
      }
    });
    if (label && !btn.title) btn.title = label;
  });

  /* 2. 折叠按钮 */
  const brand = side.querySelector('.brand');
  let toggle = null;
  if (brand) {
    toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'side-toggle';
    toggle.id = 'sideToggle';
    toggle.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>';
    brand.appendChild(toggle);
  }

  const ws = side.querySelector('.workspace');
  if (ws && !ws.title) ws.title = '本地工作区 · 本地优先，AI 关闭';

  function apply(rail, silent, persist) {
    body.classList.toggle('side-rail', rail);
    side.classList.toggle('is-rail', rail);
    if (toggle) {
      toggle.setAttribute('aria-expanded', String(!rail));
      toggle.setAttribute('aria-label', rail ? '展开侧栏' : '收起侧栏');
      toggle.title = rail ? '展开侧栏' : '收起侧栏';
    }
    if (persist !== false) { try { localStorage.setItem(KEY, rail ? '1' : '0'); } catch (_e) {} }
    if (!silent) {
      /* 折叠后焦点可能落在被隐藏的元素上 */
      const a = document.activeElement;
      if (a && a.closest && a.closest('.side') && a !== toggle && rail) toggle && toggle.focus({ preventScroll: true });
    }
  }

  /* 窄窗口默认收成图标轨道。
     850×680 下 216px 的全局导航会把 Finder 列视图挤到只能看到两列半 ——
     折叠后省 152px，第三列才露得出来。用户只要亲手切过一次，就完全尊重他的选择，
     不再自动改。 */
  let preferred = null;
  try {
    const v = localStorage.getItem(KEY);
    if (v === '1') preferred = true;
    else if (v === '0') preferred = false;
  } catch (_e) {}
  const NARROW = 940;
  const wantRail = () => (preferred !== null ? preferred : innerWidth <= NARROW);

  if (toggle) {
    toggle.addEventListener('click', () => {
      const next = !body.classList.contains('side-rail');
      preferred = next;
      apply(next, false, true);
    });
  }

  apply(wantRail(), true, preferred !== null);

  let rzT = 0;
  addEventListener('resize', () => {
    clearTimeout(rzT);
    rzT = setTimeout(() => {
      const w = wantRail();
      if (w !== body.classList.contains('side-rail')) apply(w, true, false);
    }, 120);
  });

  window.zcSide = { toggle: v => apply(v === undefined ? !body.classList.contains('side-rail') : !!v) };
})();
