/* ===== Windows 文件库：外部存储的界面部分（只注入 Windows 版）
   设备数据与状态机在 dev/… devices.js（两套共用），这里只负责：
   1) 侧栏「外部设备」组；
   2) 每个窗格顶部的设备条（只读标识 / 换入 / 安全弹出）；
   3) 路径落在已断开设备上时的空态；
   4) 云端文件的「仅云端」徽标与按需下载。
   ============================================================ */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const D = window.zcDevices;
  if (!D) return;

  const ORDER = ['A', 'B', 'C', 'D'];
  const ICON = { usb: 'i-usb', sd: 'i-sdcard', nas: 'i-nas', phone: 'i-phone', cloud: 'i-cloud' };
  const toast = m => { if (typeof showToast === 'function') showToast(m); };
  const paneEl = k => document.getElementById('pane' + k);
  const pathOf = k => (typeof paneState === 'function' ? paneState(k).path : '');
  const visiblePanes = () => ORDER.filter(k => { const el = paneEl(k); return el && !el.hidden; });

  /* ---------------- 1. 侧栏 ---------------- */
  function buildGroup() {
    if ($('#treeDevs')) return;
    const scroll = $('.fm-tree-scroll');
    if (!scroll) return;
    const volRows = $$('.tree-row.tree-vol', scroll);
    const anchor = volRows[volRows.length - 1];
    const title = document.createElement('div');
    title.className = 'tree-group dev-group-h';
    title.innerHTML = '外部设备';
    const box = document.createElement('div');
    box.id = 'treeDevs';
    if (anchor) { anchor.after(title); title.after(box); }
    else scroll.appendChild(box);
  }

  function devRow(d) {
    const open = D.isOpen(d);
    const busy = d.state === 'mounting' || d.state === 'ejecting' || d.state === 'signingin';
    const off = d.state === 'offline';
    const cls = ['tree-row', 'tree-vol', 'dev-row'];
    if (off) cls.push('is-off');
    if (busy) cls.push('is-busy');
    let sub, chip = '', act = '';
    if (d.state === 'mounting') sub = '正在连接…';
    else if (d.state === 'ejecting') sub = '正在安全弹出…';
    else if (d.state === 'signingin') sub = '正在登录…';
    else if (off) sub = '已断开 · 上次 ' + (d.lastAt || '更早');
    else if (d.state === 'signedout') sub = '未登录 · 点此登录';
    else sub = '可用 ' + D.gb(d.total - d.used) + ' / ' + D.gb(d.total);

    if (d.state === 'readonly') chip = '<span class="dev-chip is-ro">只读</span>';
    else if (d.state === 'signedout') chip = '<span class="dev-chip is-cloud">未登录</span>';
    else if (d.kind === 'cloud') chip = '<span class="dev-chip is-cloud">云盘</span>';
    else if (off) chip = '<span class="dev-chip is-off">已断开</span>';

    if (d.ejectable && open) act = '<button class="dev-act" type="button" data-act="eject" title="安全弹出" aria-label="安全弹出 ' + zcEsc(d.name) + '"><svg><use href="#i-eject"/></svg></button>';
    else if (off) act = '<button class="dev-act" type="button" data-act="connect" title="重新连接" aria-label="重新连接 ' + zcEsc(d.name) + '"><svg><use href="#i-refresh"/></svg></button>';

    const pct = Math.round(Math.min(100, d.used / d.total * 100));
    const bar = (open && d.kind !== 'cloud' || (open && d.kind === 'cloud'))
      ? '<span class="vol-bar"><i style="width:' + pct + '%"></i></span>' : '';
    return '<div class="' + cls.join(' ') + '" data-dev="' + d.id + '" role="button" tabindex="0"' +
      ' aria-label="' + zcEsc(d.name + '，' + sub) + '">' +
      '<svg class="dev-ico"><use href="#' + (ICON[d.kind] || 'i-usb') + '"/></svg>' +
      '<span class="vol-copy"><span class="tree-name"><b>' + zcEsc(d.name) + '</b>' + chip + '</span>' +
      '<span class="vol-sub">' + sub + '</span>' + bar + '</span>' + act + '</div>';
  }

  function renderDevs() {
    buildGroup();
    const box = $('#treeDevs');
    if (!box) return;
    box.innerHTML = D.list().map(devRow).join('');
    const cur = pathOf(focus);
    const curDev = D.devOfPath(cur);
    $$('.dev-row', box).forEach(el => {
      const d = D.get(el.dataset.dev);
      el.classList.toggle('is-current', !!curDev && curDev.id === el.dataset.dev);
    });
  }

  /* ---------------- 2. 窗格设备条 ---------------- */
  function ensureBars() {
    ORDER.forEach(k => {
      const pane = paneEl(k);
      if (!pane || pane.querySelector('.dev-bar')) return;
      const head = pane.querySelector('.fm-pane-head');
      const bar = document.createElement('div');
      bar.className = 'dev-bar';
      bar.hidden = true;
      if (head) head.after(bar);
    });
  }

  function updateBars() {
    ensureBars();
    ORDER.forEach(k => {
      const pane = paneEl(k);
      if (!pane) return;
      const bar = pane.querySelector('.dev-bar');
      if (!bar) return;
      const d = D.devOfPath(pathOf(k));
      if (!d || !D.isOpen(d)) { bar.hidden = true; return; }
      const ro = d.state === 'readonly';
      const cloud = d.kind === 'cloud';
      const meta = '可用 ' + D.gb(d.total - d.used) + ' / ' + D.gb(d.total);
      bar.hidden = false;
      bar.title = d.name + ' · ' + d.bus;
      bar.classList.toggle('is-ro', ro);
      bar.innerHTML =
        '<svg><use href="#' + (ICON[d.kind] || 'i-usb') + '"/></svg><b>' + zcEsc(d.name) + '</b>' +
        '<span class="dev-bar-meta">' + meta + '</span>' +
        (ro ? '<span class="dev-chip is-ro">只读</span>' : '') +
        '<span class="dev-bar-gap"></span>' +
        '<button class="btn btn-ghost" type="button" data-act="import">' + (cloud ? '下载全部' : '换入到本机') + '</button>' +
        (d.ejectable ? '<button class="btn btn-ghost" type="button" data-act="eject">安全弹出</button>' : '');
    });
  }

  /* ---------------- 3. 设备已断开 ---------------- */
  const IDLE = {
    offline: d => ({
      t: '设备已断开',
      d: zcEsc(d.name) + ' 已弹出或不在连接状态。重新连上后点「重新连接」，或换到工作区继续。',
      acts: [['connect', '重新连接', 'btn-primary'], ['home', '回到工作区', 'btn-ghost']]
    }),
    signedout: d => ({
      t: '还没有登录 ' + zcEsc(d.name),
      d: '登录后这个文件夹才会显示内容；没下载过的文件会标成「仅云端」。',
      acts: [['signin', '登录 ' + zcEsc(d.name), 'btn-primary'], ['home', '回到工作区', 'btn-ghost']]
    }),
    signingin: d => ({ t: '正在登录 ' + zcEsc(d.name) + '…', d: '完成授权后会自动回到这里。', acts: [] }),
    mounting: d => ({ t: '正在连接 ' + d.name + '…', d: '设备已识别，正在读取文件列表。', acts: [] }),
    ejecting: d => ({ t: '正在安全弹出…', d: '正在把没写完的内容写完，完成后就可以拔下。', acts: [] })
  };

  let idleHidInfo = false, infoBefore = true;
  const infoOn = () => !document.querySelector('.lib').classList.contains('info-off');

  function toggleInfoForIdle(idle) {
    if (idle && !idleHidInfo) {
      infoBefore = infoOn();
      idleHidInfo = true;
      if (typeof setInfo === 'function') setInfo(false);
    } else if (!idle && idleHidInfo) {
      idleHidInfo = false;
      if (typeof setInfo === 'function') setInfo(infoBefore);
    }
  }

  function paintIdle() {
    const focusedDev = D.devOfPath(pathOf(focus));
    toggleInfoForIdle(!!focusedDev && !D.isOpen(focusedDev));
    visiblePanes().forEach(k => {
      const pane = paneEl(k);
      const rows = pane && pane.querySelector('.rows');
      if (!rows) return;
      const d = D.devOfPath(pathOf(k));
      if (!d || D.isOpen(d)) {
        ['filter', 'sort', 'view', 'more'].forEach(x => {
          const b = pane.querySelector('#' + x + k);
          if (b) b.disabled = false;
        });
        return;
      }
      const spec = IDLE[d.state] ? IDLE[d.state](d) : IDLE.offline(d);
      const cnt = pane.querySelector('.fm-pane-count');
      if (cnt) cnt.textContent = spec.t.replace('…', '');
      /* 设备不在，筛选/排序/视图这些动作没有对象，置灰而不是让它们点空 */
      ['filter', 'sort', 'view', 'more'].forEach(x => {
        const b = pane.querySelector('#' + x + k);
        if (b) b.disabled = true;
      });
      if (k === focus) {
        const c = document.getElementById('stCount');
        if (c) c.textContent = '0 项';
        const sz = document.getElementById('stSize');
        if (sz) sz.textContent = '—';
        const se = document.getElementById('stSel');
        if (se) se.hidden = true;
      }
      rows.className = 'rows';
      rows.innerHTML =
        '<div class="empty dev-off"><span class="empty-art"><svg width="26" height="26"><use href="#' + (ICON[d.kind] || 'i-usb') + '"/></svg></span>' +
        '<b>' + spec.t + '</b><p>' + spec.d + '</p>' +
        (spec.acts.length ? '<div class="acts">' + spec.acts.map(([act, label, cls]) =>
          '<button class="btn ' + cls + '" type="button" data-act="' + act + '" data-dev="' + d.id + '">' + label + '</button>').join('') + '</div>' : '') +
        '</div>';
    });
  }

  /* ---------------- 4. 云端文件 ---------------- */
  const baseParts = window.nameParts;
  window.nameParts = function (n) {
    const html = baseParts.apply(this, arguments);
    const f = (typeof FILES !== 'undefined') ? FILES.find(x => x.n === n && x.cloud) : null;
    return f ? html + '<span class="chip-cloud">仅云端</span>' : html;
  };

  const baseOpenQP = window.openQP;
  window.openQP = function (i) {
    const f = FILES[i];
    if (f && f.cloud) { D.download(f.n); return; }
    return baseOpenQP.apply(this, arguments);
  };

  const baseRowMenu = window.rowMenu;
  window.rowMenu = function (x, y, idx, side) {
    const f = FILES[idx];
    if (f && f.cloud && typeof openMenuAt === 'function') {
      openMenuAt(x, y, [
        { label: '下载到本机', act: () => D.download(f.n) },
        { label: '复制链接', act: () => toast('已复制共享链接') },
        'sep',
        { label: '重命名…', act: () => window.zcOps && zcOps.rename(idx) },
        { label: '移动到…', act: () => toast('原型：选择目标文件夹') },
        'sep',
        { label: '在云端打开', act: () => toast('原型：用浏览器打开') }
      ]);
      return;
    }
    return baseRowMenu.apply(this, arguments);
  };

  /* ---------------- 5. 交互 ---------------- */
  function deviceAction(id, act) {
    const d = D.get(id);
    if (!d) return;
    if (act === 'eject') return D.eject(id);
    if (act === 'connect') return D.connect(id);
    if (act === 'import') return D.importFrom(id);
  }

  document.addEventListener('click', e => {
    const actBtn = e.target.closest('.dev-act, .dev-bar [data-act]');
    if (actBtn) {
      e.stopPropagation();
      const host = actBtn.closest('[data-dev]') || actBtn.closest('.fm-pane');
      const devEl = actBtn.closest('[data-dev]');
      if (devEl) return deviceAction(devEl.dataset.dev, actBtn.dataset.act);
      if (host) {
        const d = D.devOfPath(pathOf(host.id.replace('pane', '')));
        if (d) return deviceAction(d.id, actBtn.dataset.act);
      }
      return;
    }
    const row = e.target.closest('#treeDevs .dev-row');
    if (row) {
      const d = D.get(row.dataset.dev);
      if (!d) return;
      if (D.isOpen(d)) return navigateTo(focus, d.mount);
      if (d.state === 'offline') { D.connect(d.id); return; }
      if (d.state === 'signedout') { D.signIn(d.id); return; }
      toast(d.name + (d.state === 'mounting' ? ' 正在连接…' : ' 正在弹出…'));
    }
    const idleBtn = e.target.closest('.dev-off [data-act]');
    if (idleBtn) {
      const act = idleBtn.dataset.act;
      if (act === 'home') { navigateTo(focus, 'Documents / Workspace'); return; }
      if (act === 'signin') { D.signIn(idleBtn.dataset.dev); return; }
      if (act === 'connect') { D.connect(idleBtn.dataset.dev); return; }
    }
  });

  document.addEventListener('keydown', e => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const row = e.target.closest && e.target.closest('#treeDevs .dev-row');
    if (!row) return;
    e.preventDefault();
    row.click();
  });

  /* 右键设备行：能力入口（换入 / 弹出 / 重新连接） */
  document.addEventListener('contextmenu', e => {
    const row = e.target.closest('#treeDevs .dev-row');
    if (!row || typeof openMenuAt !== 'function') return;
    e.preventDefault();
    const d = D.get(row.dataset.dev);
    if (!d) return;
    const open = D.isOpen(d);
    openMenuAt(e.clientX, e.clientY, [
      { label: '在新窗格中打开', act: () => open ? openInNewPane(d) : toast('设备不可用') },
      { label: '换入到本机…', act: () => D.importFrom(d.id), on: false },
      'sep',
      { label: '安全弹出', act: () => D.eject(d.id) },
      { label: '重新连接', act: () => D.connect(d.id) },
      'sep',
      { label: '在系统中显示', act: () => toast('原型：在资源管理器中显示 ' + d.name) }
    ].filter(Boolean));
  });

  function openInNewPane(d) {
    /* 空着的窗格优先；都没有就开左右双栏 */
    const used = visiblePanes();
    const free = ORDER.find(k => used.indexOf(k) < 0);
    if (!free) { if (typeof setLayout === 'function') setLayout('2v'); }
    const target = free && free !== 'A' ? free : (used.length < 2 ? 'B' : 'A');
    if (!visiblePanes().includes(target)) return;
    navigateTo(target, d.mount);
    if (typeof focusPane === 'function') focusPane(target);
  }

  /* 更多菜单里原来那两条「原型：从外部磁盘换入」的占位，换成真的设备选择 */
  async function pickDeviceForImport() {
    const Z = window.zcFlow || {};
    const list = D.list().filter(d => D.canImport(d));
    if (!list.length) { toast('现在没有已连接的设备'); return; }
    if (!Z.zcPick) return;
    const i = await Z.zcPick({
      title: '从哪个设备换入？',
      sub: '只复制，不会删除设备上的原文件。',
      items: list.map(d => ({
        label: d.name,
        desc: d.bus + ' · ' + D.gb(d.total - d.used) + ' 可用' + (d.state === 'readonly' ? ' · 只读' : '')
      }))
    });
    if (i == null) return;
    D.importFrom(list[i].id);
  }

  const baseMore = window.moreItems;
  if (typeof baseMore === 'function') {
    window.moreItems = function (side) {
      const items = baseMore.apply(this, arguments) || [];
      return items.map(it => {
        if (!it || typeof it !== 'object' || !it.label) return it;
        if (String(it.label).indexOf('外部换入') === 0) return { label: '从外部设备换入…', act: pickDeviceForImport };
        if (String(it.label).indexOf('外部复制') === 0) return { label: '复制到设备…', act: () => toast('原型：选目标设备后复制过去') };
        return it;
      });
    };
  }

  /* ---------------- 6. 接线 ---------------- */
  D.configure({
    toast,
    redraw: () => { if (typeof renderAll === 'function') renderAll(); renderDevs(); },
    openPath: p => navigateTo(focus, p),
    historyPush: e => { if (window.zcFlow && zcFlow.pushHistory) zcFlow.pushHistory(e); },
    panePaths: () => visiblePanes().map(pathOf)
  });
  D.onChange(() => {
    /* 设备上线/下线会改变「这个路径还能不能列出东西」，必须重画一次窗格，
       否则会出现「设备连上了、列表还是 0 项」 */
    if (typeof renderAll === 'function') renderAll();
    after();
  });

  let queued = false;
  function after() {
    if (queued) return;
    queued = true;
    queueMicrotask(() => {
      queued = false;
      updateBars();
      paintIdle();
      renderDevs();
    });
  }

  ['render', 'renderB', 'renderAll', 'paintPane'].forEach(name => {
    const base = window[name];
    if (typeof base !== 'function') return;
    window[name] = function () {
      const r = base.apply(this, arguments);
      after();
      return r;
    };
  });

  buildGroup();
  ensureBars();
  renderDevs();
  after();
})();
