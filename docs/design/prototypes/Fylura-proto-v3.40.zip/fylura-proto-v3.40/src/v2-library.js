/* ===== Windows 文件库：平台适配（只注入 redesign-v2.html）=====
   能力本身在 src/file-ops.js（两套共用），这里只做三件事：
   1) 用 PA / multi 这套模型实现 adapter；
   2) 组装「更多」菜单与行右键菜单；
   3) Windows 特有的入口：上一级按钮、目录树里的收藏与最近位置、8 个标签上限、对比的两维。 */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const ops = window.zcOps;
  if (!ops) return;

  const STAR = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3.6 2.6 5.3 5.8.8-4.2 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8-4.2-4.1 5.8-.8z"/></svg>';
  const UP = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V6M6 12l6-6 6 6"/></svg>';
  const toast = m => { if (typeof showToast === 'function') showToast(m); };

  /* ---------- adapter ---------- */
  /* 这一层的选择模型必须**跟着焦点窗格走**。
     原来 ids 只判断 'B' 与「其它」，而多窗格已经扩到 A–D：聚焦 C 格复制时
     会回落到 A 格的选择，剪贴板里装的是 A 的文件 —— 界面看着对，操作打偏。
     所以凡是「当前选择」都统一问 window.paneSel(focus)。 */
  const paneKey = side => side || (typeof focus === 'string' && focus ? focus : 'A');
  /* 单选用 cur 表示（sel 为空），多选才进 sel —— 所以「当前选择」要两段拼：
     只取 sel 会让「点了一行、直接点复制」取到空列表。 */
  const sel = k => {
    if (typeof window.paneSel === 'function') {
      const s = window.paneSel(k);
      if (s && s.size) return [...s];
      const cur = typeof window.paneCur === 'function' ? window.paneCur(k) : null;
      return cur != null ? [cur] : [];
    }
    return k === 'B'
      ? (selB.size ? [...selB] : (curB != null ? [curB] : []))
      : (multi.size ? [...multi] : (current != null ? [current] : []));
  };

  ops.configure({
    /* 目录取「当前聚焦的那一格」：粘贴 / 新建都落在你正在看的地方，
       而不是永远落在 A 栏 */
    path: () => (typeof paneState === 'function' ? paneState(paneKey()).path : PA.path) || '',
    ids: side => sel(paneKey(side)),
    select: i => {
      const k = paneKey();
      if (k !== 'A' && window.zcPanes) { window.zcPanes.select(k, i); return; }
      selectOne(i);
    },
    setSelection: list => {
      const k = paneKey();
      if (k !== 'A' && typeof window.paneSel === 'function') {
        const s = window.paneSel(k);
        s.clear();
        list.forEach(i => s.add(i));
        if (list.length) window.paneSetCur(k, list[list.length - 1]);
        if (window.paintPane) window.paintPane(k);
        return;
      }
      multi.clear();
      list.forEach(i => multi.add(i));
      if (list.length) { current = list[list.length - 1]; paintInspector(FILES[current]); }
      render();
    },
    /* 任何一个窗格里发生增删改，四格都可能受影响（同目录会在多格里出现） */
    redraw: () => {
      if (typeof window.renderAll === 'function') window.renderAll();
      else { render(); if (dual) renderB(); }
      syncClipHint(); renderTreeGroups();
    },
    preview: i => openQP(i),
    navTo: p => navigateTo('A', p),
    toast,
    onFavChange: () => renderTreeGroups(),
    /* 必须 return：file-ops 靠这个返回值记住「快捷撤销对应哪条历史」，
       原来没返回，Ctrl+Z 恢复文件后历史里仍显示未撤销 */
    historyPush: e => (window.zcFlow ? window.zcFlow.pushHistory(e) : null),
    onUndo: (kind, fn) => { if (window.zcFlow) window.zcFlow.onUndo(kind, fn); }
  });

  /* ---------- 上一级 ---------- */
  function goUp() {
    if (!PA.path) return toast('已经在最上层');
    navigateTo('A', PA.path.split(' / ').slice(0, -1).join(' / '));
  }
  function addUpButton() {
    if ($('#upA')) return;
    const fwd = $('#fwdA');
    if (!fwd) return;
    const b = document.createElement('button');
    b.className = 'fm-tool';
    b.id = 'upA';
    b.type = 'button';
    b.title = '上一级';
    b.setAttribute('aria-label', '上一级');
    b.innerHTML = UP;
    b.addEventListener('click', goUp);
    fwd.after(b);
  }

  /* ---------- 目录树：收藏 / 最近位置 ---------- */
  function ensureTreeGroups() {
    const scroll = $('.fm-tree-scroll');
    if (!scroll || $('#treeFavs')) return;
    const wrap = document.createElement('div');
    wrap.innerHTML = '<div class="tree-group">收藏</div><div id="treeFavs"></div>' +
      '<div class="tree-group" id="treeRecentGroup">最近位置</div><div id="treeRecents"></div>';
    const first = scroll.querySelector('.tree-row[data-start]');
    if (first) first.after(wrap); else scroll.prepend(wrap);
  }

  function renderTreeGroups() {
    const favEl = $('#treeFavs'), recEl = $('#treeRecents');
    if (favEl) {
      favEl.innerHTML = [...ops.favs].map(p =>
        '<button class="tree-row" type="button" data-path="' + p + '">' + STAR +
        '<span class="tree-name">' + (p.split(' / ').pop() || '本机') + '</span></button>').join('') ||
        '<div class="tree-empty">还没有收藏</div>';
    }
    if (recEl) {
      const cur = PA.path || '';
      const seen = new Set([cur]);
      const list = [];
      (PA.hist || []).slice().reverse().forEach(h => {
        const p = h.path;
        if (p && !seen.has(p)) { seen.add(p); list.push(p); }
      });
      const show = list.length > 0;
      const grp = $('#treeRecentGroup');
      if (grp) grp.style.display = show ? '' : 'none';
      recEl.style.display = show ? '' : 'none';
      recEl.innerHTML = list.slice(0, 4).map(p =>
        '<button class="tree-row" type="button" data-path="' + p + '"><svg width="16" height="16"><use href="#i-clock"/></svg>' +
        '<span class="tree-name">' + (p.split(' / ').pop() || '本机') + '</span></button>').join('');
    }
  }

  /* ---------- 剪贴板提示 ---------- */
  function syncClipHint() {
    $$('.clip-hint').forEach(el => el.remove());
    const c = ops.clip;
    if (!c || !c.items || !c.items.length) return;
    const host = $('#p-library .lib-head') || $('#p-library');
    if (!host) return;
    const el = document.createElement('span');
    el.className = 'clip-hint';
    el.textContent = (c.mode === 'cut' ? '已剪切 ' : '已复制 ') + c.items.length + ' 项 · 到目标文件夹后粘贴';
    host.appendChild(el);
  }

  /* ---------- 菜单 ---------- */
  /* 菜单里的「全选 / 反选 / 刷新」也必须按**打开菜单的那一格**走。
     原来只判断 side === 'B'，C/D 格一律落到 A 的列表上。 */
  const paneIdsOf = k => (typeof window.paneIds === 'function' ? window.paneIds(k) : []);
  const paint = k => { if (typeof window.paintPane === 'function') window.paintPane(k); };

  window.moreItems = side => {
    const k = paneKey(side);
    return [
      { label: '新建文件', act: () => ops.newFile() },
      { label: '新建文件夹', act: () => ops.newFolder() },
      'sep',
      { label: '复制', act: () => ops.setClip('copy', k) },
      { label: '剪切', act: () => ops.setClip('cut', k) },
      { label: '粘贴' + (ops.clip ? '（' + ops.clip.items.length + ' 项）' : ''), act: () => ops.paste() },
      { label: '反选', act: () => ops.invert(paneIdsOf(k), new Set(sel(k))) },
      'sep',
      { label: '刷新', act: () => { paint(k); toast('已刷新'); } },
      { label: '全选', act: () => {
          const ids = paneIdsOf(k);
          if (!ids.length) return toast('这个文件夹是空的');
          if (typeof window.paneSel === 'function') {
            const s = window.paneSel(k);
            s.clear();
            ids.forEach(i => s.add(i));
            if (ids.length) window.paneSetCur(k, ids[ids.length - 1]);
            paint(k);
          } else {
            multi.clear();
            ids.forEach(i => multi.add(i));
            render();
          }
          toast('已全选 ' + ids.length + ' 项');
        } },
      { label: '加入篮子', act: addToBasket },
      'sep',
      { label: '对比左右', act: () => setCmp(true) },
      { label: ops.favs.has(paneState(k).path || '') ? '取消收藏当前文件夹' : '收藏当前文件夹', act: () => ops.toggleFav(paneState(k).path) },
      { label: '收藏的文件夹…', act: () => ops.openFavs() },
      { label: '打开方式…', act: () => ops.openWith(k) },
      'sep',
      { label: '外部换入…', act: () => toast('原型：从外部磁盘换入') },
      { label: '外部复制…', act: () => toast('原型：从外部磁盘复制') }
    ];
  };

  window.rowMenu = (x, y, idx, side) => {
    const f = FILES[idx];
    if (!f || typeof openMenuAt !== 'function') return;
    openMenuAt(x, y, [
      { label: f.folder ? '打开' : '预览', act: () => f.folder ? navigateTo(side, f.full) : openQP(idx) },
      { label: '打开方式…', act: () => ops.openWith(side) },
      'sep',
      { label: '重命名…', act: () => ops.rename(idx) },
      { label: '创建副本', act: () => ops.duplicate() },
      { label: '复制', act: () => ops.setClip('copy', side) },
      { label: '剪切', act: () => ops.setClip('cut', side) },
      { label: '粘贴到此处', act: () => ops.paste() },
      'sep',
      { label: '加入篮子', act: () => { basket.set(ops.bkey(f), f); renderBasket(); toast('已加入篮子 · 1 项'); } },
      { label: '收藏所在文件夹', act: () => ops.toggleFav(f.p) },
      { label: '移到安全回收站', act: () => ops.del() },
      'sep',
      { label: '显示位置', act: () => toast('原型：在系统中显示位置') }
    ]);
  };

  /* 列表 ↔ 网格切换时给列表一帧淡入，避免整块内容硬切 */
  function flashRows(k) {
    const el = document.getElementById('pane' + k);
    const box = el && el.querySelector('.rows');
    if (!box) return;
    box.classList.remove('is-swapping');
    void box.offsetWidth;
    box.classList.add('is-swapping');
    setTimeout(() => box.classList.remove('is-swapping'), 200);
  }
  window.flashRows = flashRows;

  /* ---------- 8 个标签上限 ---------- */
  if (typeof window.addTab === 'function') {
    const _addTab = window.addTab;
    window.addTab = function () {
      if (tabs.length >= 8) { toast('最多同时打开 8 个标签页'); return; }
      return _addTab.apply(this, arguments);
    };
  }

  /* ---------- 对比：补类型 / 时间 ---------- */
  function extendCompare() {
    const bar = document.getElementById('cmpBar');
    if (!bar || bar.dataset.ext) return;
    bar.dataset.ext = '1';

    const baseSets = window.cmpSets;
    window.cmpSets = function () {
      const sets = baseSets ? baseSets() : { left: new Set(), right: new Set(), both: new Set(), diff: new Set() };
      const a = (PA.idx || []).map(i => FILES[i]), b = (PB.idx || []).map(i => FILES[i]);
      const am = new Map(a.map(f => [f.n, f])), bm = new Map(b.map(f => [f.n, f]));
      sets.ctype = new Set([...sets.both].filter(n => am.get(n).k !== bm.get(n).k));
      sets.ctime = new Set([...sets.both].filter(n => am.get(n).t !== bm.get(n).t));
      return sets;
    };

    const label = () => {
      const s = window.cmpSets();
      const t1 = bar.querySelector('button[data-c="ctype"]'), t2 = bar.querySelector('button[data-c="ctime"]');
      if (t1) t1.textContent = '类型不同 ' + (s.ctype ? s.ctype.size : 0);
      if (t2) t2.textContent = '时间不同 ' + (s.ctime ? s.ctime.size : 0);
    };

    const mk = (key, text) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.dataset.c = key;
      b.textContent = text;
      bar.appendChild(b);
      b.addEventListener('click', () => {
        cmpType = cmpType === key ? null : key;
        [...bar.querySelectorAll('button[data-c]')].forEach(x => x.classList.toggle('is-on', x.dataset.c === cmpType));
        render(); if (dual) renderB();
        label();
      });
    };
    mk('ctype', '类型不同 0');
    mk('ctime', '时间不同 0');

    window.applyCmpFilter = function (container, countEl, side) {
      if (!cmpType || !container) return;
      const sets = window.cmpSets();
      let keep = null;
      if (cmpType === 'left' && side === 'A') keep = sets.left;
      else if (cmpType === 'right' && side === 'B') keep = sets.right;
      else if (cmpType === 'both') keep = sets.both;
      else if (cmpType === 'diff') keep = sets.diff;
      else if (cmpType === 'ctype') keep = sets.ctype;
      else if (cmpType === 'ctime') keep = sets.ctime;
      if (!keep) return;
      let visible = 0;
      [...container.querySelectorAll('.row')].forEach(r => {
        const name = r.querySelector('.fname')?.textContent;
        const on = !!name && keep.has(name);
        r.style.display = on ? '' : 'none';
        if (on) visible++;
      });
      if (countEl) countEl.textContent = visible + ' 项';
    };

    const _setCmp = window.setCmp;
    if (typeof _setCmp === 'function') {
      window.setCmp = function () {
        const r = _setCmp.apply(this, arguments);
        setTimeout(label, 0);
        return r;
      };
    }
    label();
  }

  /* ---------- Ctrl+C / Ctrl+X / Ctrl+V ---------- */
  document.addEventListener('keydown', e => {
    if (!(e.ctrlKey || e.metaKey)) return;
    if (!document.querySelector('#p-library.active')) return;
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    const k = e.key.toLowerCase();
    if (k === 'c') { e.preventDefault(); ops.setClip('copy'); }
    else if (k === 'x') { e.preventDefault(); ops.setClip('cut'); }
    else if (k === 'v') { e.preventDefault(); ops.paste(); }
    else if (k === 'z') { e.preventDefault(); if (!ops.quickUndo()) toast('没有可撤销的删除'); }
  });

  /* ---------- Delete / Backspace 删除 ---------- */
  document.addEventListener('keydown', e => {
    if (!document.querySelector('#p-library.active')) return;
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    if (e.key === 'Delete' || (e.key === 'Backspace' && !e.metaKey && !e.ctrlKey)) {
      e.preventDefault();
      ops.del();
    }
  });

  /* ---------- 启动 ---------- */
  addUpButton();
  ensureTreeGroups();
  renderTreeGroups();
  extendCompare();

  const origRender = window.render;
  window.render = function () {
    const r = origRender.apply(this, arguments);
    renderTreeGroups(); syncClipHint();
    return r;
  };

  window.v2lib = {
    goUp, renderTreeGroups, syncClipHint,
    get ids() { return (lastA || []).slice(); },
    get favs() { return [...ops.favs]; },
    get clip() { return ops.clip; }
  };
})();
