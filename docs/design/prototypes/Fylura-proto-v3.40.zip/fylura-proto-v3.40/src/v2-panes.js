/* ===== Windows 文件库：多窗格（1–4）=====
   这一层把「左右双栏」推广成 1–4 个同构窗格：
   - 每格有自己的目录、历史、搜索、筛选、排序、视图与选中；
   - 布局是 单栏 / 左右 / 上下 / 三栏 / 四宫格，分隔条可拖、可双击复位、方向键微调；
   - 跨格拖放会真的改 p（原来只弹一句 toast）。

   A / B 沿用主脚本里已经跑通的 render()/renderB()，C / D 由这里按同一个 DOM 形状
   构建（行仍复用 rowHTML）。这样不重写已验证的渲染路径，四种布局长得一模一样。
   ==================================================================== */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const ORDER = ['A', 'B', 'C', 'D'];
  const GAP = 9;                 /* 分隔条轨道宽度，与旧双栏一致 */
  const MIN = 230;               /* 单格最小宽度 */
  const toast = m => { if (typeof showToast === 'function') showToast(m); };

  const libEl = document.querySelector('.lib');
  const wrap = document.querySelector('.fm-panes');
  const paneA = document.getElementById('paneA');
  const paneB = document.getElementById('paneB');
  if (!libEl || !wrap || !paneA || !paneB || typeof computeIdx !== 'function') return;

  /* ---------------- 1. 状态 ---------------- */
  /* PA 的搜索词与视图原来挂在全局 query / view 上，这里补成同构字段 */
  Object.defineProperty(PA, 'q', { get: () => query, set: v => { query = v; }, configurable: true });
  Object.defineProperty(PA, 'view', { get: () => view, set: v => { view = v; }, configurable: true });

  const dirsAvailable = () => {
    const files = new Map(), hasSub = new Set();
    FILES.forEach(f => {
      const p = f.p || '';
      if (!p) return;
      if (f.folder) hasSub.add(p);
      else files.set(p, (files.get(p) || 0) + 1);
    });
    const list = [...files.entries()].filter(([p, n]) => n >= 2 && !hasSub.has(p));
    const pool = list.length >= 3 ? list : [...files.entries()].filter(([, n]) => n >= 2);
    return pool.sort((a, b) => b[1] - a[1]).map(([p]) => p);
  };

  function mkPaneState(path) {
    const st = { q: '', filter: 'all', sort: 'name', dir: 1, view: 'list',
      path, idx: [], hist: [], hi: 0, sel: new Set(), cur: null, ids: [] };
    st.idx = FILES.map((f, i) => i).filter(i => FILES[i].p === path);
    st.hist = [{ path, idx: st.idx.slice() }];
    st.cur = st.idx[0] != null ? st.idx[0] : null;
    return st;
  }
  const seed = dirsAvailable();
  const PC = mkPaneState(seed[1] || seed[0] || 'Assets / Photos');
  const PD = mkPaneState(seed[2] || seed[0] || 'Documents / Finance');

  const ST = { A: PA, B: PB, C: PC, D: PD };
  const paneState = k => ST[k] || PA;
  const paneSel = k => (k === 'A' ? multi : k === 'B' ? selB : paneState(k).sel);
  const paneCur = k => (k === 'A' ? current : k === 'B' ? curB : paneState(k).cur);
  const paneSetCur = (k, v) => { if (k === 'A') current = v; else if (k === 'B') curB = v; else paneState(k).cur = v; };
  const paneIds = k => {
    const v = k === 'A' ? lastA : k === 'B' ? lastB : paneState(k).ids;
    return Array.isArray(v) ? v : [];
  };
  const paneEl = k => document.getElementById('pane' + k);

  /* ---------------- 2. 布局 ---------------- */
  /* cells: [col, row, colSpan, rowSpan]，按顺序对应 A / B / C / D。
     三栏不做三等分——那在 900 宽的内容区里每格只剩 250，文件名全被截断；
     改成「左一大 + 右两小」，左栏照常使用，右栏上下各一格。 */
  const LAYOUTS = {
    '1':  { id: '1',  name: '单栏',     cols: 1, rows: 1,
            cells: [[0, 0, 1, 1]], rs: [] },
    '2v': { id: '2v', name: '左右双栏', cols: 2, rows: 1,
            cells: [[0, 0, 1, 1], [1, 0, 1, 1]],
            rs: [{ axis: 'v', at: 1, col: '2', row: '1 / -1' }] },
    '2h': { id: '2h', name: '上下双栏', cols: 1, rows: 2,
            cells: [[0, 0, 1, 1], [0, 1, 1, 1]],
            rs: [{ axis: 'h', at: 1, col: '1 / -1', row: '2' }] },
    '3':  { id: '3',  name: '三栏',     cols: 2, rows: 2,
            cells: [[0, 0, 1, 2], [1, 0, 1, 1], [1, 1, 1, 1]],
            rs: [{ axis: 'v', at: 1, col: '2', row: '1 / -1' },
                 { axis: 'h', at: 1, col: '3', row: '2' }] },
    '4':  { id: '4',  name: '四宫格',   cols: 2, rows: 2,
            cells: [[0, 0, 1, 1], [1, 0, 1, 1], [0, 1, 1, 1], [1, 1, 1, 1]],
            rs: [{ axis: 'v', at: 1, col: '2', row: '1 / -1' },
                 { axis: 'h', at: 1, col: '1 / -1', row: '2' }] }
  };
  const LAYOUT_ORDER = ['1', '2v', '2h', '3', '4'];
  let layoutId = '1';
  let visible = 1;
  let layTimer = 0;
  const ratios = { col: [1, 1], row: [1, 1] };

  function paintTracks() {
    const L = LAYOUTS[layoutId];
    const c = ratios.col.slice(0, L.cols), r = ratios.row.slice(0, L.rows);
    wrap.style.gridTemplateColumns = c.map(v => `minmax(0,${v}fr)`).join(` ${GAP}px `);
    wrap.style.gridTemplateRows = r.map(v => `minmax(0,${v}fr)`).join(` ${GAP}px `);
  }

  function buildResizers(L) {
    $$('.fm-rs', wrap).forEach(el => el.remove());
    (L.rs || []).forEach(spec => {
      const { axis, at: j } = spec;
      const rz = document.createElement('div');
      rz.className = 'fm-rs fm-rs--' + (axis === 'v' ? 'v' : 'h');
      rz.tabIndex = 0;
      rz.setAttribute('role', 'separator');
      rz.setAttribute('aria-orientation', axis === 'v' ? 'vertical' : 'horizontal');
      rz.setAttribute('aria-label', axis === 'v' ? '调整左右窗格宽度' : '调整上下窗格高度');
      rz.title = '拖动调整，双击复位';
      rz.style.gridColumn = spec.col;
      rz.style.gridRow = spec.row;
      rz.addEventListener('pointerdown', e => startDrag(e, rz, axis, j));
      rz.addEventListener('dblclick', () => { resetGap(axis, j); });
      rz.addEventListener('keydown', e => {
        const arr = axis === 'v' ? ratios.col : ratios.row;
        const sum = arr[j - 1] + arr[j];
        const step = (e.shiftKey ? 0.08 : 0.02) * sum;
        if ((axis === 'v' && e.key === 'ArrowLeft') || (axis === 'h' && e.key === 'ArrowUp')) { e.preventDefault(); nudge(axis, j, -step); }
        else if ((axis === 'v' && e.key === 'ArrowRight') || (axis === 'h' && e.key === 'ArrowDown')) { e.preventDefault(); nudge(axis, j, step); }
        else if (e.key === 'Home') { e.preventDefault(); resetGap(axis, j); }
      });
      wrap.appendChild(rz);
    });
  }

  function resetGap(axis, j) {
    const arr = axis === 'v' ? ratios.col : ratios.row;
    const half = (arr[j - 1] + arr[j]) / 2;
    arr[j - 1] = half; arr[j] = half;
    paintTracks();
  }

  function nudge(axis, j, delta) {
    const arr = axis === 'v' ? ratios.col : ratios.row;
    const sum = arr[j - 1] + arr[j];
    const lo = 0.18 * sum, hi = 0.82 * sum;
    const a = Math.max(lo, Math.min(hi, arr[j - 1] + delta));
    arr[j - 1] = a; arr[j] = sum - a;
    paintTracks();
  }

  let drag = null;
  function startDrag(e, rz, axis, j) {
    if (e.button !== 0) return;
    const L = LAYOUTS[layoutId];
    const box = wrap.getBoundingClientRect();
    const total = (axis === 'v' ? box.width : box.height) - GAP * ((axis === 'v' ? L.cols : L.rows) - 1);
    const arr = axis === 'v' ? ratios.col : ratios.row;
    const pairSum = arr[j - 1] + arr[j];
    drag = { axis, j, rz, total, pairSum, start: axis === 'v' ? e.clientX : e.clientY,
             from: arr[j - 1] / pairSum };
    rz.classList.add('is-drag');
    document.body.classList.add(axis === 'v' ? 'fm-col-resizing' : 'fm-row-resizing');
    try { rz.setPointerCapture(e.pointerId); } catch (_e) {}
    e.preventDefault();
  }
  window.addEventListener('pointermove', e => {
    if (!drag) return;
    const { axis, j, total, pairSum, start, from } = drag;
    const arr = axis === 'v' ? ratios.col : ratios.row;
    const minFrac = Math.min(0.45, MIN / Math.max(1, total));
    const f = Math.max(minFrac, Math.min(1 - minFrac, from + ((axis === 'v' ? e.clientX : e.clientY) - start) / total));
    arr[j - 1] = f * pairSum;
    arr[j] = (1 - f) * pairSum;
    paintTracks();
  });
  window.addEventListener('pointerup', () => {
    if (!drag) return;
    drag.rz.classList.remove('is-drag');
    document.body.classList.remove('fm-col-resizing', 'fm-row-resizing');
    try { drag.rz.releasePointerCapture(1); } catch (_e) {}
    drag = null;
  });

  function applyLayout() {
    const L = LAYOUTS[layoutId];
    const n = L.cells.length;
    visible = n;
    ORDER.forEach((k, i) => {
      const el = paneEl(k);
      if (!el) return;
      const cell = L.cells[i];
      const vis = !!cell;
      el.hidden = !vis;
      if (vis) {
        const [c, r, cs, rs] = cell;
        el.style.gridColumn = (2 * c + 1) + ' / span ' + (2 * cs - 1);
        el.style.gridRow = (2 * r + 1) + ' / span ' + (2 * rs - 1);
      }
    });
    paintTracks();
    buildResizers(L);
    dual = n > 1;                          /* 旧逻辑用 dual 控制工具栏/路径/检查器的显隐 */
    libEl.classList.toggle('dual', dual);
    libEl.classList.toggle('is-multi', dual);
    ['1', '2v', '2h', '3', '4'].forEach(id => libEl.classList.remove('panes-' + id));
    libEl.classList.add('panes-' + L.id);
    syncLayoutLabel();
    /* 切布局时每一格各自落位。用一个短命类打一帧，避免每次重绘都播一遍 */
    libEl.classList.remove('is-lay');
    void libEl.offsetWidth;
    libEl.classList.add('is-lay');
    clearTimeout(layTimer);
    layTimer = setTimeout(() => libEl.classList.remove('is-lay'), 340);
  }

  function syncLayoutLabel() {
    const el = document.getElementById('layoutLabel');
    if (el) el.textContent = LAYOUTS[layoutId].name;
    const btn = document.getElementById('layoutBtn');
    if (btn) btn.setAttribute('aria-pressed', String(layoutId !== '1'));
  }

  /* 新开的窗格别和别的窗格停在同一目录：否则「跨格移动」看不见任何变化 */
  function homelyPanes(n) {
    for (let i = 0; i < n; i++) {
      const k = ORDER[i];
      if (k === 'A' || k === 'B') continue;
      const st = paneState(k);
      const used = ORDER.slice(0, n).filter(x => x !== k).map(x => paneState(x).path);
      if (!st.path || used.includes(st.path)) {
        const cand = dirsAvailable().find(p => !used.includes(p) && p !== st.path);
        if (cand) gotoPane(k, cand);
      }
    }
  }

  function gotoPane(k, path) {
    const st = paneState(k);
    st.path = path;
    st.idx = FILES.map((f, i) => i).filter(i => FILES[i].p === path);
    st.hist = [{ path, idx: st.idx.slice() }];
    st.hi = 0;
    paneSel(k).clear();
    paneSetCur(k, st.idx[0] != null ? st.idx[0] : null);
  }

  function setLayout(id, silent) {
    if (!LAYOUTS[id]) return;
    if (id === layoutId && !silent) return;
    layoutId = id;
    const n = LAYOUTS[layoutId].cells.length;
    homelyPanes(n);
    applyLayout();
    renderAll();
    if (n === 1) focusPane('A');
    else if (ORDER.indexOf(focus) >= n) focusPane('A');
    if (!silent) toast(LAYOUTS[layoutId].name + ' · ' + n + ' 个窗格');
  }

  /* ---------------- 3. 渲染 ---------------- */
  function rowClick(k, i, e) {
    focusPane(k);
    lastClick[k] = i;
    if (e.shiftKey) { selectRange(k, i); return; }
    if (e.metaKey || e.ctrlKey || e.target.closest('.cb')) toggleIn(k, i);
    else selectIn(k, i);
  }

  function rowOpen(k, i) {
    const f = FILES[i];
    if (!f) return;
    if (f.folder) { navigateTo(k, f.full); return; }
    openQP(i);
  }

  function startDragRow(k, i) {
    const sel = paneSel(k);
    dragSide = k;
    dragIds = sel.size ? [...sel] : [i];
  }

  function renderPane(k) {
    const el = paneEl(k);
    if (!el) return;
    const st = paneState(k), sel = paneSel(k), cur = paneCur(k);
    const idxs = computeIdx(st, st.q || '');
    st.ids = idxs;
    const rows = el.querySelector('.rows');
    const cols = el.querySelector('.cols');
    const grid = st.view === 'grid';
    if (!rows) return;
    if (cols) cols.style.display = grid ? 'none' : '';
    rows.className = 'rows' + (grid ? ' grid' : '');
    const single = sel.size === 0;
    const on = i => sel.has(i) || (single && i === cur);
    rows.innerHTML = '';
    if (!idxs.length) {
      rows.innerHTML = stateHTML(st.q ? 'search' : 'empty');
    } else {
      const frag = document.createDocumentFragment();
      idxs.forEach(i => {
        const f = FILES[i];
        const btn = document.createElement('button');
        btn.dataset.i = String(i);
        btn.draggable = true;
        btn.addEventListener('click', e => rowClick(k, i, e));
        btn.addEventListener('dblclick', () => rowOpen(k, i));
        btn.addEventListener('dragstart', () => startDragRow(k, i));
        if (grid) {
          btn.className = 'gcard' + (on(i) ? ' sel' : '');
          /* 文件名与路径必须转义：这里拼的是 innerHTML，用户能把文件名改成 `<img onerror=…>`。
             列表视图的 rowHTML 走同一套（zcEsc 由 flow.js 导出）。 */
          btn.innerHTML = `<span class="fi" data-k="${f.k}"><svg><use href="#f-${f.k}"/></svg></span>
            <b>${zcEsc(f.n)}</b><small>${zcEsc(f.p)}</small>
            <span class="gm"><span>${zcEsc(f.t)}</span><span>${zcEsc(f.s)}</span></span>`;
        } else {
          btn.className = 'row' + (on(i) ? ' sel' : '');
          btn.setAttribute('role', 'option');
          btn.setAttribute('aria-selected', String(on(i)));
          btn.tabIndex = (single && i === cur) ? 0 : -1;
          btn.innerHTML = rowHTML(i);
        }
        frag.appendChild(btn);
      });
      rows.appendChild(frag);
    }
    const cnt = el.querySelector('.fm-pane-count');
    if (cnt) cnt.textContent = idxs.length + ' 项';
  }

  function renderAll() {
    if (typeof window.render === 'function') window.render();
    if (visible > 1 && typeof window.renderB === 'function') window.renderB();
    if (visible > 2) renderPane('C');
    if (visible > 3) renderPane('D');
    syncHeads();
  }

  function selectIn(k, i) {
    /* 传进来的可能是已失效的下标（列表在两次调用之间被重建过）：直接忽略，
       否则 paintInspector 会读 undefined 崩掉整页 */
    if (!FILES[i]) return;
    paneSetCur(k, i);
    paneSel(k).clear();
    paintInspector(FILES[i]);
    renderPane(k);
    syncHeads();
    updateStatus();
  }

  function toggleIn(k, i) {
    const sel = paneSel(k), ids = paneIds(k), cur = paneCur(k);
    /* 当前项在视觉上已被选中，多选时先把它带进来 */
    if (sel.size === 0 && cur != null && cur !== i && ids.includes(cur)) sel.add(cur);
    if (sel.has(i)) sel.delete(i); else sel.add(i);
    if (sel.size === 1) paneSetCur(k, [...sel][0]);
    renderPane(k);
    updateStatus();
  }

  /* ---------------- 4. 覆盖主脚本里的 A/B 假设 ---------------- */
  window.selectRange = function (k, i) {
    const arr = paneIds(k), anchor = lastClick[k];
    const fallback = () => { selectIn(k, i); lastClick[k] = i; };
    if (anchor == null || !arr.length) return fallback();
    const a = arr.indexOf(anchor), b = arr.indexOf(i);
    if (a < 0 || b < 0) return fallback();
    const [s0, e0] = a < b ? [a, b] : [b, a];
    const sel = paneSel(k);
    sel.clear();
    arr.slice(s0, e0 + 1).forEach(x => sel.add(x));
    paneSetCur(k, i);
    paintInspector(FILES[i]);
    renderPane(k);
    updateStatus();
  };

  /* 焦点：四格统一（原来只切 A/B 两个 class） */
  window.focusPane = function (k) {
    if (!PANE_EL[k]) return;
    focus = k;
    ORDER.forEach(x => { const el = paneEl(x); if (el) el.classList.toggle('is-focus', x === k); });
    syncHeads();
    updateStatus();
  };

  /* 每格自己的头部（路径 / 前进后退 / 搜索 / 视图 / 筛选） */
  function syncPaneHead(k) {
    const el = paneEl(k), st = paneState(k);
    if (!el || el.hidden) return;
    const p = el.querySelector('#path' + k);
    if (p) p.textContent = st.path;
    const b = el.querySelector('#back' + k), f = el.querySelector('#fwd' + k);
    if (b) b.disabled = st.hi <= 0;
    if (f) f.disabled = st.hi >= st.hist.length - 1;
    const q = el.querySelector('#q' + k);
    if (q && q.value !== (st.q || '')) q.value = st.q || '';
    const v = el.querySelector('#view' + k);
    if (v) { const u = v.querySelector('use'); if (u) u.setAttribute('href', st.view === 'grid' ? '#i-list' : '#i-grid'); }
    const fl = el.querySelector('#filter' + k);
    if (fl) fl.setAttribute('aria-pressed', String(st.filter !== 'all'));
  }

  window.syncHeads = function () {
    ORDER.forEach(syncPaneHead);
    const stF = paneState(focus);
    const hb = document.getElementById('hdrBack'), hf = document.getElementById('hdrFwd');
    if (hb) hb.disabled = stF.hi <= 0;
    if (hf) hf.disabled = stF.hi >= stF.hist.length - 1;
    if (typeof renderTree === 'function') renderTree();
  };

  window.updateStatus = function () {
    const st = document.getElementById('fmStatus');
    if (!st) return;
    const k = focus;
    const el = paneEl(k);
    const ids = paneIds(k);
    const sel = paneSel(k);
    const shown = el
      ? [...el.querySelectorAll('.row')].filter(r => r.style.display !== 'none')
          .map(r => r.querySelector('.fname')?.textContent).filter(Boolean)
      : [];
    const items = ids.map(i => FILES[i]).filter(Boolean);
    const selItems = [...sel].map(i => FILES[i]).filter(Boolean);
    const total = items.reduce((n, f) => n + sizeOf(f.s), 0);
    const selTotal = selItems.reduce((n, f) => n + sizeOf(f.s), 0);
    const c = document.getElementById('stCount');
    if (c) c.textContent = (shown.length || items.length) + ' 项';
    const selEl = document.getElementById('stSel');
    if (selEl) {
      if (selItems.length) { selEl.hidden = false; selEl.textContent = '已选 ' + selItems.length + ' 项' + (selTotal ? ' · ' + fmtKB(selTotal) : ''); }
      else selEl.hidden = true;
    }
    const sz = document.getElementById('stSize');
    if (sz) sz.textContent = total ? '共 ' + fmtKB(total) : '—';
  };

  /* 标签会话：把布局和 C/D 一起存 */
  const baseSnapshot = window.snapshot, baseApplyTab = window.applyTab;
  window.snapshot = function () {
    const t = baseSnapshot();
    t.layout = layoutId;
    t.ratios = JSON.parse(JSON.stringify(ratios));
    t.panes = {};
    ORDER.slice(2).forEach(k => {
      const st = paneState(k);
      t.panes[k] = { q: st.q, filter: st.filter, sort: st.sort, dir: st.dir, view: st.view,
        path: st.path, hist: JSON.parse(JSON.stringify(st.hist)), hi: st.hi };
    });
    return t;
  };
  window.applyTab = function (t) {
    baseApplyTab(t);
    if (t && t.ratios) { ratios.col = t.ratios.col.slice(); ratios.row = t.ratios.row.slice(); }
    if (t && t.panes) ORDER.slice(2).forEach(k => {
      const s = t.panes[k];
      if (s) Object.assign(paneState(k), s, { idx: [], ids: [] });
    });
    /* 新标签没有 layout：沿用当前布局，而不是把工作区打回单栏 */
    layoutId = (t && LAYOUTS[t.layout]) ? t.layout : layoutId;
    applyLayout();
    renderAll();
  };

  /* ---------------- 5. 窗格 DOM 与绑定 ---------------- */
  const PANE_EL = { A: paneA, B: paneB, C: null, D: null };
  /* 焦点在 focusPane 里读，这里先声明避免 TDZ */
  window.PANE_EL = PANE_EL;

  const UP = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V6M6 12l6-6 6 6"/></svg>';

  function clonePane(key) {
    const el = paneA.cloneNode(true);
    el.id = 'pane' + key;
    el.classList.remove('is-focus');
    el.hidden = true;
    el.querySelectorAll('[id]').forEach(n => {
      if (n.id === 'rows') n.id = 'rows' + key;
      else if (n.id === 'cbAll') n.id = 'cbAll' + key;
      else n.id = n.id.replace(/A$/, key);
    });
    const rows = el.querySelector('.rows');
    if (rows) { rows.innerHTML = ''; rows.className = 'rows'; }
    paneB.after(el);
    return el;
  }

  function wirePane(k, el) {
    const on = (sel, ev, fn) => { const n = el.querySelector(sel); if (n) n.addEventListener(ev, fn); };
    on('#back' + k, 'click', () => histMove(k, -1));
    on('#fwd' + k, 'click', () => histMove(k, 1));
    on('#path' + k, 'click', () => editPath(k));
    on('#filter' + k, 'click', e => { e.stopPropagation(); openMenu(el.querySelector('#filter' + k), filterItems(k)); });
    on('#sort' + k, 'click', e => { e.stopPropagation(); openMenu(el.querySelector('#sort' + k), sortItems(k)); });
    on('#view' + k, 'click', () => { const st = paneState(k); st.view = st.view === 'grid' ? 'list' : 'grid'; syncHeads(); renderPane(k); if (window.flashRows) flashRows(k); });
    on('#more' + k, 'click', e => { e.stopPropagation(); openMenuAt(e.clientX, e.clientY, (window.moreItems || moreItems)(k)); });
    const q = el.querySelector('#q' + k);
    if (q) q.addEventListener('input', () => { paneState(k).q = q.value.trim(); renderPane(k); });

    el.addEventListener('mousedown', e => {
      if (e.target.closest('.fm-tool, .fm-path, input, .fm-pane-search')) { focusPane(k); return; }
      focusPane(k);
    });
    el.addEventListener('contextmenu', e => {
      const row = e.target.closest('.row, .gcard');
      if (!row) {
        e.preventDefault();
        openMenuAt(e.clientX, e.clientY, emptyItems(k));
        return;
      }
      const i = row.dataset.i != null ? +row.dataset.i : -1;
      if (i < 0) return;
      e.preventDefault();
      focusPane(k);
      if (!paneSel(k).has(i)) {
        paneSetCur(k, i);
        paneSel(k).clear();
        renderPane(k);
      }
      if (typeof window.rowMenu === 'function') window.rowMenu(e.clientX, e.clientY, i, k);
    });

    /* 框选（复用 initMarquee） */
    const box = el.querySelector('.rows');
    if (box && typeof initMarquee === 'function') {
      initMarquee(box, '.row, .gcard', (hits, add, commit) => {
        /* 框选时 pointerdown 被 preventDefault 了，兼容的 mousedown 不会来，
           焦点得在这里手动挪到这一格，否则键盘操作还留在上一格 */
        if (hits.length && focus !== k) focusPane(k);
        const sel = paneSel(k), ids = paneIds(k);
        const nodes = [...box.querySelectorAll('.row, .gcard')];
        if (!add) sel.clear();
        const hs = new Set(hits);
        nodes.forEach((n, pos) => {
          if (hs.has(n) && ids[pos] != null) sel.add(ids[pos]);
          n.classList.toggle('sel', ids[pos] != null && sel.has(ids[pos]));
        });
        const lastHit = hits[hits.length - 1];
        if (lastHit) {
          const pos = nodes.indexOf(lastHit);
          if (pos >= 0 && ids[pos] != null) paneSetCur(k, ids[pos]);
        }
        if (commit) {
          [...sel].forEach(i => { if (!ids.includes(i)) sel.delete(i); });
          renderPane(k); updateStatus();
        }
      }, '.cols');
    }

    /* 跨格拖放由 wireDrop 统一绑定（A/B 的旧绑定在主脚本里已经摘掉） */
  }

  function addUp(k, el) {
    const fwd = el && el.querySelector('#fwd' + k);
    if (!fwd || el.querySelector('#up' + k)) return;
    const up = document.createElement('button');
    up.className = 'fm-tool';
    up.id = 'up' + k;
    up.type = 'button';
    up.title = '上一级';
    up.setAttribute('aria-label', '上一级');
    up.innerHTML = UP;
    up.addEventListener('click', () => {
      const p = paneState(k).path;
      if (!p || p === '本机') return toast('已经在最上层');
      navigateTo(k, p.split(' / ').slice(0, -1).join(' / '));
    });
    fwd.after(up);
  }

  /* 跨格拖放：真的改 p，不再只弹一句 toast */
  function wireDrop(k, el) {
    if (!el) return;
    el.addEventListener('dragover', e => {
      if (!dragIds || !dragIds.length) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      el.classList.add('is-drop');
    });
    el.addEventListener('dragleave', e => {
      if (el.contains(e.relatedTarget)) return;
      el.classList.remove('is-drop');
    });
    el.addEventListener('drop', e => {
      if (!dragIds || !dragIds.length) return;
      e.preventDefault();
      e.stopPropagation();
      el.classList.remove('is-drop');
      const to = paneState(k).path;
      const ids = dragIds.slice();
      const from = dragSide;
      dragIds = [];
      let moved = 0;
      ids.forEach(i => {
        const f = FILES[i];
        if (!f || f.p === to || f.folder) return;
        f.p = to; f.t = '刚刚'; f.m = '刚刚';
        moved++;
      });
      if (!moved) { toast('已经在同一个文件夹'); return; }
      ORDER.forEach(x => paneSel(x).clear());
      ids.forEach(i => { if (FILES[i] && FILES[i].p === to) paneSel(k).add(i); });
      if (paneSel(k).size) paneSetCur(k, [...paneSel(k)][0]);
      renderAll();
      toast('已移动 ' + moved + ' 项到 ' + to.split(' / ').pop());
      if (from && from !== k) focusPane(k);
    });
  }

  /* 篮子：转运到「下一格」（不是固定的左右两栏） */
  function transferBasket() {
    if (!basket.size) { toast('篮子还是空的'); return; }
    const n = visible;
    const idxNow = Math.max(0, ORDER.indexOf(focus));
    const target = ORDER[(idxNow + 1) % n];
    const to = paneState(target).path;
    let moved = 0;
    basket.forEach(f => {
      const i = FILES.indexOf(f);
      if (i < 0 || f.p === to || f.folder) return;
      f.p = to; f.t = '刚刚'; f.m = '刚刚';
      moved++;
    });
    basket.clear();
    if (typeof renderBasket === 'function') renderBasket();
    if (!moved) { toast('这些项已经在 ' + to.split(' / ').pop()); return; }
    renderAll();
    toast('已转运 ' + moved + ' 项到' + (target === 'A' ? '左栏' : target === 'B' ? '右栏' : LAYOUTS[layoutId].name + ' 的第 ' + (ORDER.indexOf(target) + 1) + ' 格'));
  }

  window.zcTransferBasket = transferBasket;

  ['C', 'D'].forEach(k => {
    const el = clonePane(k);
    PANE_EL[k] = el;
    wirePane(k, el);
  });
  ORDER.forEach(k => { addUp(k, paneEl(k)); wireDrop(k, paneEl(k)); });

  /* ---------------- 6. 布局按钮 ---------------- */
  const oldBtn = document.getElementById('dualBtn');
  if (oldBtn) {
    /* 换一个新节点：旧的 click 监听是「切双栏」，没法移除 */
    const btn = oldBtn.cloneNode(false);
    btn.id = 'layoutBtn';
    btn.setAttribute('aria-haspopup', 'menu');
    btn.setAttribute('aria-pressed', 'false');
    btn.title = '窗格布局';
    btn.innerHTML = '<svg><use href="#i-split"/></svg><span id="layoutLabel">单栏</span>';
    oldBtn.replaceWith(btn);
    btn.addEventListener('click', e => {
      e.stopPropagation();
      openMenu(btn, LAYOUT_ORDER.map(id => ({
        label: LAYOUTS[id].name, on: layoutId === id, act: () => setLayout(id)
      })));
    });
  }

  window.setLayout = setLayout;
  window.renderPane = renderPane;
  window.renderAll = renderAll;
  window.paintPane = k => {
    if (k === 'A') { if (typeof window.render === 'function') window.render(); }
    else if (k === 'B') { if (typeof window.renderB === 'function') window.renderB(); }
    else renderPane(k);
    if (k === focus) updateStatus();
  };
  window.paneState = paneState;
  window.paneSel = paneSel;
  window.paneCur = paneCur;
  window.paneSetCur = paneSetCur;
  window.paneIds = paneIds;
  window.zcPanes = {
    get layout() { return layoutId; },
    get visible() { return visible; },
    setLayout, renderAll, renderPane, state: paneState,
    select: (k, i) => selectIn(k, i),
    toggle: (k, i) => toggleIn(k, i),
    get ratios() { return JSON.parse(JSON.stringify(ratios)); }
  };

  /* ---------------- 7. 启动 ---------------- */
  applyLayout();
  homelyPanes(1);
  /* 默认单栏：先把四个窗格都渲染一次，切换布局时不会看到空白 */
  renderAll();
  renderPane('C');
  renderPane('D');
  focusPane('A');
})();
