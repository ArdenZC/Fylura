/* ===== Windows 文件库侧栏：分组折叠 + 信息栏把手 =====
   分组标题原来只是说明文字，占着一行却什么都不能点。现在每个分组都是
   一个可折叠的段：chevron + 标题，点一下收起，状态记在 localStorage。
   ==================================================== */
(function () {
  'use strict';
  if (window.__zcV2Sidebar) return;
  window.__zcV2Sidebar = true;

  const COL_KEY = 'fylura:tree-cols';
  let collapsed = [];
  try { collapsed = JSON.parse(localStorage.getItem(COL_KEY) || '[]'); } catch (_e) { collapsed = []; }
  const save = () => { try { localStorage.setItem(COL_KEY, JSON.stringify(collapsed)); } catch (_e) {} };

  const CHEV = '<svg class="sec-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>';

  function wrapGroups() {
    const scroll = document.querySelector('.fm-tree-scroll');
    if (!scroll) return;
    const heads = [...scroll.querySelectorAll('.tree-group')].filter(h => !h.classList.contains('tree-sec-h'));
    heads.forEach(h => {
      const label = (h.textContent || '').trim();
      const wrap = document.createElement('div');
      wrap.className = 'tree-wrap';
      const body = document.createElement('div');
      body.className = 'tree-inner';
      wrap.appendChild(body);
      let n = h.nextSibling;
      while (n) {
        const next = n.nextSibling;
        if (n.nodeType === 1 && n.classList.contains('tree-group')) break;
        body.appendChild(n);
        n = next;
      }
      const sec = document.createElement('div');
      sec.className = 'tree-sec';
      sec.dataset.sec = label;
      const head = document.createElement('button');
      head.type = 'button';
      head.className = 'tree-group tree-sec-h';
      if (h.id) head.id = h.id;          /* v2-library 会按 id 隐藏空分组 */
      head.setAttribute('aria-expanded', 'true');
      head.innerHTML = CHEV + '<span class="sec-txt">' + label + '</span>';
      sec.appendChild(head);
      sec.appendChild(wrap);
      h.replaceWith(sec);
      if (collapsed.indexOf(label) >= 0) {
        sec.classList.add('is-collapsed');
        head.setAttribute('aria-expanded', 'false');
      }
      head.addEventListener('click', () => {
        const col = sec.classList.toggle('is-collapsed');
        head.setAttribute('aria-expanded', String(!col));
        const i = collapsed.indexOf(label);
        if (col && i < 0) collapsed.push(label);
        if (!col && i >= 0) collapsed.splice(i, 1);
        save();
      });
    });
  }

  function addInspRail() {
    const host = document.querySelector('.lib-body');
    if (!host || document.getElementById('inspRail')) return;
    const rail = document.createElement('button');
    rail.type = 'button';
    rail.className = 'insp-rail';
    rail.id = 'inspRail';
    rail.title = '展开信息栏';
    rail.setAttribute('aria-label', '展开信息栏');
    rail.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>';
    rail.addEventListener('click', () => { if (typeof setInfo === 'function') setInfo(true); });
    host.appendChild(rail);
  }

  /* 目录树收起后留一个把手把它拉回来（原来只能靠工具栏那个 panel 图标） */
  function addTreeHandle() {
    const host = document.querySelector('.lib-body');
    if (!host || document.getElementById('treeHandle')) return;
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'insp-rail tree-handle';
    b.id = 'treeHandle';
    b.title = '展开目录树';
    b.setAttribute('aria-label', '展开目录树');
    b.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>';
    b.addEventListener('click', () => {
      const lib = document.querySelector('.lib');
      if (!lib) return;
      lib.classList.remove('tree-off');
      const t = document.getElementById('treeBtn');
      if (t) t.setAttribute('aria-pressed', 'true');
    });
    host.appendChild(b);
    const sync = () => {
      const lib = document.querySelector('.lib');
      b.style.display = lib && lib.classList.contains('tree-off') ? 'grid' : 'none';
    };
    /* tree-off 由工具栏按钮和窄窗逻辑共同切换，用观察者跟住它 */
    const lib = document.querySelector('.lib');
    if (lib && window.MutationObserver) new MutationObserver(sync).observe(lib, { attributes: true, attributeFilter: ['class'] });
    sync();
  }

  wrapGroups();
  addInspRail();
  addTreeHandle();
})();
